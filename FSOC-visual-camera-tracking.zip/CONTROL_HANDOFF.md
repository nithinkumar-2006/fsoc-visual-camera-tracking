# Role #7 Control Handoff

Instantiate a controller with optional configuration:

```python
controller = PIDController(ControllerConfig(kp_pan=1.2, kp_tilt=1.2,
    ki_pan=0.05, kd_pan=0.02, max_pan_rate_radps=0.5))
command = controller.process(ControlInput(tracking_output, frame.camera_state))
apply_tracking_command(camera, command, snapshot.context.simulation_dt_s)
```

The input is Role #6 `TrackingOutput` and the matching `CameraState`; do not provide truth. `TrackingCommand` is a rate request in rad/s, associated with its simulation frame/time. Camera application uses the public camera method and therefore preserves its own rate, pan, and tilt constraints.

Sign convention: right target (`e_u > 0`) commands positive pan; left commands negative pan. Below (`e_v > 0`) commands negative tilt; above commands positive tilt. Error is normalized against the current image dimensions.

Configured controller saturation is visible in command flags, while physical clamping remains camera-owned. Within deadband, requested axis motion is zero. Measured tracking uses normal gain; coasting uses the configurable reduced gain; `LOST` / no estimate sends neutral `NO_TRACK` and resets PID integration by default.

Run the complete regression suite from repository root:

```bash
python -m unittest discover -v
```

`tests/unit/test_control.py` contains unit sign, PID, saturation, anti-windup, lost/coast, mechanical-limit, stationary closed-loop, moving-target, and Role #3–#7 pipeline coverage.
