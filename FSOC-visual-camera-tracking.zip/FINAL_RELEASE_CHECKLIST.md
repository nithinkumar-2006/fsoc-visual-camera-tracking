# Final Release Checklist

## Before leaving for SIH

- [ ] Repository and `ROLE_14_FINAL_SIH.zip` copied to laptop and backup media
- [ ] Python and Tkinter checked with `python -m tkinter`
- [ ] `assets/models/beacon_logistic_v1.json` present
- [ ] `python -m gui.desktop` launched from repository root
- [ ] `exports/` writable and export tested
- [ ] Charger/power arranged; backup copy available

## Before judges arrive

- [ ] Launch application and visually check at 1920×1080
- [ ] Run Clean Tracking
- [ ] Run Temporary Occlusion and observe loss/reacquisition
- [ ] Select AI Assisted (`ai-kalman-pid`) and check model health
- [ ] Run Benchmark; review comparison
- [ ] Export report/telemetry; Reset; close and relaunch once

## Claims check

- [ ] Describe software simulation, not physical FSOC link performance
- [ ] Do not claim webcam validation or physical servo validation
- [ ] Do not fabricate benchmark numbers
- [ ] Explain that ground truth is evaluation-only
- [ ] State that a packaged executable is not verified
