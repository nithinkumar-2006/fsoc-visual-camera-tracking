# User Manual

## Purpose

This desktop application is a virtual-camera laboratory for testing coarse alignment of a moving optical beacon. It runs locally; no account, network connection or cloud backend is needed.

## What you need

Python 3.11+ with Tkinter, the complete repository, and write permission for `exports/`. The required AI artifact is `assets/models/beacon_logistic_v1.json`. Start from repository root with `python -m gui.desktop`.

## Main screen

The top bar contains the **scenario selector** plus **Start**, **Pause**, **Stop**, **Reset**, **Run Benchmark**, and **Export Results**. The centre is the virtual-camera viewport: grey crosshair is image centre, amber rectangles are detections, and cyan circle is the tracked estimate. **Evaluation / Ground Truth** shows a red, explicitly labelled evaluation overlay; leave it off during a realistic live run.

The left rail selects algorithm mode and individual disturbances. The right rail shows state, detector, tracker, controller, confidence, estimate, error, pan/tilt, FPS, latency and active effects. Bottom tabs show tracking error/pose and an event log.

## Run a scenario

1. Select one of: Clean Tracking, Vibration, Turbulence + Noise, False Bright Objects, Temporary Occlusion, or Combined Stress.
2. Select an algorithm:
   - `classical-reactive-proportional` — baseline;
   - `classical-kalman-pid` — classical advanced;
   - `ai-kalman-pid` — model-backed candidate classifier with Kalman/PID.
3. Press **Start**. The state progresses through search/acquire/track/locked where detections permit.
4. **Pause** freezes simulation progress; press **Start** to resume. **Stop** ends the run. **Reset** rebuilds the selected preset from time zero.

To change a disturbance manually, tick its control. For preset changes, always Reset before starting. Temporary occlusion intentionally removes the sensor-visible beacon for its configured window, so loss and subsequent reacquisition are expected.

## Benchmark, comparison and export

**Run Benchmark** executes the three supported modes with the same selected scenario configuration and seed, and saves `exports/application_comparison.csv`. **Export Results** writes the current selected mode as `exports/application_run_REPORT.json` and `exports/application_run_TELEMETRY.csv`.

Reports include simulation duration, configured/effective FPS, acquisition, paired-frame tracking error, lock retention, loss/reacquisition and timing. A blank/NA reacquisition field means a recorded loss did not reacquire within that run—not zero delay.

## AI model health

AI mode uses `beacon_logistic_v1.json`, a small logistic classifier. It ranks observable image-candidate features and continuity; it does not use runtime ground truth and does not control pan/tilt directly. If model health fails, do not present the run as AI-assisted. Check that the model file exists and launch from repository root.

## Common errors and safe shutdown

| Symptom | Action |
|---|---|
| `No module named tkinter` | Install/enable Tkinter for the active Python, then re-run `python -m tkinter`. |
| Model missing/unhealthy | Restore `assets/models/beacon_logistic_v1.json`; launch from repository root. |
| Export error | Choose a writable folder/location and confirm `exports/` can be created. |
| Invalid setting/operator dialog | Reset; use valid numeric configuration through the supplied controls. |
| Run appears finished | A preset is finite (application defaults to 12 s); press Reset then Start. |

Use **Stop** or wait for completion before closing. Export any desired evidence, then close the window. This release does not operate a webcam or physical servo.
