"""Typed UI-facing composition layer; core algorithms remain unchanged."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping

from core.ai import AIAssistedBeaconDetector, AIDetectorConfig
from core.benchmarking import AlgorithmMode, BenchmarkRunner, scenario_preset
from core.camera import PinholeCamera
from core.contracts.control import ControlInput
from core.contracts.tracking import TrackingInput, TrackingStatus
from core.control import ControllerConfig, PIDController, ProportionalController, apply_tracking_command
from core.disturbances import DisturbanceEngine
from core.perception import BeaconDetector, BeaconDetectorConfig
from core.simulation import LifecycleStatus, SimulationEngine, validate_experiment_config
from core.tracking import KalmanTracker, ReactiveTracker, TrackingConfig


class ApplicationState(str, Enum):
    IDLE="IDLE"; SEARCHING="SEARCHING"; ACQUIRING="ACQUIRING"; TRACKING="TRACKING"; LOCKED="LOCKED"
    LOST="LOST"; REACQUIRING="REACQUIRING"; STOPPED="STOPPED"; FAULTED="FAULTED"

PRESETS = {"Clean Tracking":"clean", "Vibration":"vibration", "Turbulence + Noise":"turbulence_noise",
           "False Bright Objects":"false_bright_objects", "Temporary Occlusion":"temporary_occlusion", "Combined Stress":"combined_stress"}
REPOSITORY_ROOT = Path(__file__).resolve().parent.parent
MODEL_PATH = REPOSITORY_ROOT / "assets" / "models" / "beacon_logistic_v1.json"

@dataclass(frozen=True, slots=True)
class RuntimeSnapshot:
    state: ApplicationState; frame: Any | None; truth: Any | None; detections: tuple[Any, ...]
    tracking: Any | None; camera_state: Any | None; active_disturbances: tuple[str, ...]
    telemetry: Mapping[str, Any]; events: tuple[Any, ...]; model_health: Mapping[str, Any] | None; error: str | None

class ApplicationController:
    """Owns experiment lifecycle and translates public core outputs for a UI."""
    def __init__(self, *, preset: str="Clean Tracking", mode: AlgorithmMode=AlgorithmMode.CLASSICAL_ADVANCED) -> None:
        self.preset_name, self.mode = preset, mode; self._events=[]; self._history=[]; self._error=None; self._last=None
        self._build()

    def _build(self) -> None:
        self.config = scenario_preset(PRESETS[self.preset_name], duration_s=12.0)
        self.engine = SimulationEngine(validate_experiment_config(self.config))
        from core.benchmarking.runner import _camera_state
        self.camera=PinholeCamera(_camera_state(self.config)); self.disturbance=DisturbanceEngine.from_experiment(self.config)
        self._make_pipeline(); self.state=ApplicationState.IDLE; self._events=[]; self._history=[]; self._last=None; self._error=None; self._hits=0; self._was_lost=False

    def _make_pipeline(self) -> None:
        if self.mode is AlgorithmMode.BASELINE:
            self.detector=BeaconDetector(BeaconDetectorConfig(intensity_threshold=100,min_area_px=2,min_mean_intensity=100)); self.tracker=ReactiveTracker(TrackingConfig(gating_radius_px=55)); self.controller=ProportionalController(ControllerConfig(kp_pan=1.2,kp_tilt=1.2,max_pan_rate_radps=.5,max_tilt_rate_radps=.5))
        elif self.mode is AlgorithmMode.CLASSICAL_ADVANCED:
            self.detector=BeaconDetector(BeaconDetectorConfig(intensity_threshold=100,min_area_px=2,min_mean_intensity=100)); self.tracker=KalmanTracker(TrackingConfig(gating_radius_px=55)); self.controller=PIDController(ControllerConfig(kp_pan=1.2,kp_tilt=1.2,ki_pan=.03,ki_tilt=.03,kd_pan=.01,kd_tilt=.01,max_pan_rate_radps=.5,max_tilt_rate_radps=.5))
        else:
            self.detector=AIAssistedBeaconDetector(AIDetectorConfig(model_path=str(MODEL_PATH),threshold=.2)); self.tracker=KalmanTracker(TrackingConfig(gating_radius_px=55)); self.controller=PIDController(ControllerConfig(kp_pan=1.2,kp_tilt=1.2,ki_pan=.03,ki_tilt=.03,kd_pan=.01,kd_tilt=.01,max_pan_rate_radps=.5,max_tilt_rate_radps=.5))

    def select_preset(self, name: str) -> None:
        if name not in PRESETS: raise ValueError(f"unknown preset: {name}")
        self.preset_name=name; self._build()
    def select_algorithm(self, mode: AlgorithmMode) -> None:
        self.mode=AlgorithmMode(mode); self._build()
    def set_disturbance(self, name: str, *, enabled: bool, severity: float=1.0) -> None:
        if name not in self.disturbance.ORDER: raise ValueError(f"unsupported disturbance: {name}")
        entry=dict(self.config["disturbances"].get(name,{})); entry.update(enabled=enabled,severity=max(0,min(1,float(severity))))
        self.config["disturbances"][name]=entry; self.disturbance=DisturbanceEngine.from_experiment(self.config)
        self._events.append(self._event("DISTURBANCE_CHANGED", {"disturbance":name,"active":enabled}))
    def _event(self, kind: str, payload: Mapping[str,Any]) -> dict[str,Any]:
        return {"event_id":f"app-{len(self._events)+1:06d}","t_sim_s":self.engine.snapshot().context.t_sim_s,"severity":"INFO","type":kind,"target_id":None,"payload":dict(payload)}
    def start(self) -> None:
        if self.engine.status is LifecycleStatus.PAUSED: self.engine.resume()
        elif self.engine.status is LifecycleStatus.IDLE: self._events.extend(self.engine.start())
        else: raise RuntimeError("start is valid only from IDLE or PAUSED")
        self.state=ApplicationState.SEARCHING
    def pause(self) -> None: self.engine.pause()
    def stop(self) -> None:
        self._events.extend(self.engine.stop()); self.state=ApplicationState.STOPPED
    def reset(self) -> None: self._build()
    def tick(self) -> RuntimeSnapshot:
        if self.engine.status is not LifecycleStatus.RUNNING: return self.snapshot()
        try:
            snap=self.engine.snapshot(); started=perf_counter(); sample=self.disturbance.process(self.camera,snap)
            detections=self.detector.process(sample.frame); tracking=self.tracker.process(TrackingInput(sample.frame.frame_id,sample.frame.t_sim_s,detections,sample.frame.camera_state))
            command=self.controller.process(ControlInput(tracking,sample.frame.camera_state)); apply_tracking_command(self.camera,command,snap.context.simulation_dt_s)
            self._events.extend(sample.events)
            self._translate(tracking, sample)
            self._history.append({"t":tracking.t_sim_s,"error":None if tracking.error_px is None else (tracking.error_px[0]**2+tracking.error_px[1]**2)**.5,"pan":self.camera.state.pan_rad,"tilt":self.camera.state.tilt_rad,"latency_ms":(perf_counter()-started)*1000})
            self._last=(sample.frame,sample.ground_truth,detections,tracking,sample.active,(perf_counter()-started)*1000)
            _, events=self.engine.step(); self._events.extend(events)
            if self.engine.status is LifecycleStatus.COMPLETED: self.state=ApplicationState.STOPPED
        except Exception as exc:
            self._error=str(exc); self.state=ApplicationState.FAULTED
            self._events.extend(self.engine.fault(str(exc)))
        return self.snapshot()
    def _translate(self, tr: Any, sample: Any) -> None:
        previous=self.state
        if tr.status is TrackingStatus.LOST:
            self.state=ApplicationState.LOST
            if previous is not ApplicationState.LOST: self._events.append(self._event("LOCK_LOST",{}))
        elif tr.measured:
            self._hits+=1
            if self._was_lost: self.state=ApplicationState.REACQUIRING; self._events.append(self._event("REACQUIRED",{})); self._was_lost=False
            elif self._hits==1: self.state=ApplicationState.ACQUIRING; self._events.append(self._event("TARGET_ACQUIRED",{}))
            elif self._hits>=3:
                self.state=ApplicationState.LOCKED
                if previous is not ApplicationState.LOCKED: self._events.append(self._event("LOCK_ENTERED",{}))
            else: self.state=ApplicationState.TRACKING
        if self.state is ApplicationState.LOST: self._was_lost=True
    def snapshot(self) -> RuntimeSnapshot:
        frame=truth=dets=tr=None; active=(); latency=None
        if self._last: frame,truth,dets,tr,active,latency=self._last
        health=self.detector.health() if hasattr(self.detector,"health") else None
        tele={"confidence":None if tr is None else tr.confidence,"estimated":None if tr is None else tr.estimated_center_px,"error":None if tr is None else tr.error_px,"pan":self.camera.state.pan_rad,"tilt":self.camera.state.tilt_rad,"latency_ms":latency,"fps":None if not self._history else len(self._history)/max(.001,self._history[-1]["t"]+self.config["simulation_dt_s"]),"detector":self.detector.detector_id,"tracker":None if tr is None else tr.status.value,"controller":self.controller.controller_id}
        return RuntimeSnapshot(self.state,frame,truth,tuple(dets or ()),tr,self.camera.state,tuple(active),tele,tuple(self._events[-100:]),health,self._error)
    @property
    def history(self): return tuple(self._history)
    def run_benchmark(self, *, trials: int=1) -> list[Any]:
        base=scenario_preset(PRESETS[self.preset_name],seed=self.config["seed"],duration_s=self.config["duration_s"])
        return BenchmarkRunner().compare(base,list(AlgorithmMode),scenario=PRESETS[self.preset_name],seeds=range(base["seed"],base["seed"]+trials))
    def export(self, directory: str|Path="exports") -> tuple[Path,Path]:
        runner=BenchmarkRunner(); result=runner.run(deepcopy(self.config),self.mode,scenario=PRESETS[self.preset_name]); return runner.export(result,directory,stem="application_run")
