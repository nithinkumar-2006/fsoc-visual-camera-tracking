# Pan/Tilt Control Specification

## Scope and interface

`core.control` closes the coarse-alignment loop using only `ControlInput`, which pairs Role #6 `TrackingOutput` with the corresponding `CameraState`. It exposes interchangeable `ProportionalController` and `PIDController` implementations with `reset(config)`, `process(input)`, `snapshot()`, and `health()`.

`process` returns canonical `TrackingCommand`: frame/time association, target ID, control mode, pan/tilt rate requests, source ID, saturation flags, and whether the estimate was measured. `apply_tracking_command(camera, command, dt_s)` routes the request through `PinholeCamera.apply_rate_request`; the camera remains the final authority for mechanical limits.

## Coordinates, normalization, and signs

Tracking supplies `error_px = (e_u, e_v)` relative to the image principal point. Error is normalized by half the active image dimensions, so gains are resolution independent:

`x = e_u / ((W-1)/2)`, `y = e_v / ((H-1)/2)`.

Positive pan rotates the camera right and positive tilt rotates it upward. Therefore command signs are `pan = +f(x)` and `tilt = -f(y)`: target right gives positive pan; left gives negative pan; below gives negative tilt; above gives positive tilt.

## Controllers

The proportional controller requests `Kp_pan*x` and `-Kp_tilt*y`. The PID controller independently uses:

`pan = Kp_pan*x + Ki_pan*∫xdt + Kd_pan*dx/dt`

`tilt = -(Kp_tilt*y + Ki_tilt*∫ydt + Kd_tilt*dy/dt)`.

All time evolution uses `t_sim_s`; wall time is never used. Non-positive time deltas produce no integral or derivative update. PID uses conditional integration anti-windup: a candidate integral is retained only when unsaturated or when it would unwind output toward the permitted range.

## Safety policy

Deadbands independently zero small horizontal/vertical errors. Controller outputs saturate at their configured max pan/tilt rates; the virtual camera additionally clamps rate and pose using its own limits.

Fresh measured estimates use normal gain. `COASTING` predictions use `coast_gain_scale` (default 0.35) and are labelled `COAST`. `LOST`, missing estimates, or missing error produce a neutral `NO_TRACK` command; stale error is not integrated and PID integrals reset by default. Search/reacquisition remains an extension point outside this module.

## Truth isolation and extensions

No control API imports or accepts target/world/projection truth. Ground truth is used only in integration-test assertions. New controllers can implement the same four-method interface while emitting `TrackingCommand` and preserving camera-side application.
