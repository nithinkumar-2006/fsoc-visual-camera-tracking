# Simulation Handoff

Implemented now:

- Fixed-step deterministic lifecycle in `core/simulation/engine.py`.
- Canonical simulation DTOs in `core/contracts/simulation.py`.
- Multi-target truth generation, trajectories, visibility schedules, designated-beacon validation and seed-controlled random motion in `core/targets/generator.py`.
- Contract-focused tests in `tests/unit/test_simulation_engine.py`.

Run tests from the repository root:

```bash
python -m unittest discover -v
```

Consume `SimulationEngine.snapshot()` and `SimulationEngine.step()`; use only the immutable `SimulationSnapshot`, `FrameContext`, `TargetTruth`, `Event`, and `ExperimentConfig` models. The camera layer must not mutate target truth or use `designated`/`visible_truth` as a perception shortcut. `visible_truth` means the configured beacon emission schedule only. Camera projection decides geometric FOV, and the Disturbance Engine owns sensor occlusion.

The configuration is validated before engine construction and is held immutable by the engine for the run. Add future trajectory types behind the `Trajectory` interface and factory; do not change the fixed-step clock or canonical world units.
