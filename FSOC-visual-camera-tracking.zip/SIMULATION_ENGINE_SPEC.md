# Simulation Engine Specification

## Scope

`core/simulation/` owns a deterministic, fixed-step scenario clock and run lifecycle. `core/targets/` owns target/beacon kinematics and visibility truth. The implementation follows the authoritative V2 coordinate system: right-handed world axes are X east/right, Y north/forward, Z up; position, velocity and acceleration use m, m/s and m/s².

It deliberately does not project targets into a camera frame, render imagery, detect a target, modify camera pose, create disturbances, control pan/tilt, or calculate tracking metrics.

## Public interface

```python
config = validate_experiment_config(mapping)       # -> ExperimentConfig
engine = SimulationEngine(config)
events = engine.start()
snapshot, events = engine.step()                   # exactly one simulation_dt_s
engine.pause(); engine.resume(); engine.stop(); engine.reset()
snapshot = engine.snapshot()
```

`SimulationSnapshot` is immutable and contains `status`, `FrameContext`, immutable `TargetTruth` values, and `WorldEnvironment`. `FrameContext.frame_id` and `tick_id` begin at zero and identify the fixed simulation tick. The engine provides no API for consumers to mutate its world state.

Simulation-owned events use the canonical `{event_id, t_sim_s, severity, type, target_id, payload}` shape. This module emits `RUN_STARTED` and `RUN_STOPPED`; completion is represented by `RUN_STOPPED` with `reason=duration_completed`. It never emits acquisition, lock, FOV or occlusion events.

## Configuration

The entry point accepts the canonical top-level `ExperimentConfig` keys from V2 and rejects unknown top-level fields. Required non-simulation sections are retained verbatim but do not affect simulation behavior. Simulation-specific target fields are validated strictly. `duration_s` must be an integral multiple of `simulation_dt_s`, ensuring every physics update is a fixed step.

Each target requires `target_id` and `position_w_m`; it may set `velocity_w_mps`, `acceleration_w_mps2`, `emission`, `designated`, `trajectory`, and `visibility`. Exactly one target must be designated. Visibility intervals are half-open `[start_s, end_s)` overrides of `default_enabled`; they model beacon emission/truth visibility only, not camera FOV or sensor occlusion.

## Trajectory models and extension point

- `stationary`: fixed position and zero derivatives.
- `linear`: `p=p0+v0t`.
- `accelerated`: `p=p0+v0t+½at²`.
- `sinusoidal`: amplitude, frequency, phase, and normalized world motion axis.
- `random`: a fixed-step seeded random-acceleration walk with a bounded speed.
- `sudden_maneuver`: piecewise accelerated motion with time-ordered `at_s` changes to velocity and/or acceleration.

To add a trajectory, implement `Trajectory.reset()` and `Trajectory.state_at(t_sim_s)`, then register it in `_target_from_config`. No SimulationEngine change is required.

## Determinism

There is no wall-clock dependency and no global random usage. Random target motion derives a private RNG seed as SHA-256 of `"{experiment.seed}:targets:{target_id}"`; target IDs are stable within a run. Reset recreates the RNG and therefore supports exact replay. Equal config, seed and tick sequence yield equal truth states; changing the experiment seed changes random trajectories.

## Virtual Camera integration

The Virtual Camera engineer should consume `engine.snapshot()` after each `step()` and use `snapshot.context.t_sim_s`, `snapshot.context.frame_id`, `snapshot.targets`, and its own camera state. It must determine geometric FOV and projection itself; `TargetTruth.visible_truth` must not be treated as FOV visibility or detector output. It may read the immutable `WorldEnvironment` only as a lightweight scene/background hook.
