# Judge Q&A

**What problem are you solving?** Coarse pointing, acquisition and tracking of a moving optical beacon before fine alignment in mobile FSOC concepts.

**Why coarse alignment?** A narrow optical link needs the counterpart beacon inside the camera field of view before a fine-pointing stage can take over.

**Why a virtual camera?** It enables repeatable, low-cost algorithm testing before buying and integrating camera, servo and optical hardware.

**Where is the AI? Is it really AI?** `ai-logistic-reid-v1` is a trained lightweight logistic beacon-candidate classifier/re-identification aid. It scores image-derived candidate features and continuity. It is trained ML, but it is not generative AI, an LLM or autonomous control.

**Why not only PID? Why Kalman?** PID turns image-centre error into bounded camera commands. Kalman estimates/predicts the target state and helps association through noisy observations or short gaps; they solve different tasks.

**What if an object blocks Alice and Bob?** The occlusion disturbance hides the beacon from the virtual sensor. The pipeline can lose lock, search, and reacquire on a later valid detection. It does not claim communication through an optical blockage.

**What if another bright object appears?** False bright objects create real image candidates. The tracker gates associations; AI mode additionally scores visual candidates and continuity. Neither claim guarantees every real-world distractor is solved.

**Which disturbances are modeled?** Platform vibration, external camera/platform motion, sensor noise, motion blur, temporary occlusion, false bright objects and turbulence-like image effects. These are test disturbances, not a full atmospheric-channel model.

**How is the comparison fair?** Each mode receives the same scenario, initial conditions, duration, target trajectory, seed and disturbance schedule. Deterministic seeding makes it replayable.

**What is ground truth? Does the tracker use it?** It is the simulator’s known beacon geometry/projected image location. It joins telemetry only after tracker output for scoring. Runtime detector, AI, tracker and controller do not receive it.

**What metrics are measured?** Simulation duration, configured/effective FPS, acquisition time, average/RMS/maximum paired tracking error, horizontal/vertical alignment error, lock retention, loss count, reacquisition time and processing statistics.

**What is lock retention?** Locked valid frames divided by geometrically visible frames. It includes the impact of sensor-level occlusion/detection failure.

**What do the benchmark numbers prove?** They compare these implementations under these deterministic simulator conditions. They do not prove physical FSOC throughput, range, availability or field reliability.

**Where would this sit in real FSOC development?** Early PAT algorithm development and test-case validation, followed by hardware-in-the-loop, calibrated camera/servo tests and then optical-link trials.

**Can Bob send data back to Alice? Does this simulate communication data?** A real FSOC system can be designed for bidirectional communication, but this release simulates beacon tracking only. It does not model message traffic or a completed optical communication link.

**Is it hardware ready?** No. Webcam input, physical servo output and optical-link validation are not verified here.

**How would you move to a real terminal?** Add a calibrated camera adapter, synchronize camera frames and pan/tilt feedback, validate safety/limits, characterize disturbances against measurements, then test the optical link and fine-pointing stage.

**Why not buy hardware immediately?** Hardware is valuable later, but it makes repeatable fault injection and fair algorithm comparison harder and more expensive. This platform reduces that early iteration cost.

**What if AI fails? Can it work without AI?** The two classical modes remain supported. AI model health is visible; a failed model must not be presented as an AI result.

**What was tested?** Unit and integration tests cover simulation, camera, disturbances, detection, tracking, control, benchmarking, AI model handling, application lifecycle and configuration boundaries. Final regression: 63 passed, 0 failures/errors/skips.

**What defect did QA find?** QA-001: invalid camera/FOV, seed and disturbance schedule/severity configuration could pass validation and fail later or be silently clamped. Validation was tightened and two regression tests added; algorithms and metrics were unchanged.

**What are the current limitations and next step?** It is simulation-only; GUI needs a human visual check on the demo laptop; no packaged executable/webcam/servo validation. Next: hardware-in-the-loop and physical optical validation.
