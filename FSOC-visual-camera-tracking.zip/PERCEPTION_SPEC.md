# Perception / Beacon Detection Specification

## Scope and truth isolation

`core/perception/` accepts only `CameraFrame` plus `BeaconDetectorConfig`. It never imports simulation, target-generation, or ground-truth modules. It never receives a target ID, designated flag, world coordinates, trajectory, projected truth, or image-center truth. The baseline emits `target_id=None`; association is explicitly Role #6 work.

## Pipeline

`BeaconDetector` validates the row-major 8-bit grayscale buffer, thresholds pixels at a configurable intensity, extracts 8-connected bright regions, filters each component, then produces one canonical `DetectionResult` per remaining region.

- Filters: minimum/maximum area, minimum peak intensity, minimum mean intensity, and bounding-box fill ratio (compactness).
- Bounding box: inclusive extrema of thresholded component pixels, expressed as `[x, y, width, height]` and inherently image clipped.
- Centre: intensity-weighted component centroid, giving subpixel coordinates derived only from pixels.
- Confidence: bounded `[0,1]` blend of peak/mean intensity quality and component fill ratio; it contains no truth-derived value.

## Output and edge/no-detection behaviour

`process(frame) -> tuple[DetectionResult, ...]`. Results are sorted by descending observable confidence, then top-to-bottom/left-to-right to give stable deterministic ordering. Empty/dark/below-threshold frames return `()`. No stale or fabricated coordinate is returned. Edge components remain valid because extraction is bounded to the image array.

`DetectionResult` is the canonical shared DTO in `core/contracts/perception.py`: frame/time mirror the input frame; `detector_id` is `centroid-threshold-v1`; `target_id` is `None`; bbox and centroid are pixel observations; `processing_ms` is wall-clock profiling only and cannot affect simulation time.

## Interface and performance

The interchangeable detector shape is `reset(config)`, `process(camera_frame)`, `snapshot()`, and `health()`. The implementation uses a single image scan plus each foreground pixel once in connected-component traversal, requires no OpenCV/ML dependency, and maintains only lightweight health counters.

## Extension path

An improved CV or AI-assisted detector can implement the same interface and return the same `DetectionResult` tuple. It may improve candidate classification/re-identification from pixels but must preserve the truth-isolation boundary and leave target association to tracking.
