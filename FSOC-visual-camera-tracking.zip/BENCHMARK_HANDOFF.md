# Role #10 Benchmark Handoff

Run one deterministic experiment:

```python
from core.benchmarking import BenchmarkRunner, AlgorithmMode, scenario_preset
runner = BenchmarkRunner()
result = runner.run(scenario_preset("clean", seed=17), AlgorithmMode.AI_ASSISTED, scenario="clean")
runner.export(result, "exports", stem="run_001")
```

Run a fair comparison:

```python
results = runner.compare(scenario_preset("combined_stress", seed=17), list(AlgorithmMode), scenario="combined_stress", seeds=[17, 18])
runner.export_comparison(results, "exports/comparison.csv")
```

The telemetry CSV gives frame/time, algorithm IDs, estimated and truth image positions, benchmark/control errors, pose, tracker state, disturbances, and per-stage timings. The summary JSON gives acquisition, error aggregates, lock/loss/reacquisition, FPS, and latency statistics.

GUI consumers should display report metrics and charts from exports; they must label truth overlays/evaluation clearly and must never wire truth into the selected runtime algorithm. Run all checks with `python -m unittest discover -v`.
