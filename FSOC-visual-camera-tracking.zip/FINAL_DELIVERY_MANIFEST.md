# Final Delivery Manifest

## Release identity

| Item | Verified value |
|---|---|
| Final archive | `ROLE_14_FINAL_SIH.zip` |
| Project | AI-Assisted Virtual Camera Tracking for Coarse Alignment of Mobile FSOC Terminals |
| Verified launch command | `python -m gui.desktop` (from repository root) |
| Runtime requirement | Python 3.11+ with Tkinter; core runtime has no third-party dependency |
| Final regression | `python -m unittest discover -v` — 63 passed, 0 failures, 0 errors, 0 skipped |
| AI model | `assets/models/beacon_logistic_v1.json` |

## Supported algorithm modes

| Identifier | Composition |
|---|---|
| `classical-reactive-proportional` | Classical detector + reactive tracker + proportional controller |
| `classical-kalman-pid` | Classical detector + Kalman tracker + PID controller |
| `ai-kalman-pid` | AI detector + Kalman tracker + PID controller |

## Supported scenarios

Clean Tracking; Vibration; Turbulence + Noise; False Bright Objects; Temporary Occlusion; Combined Stress.

## Final documentation index

SIH-facing documentation is available under `docs/final/`:

- `TECHNICAL_REPORT.md` — architecture, methods, results and limitations
- `USER_MANUAL.md` — operation and troubleshooting
- `INSTALLATION_GUIDE.md` — verified setup and launch
- `SIH_DEMO_SCRIPT.md` — 3–5 minute presentation flow
- `JUDGE_QA.md` — accurate judge answers
- `ARCHITECTURE_DIAGRAM.md` — runtime/truth boundary
- `FINAL_DEMO_FLOW.md` — demo-state flow
- `RESULTS_SUMMARY.md` — evidence-backed results
- `FINAL_RELEASE_CHECKLIST.md` — judge-day checks
- `FINAL_DELIVERY_MANIFEST.md` — this manifest

The root `README.md` remains the repository landing page.

## Benchmark and QA evidence

- `BENCHMARK_COMPARISON.csv`
- `BENCHMARK_SAMPLE_REPORT.json`
- `BENCHMARK_SAMPLE_TELEMETRY.csv`
- `exports/application_comparison.csv`
- `exports/application_run_REPORT.json`
- `exports/application_run_TELEMETRY.csv`
- `AI_EVALUATION_REPORT.md`
- `QA_REPORT.md`, `QA_TEST_PLAN.md`, `QA_DEFECT_LOG.csv`, `QA_RELEASE_CHECKLIST.md`, `QA_FINAL_REGRESSION.txt`

## Known limitations

- Software simulation validation only; not physical FSOC link performance.
- Webcam input and physical pan/tilt servo output are not validated.
- The GUI requires a human visual check on the actual demonstration laptop.
- No packaged executable is included or verified; Python/Tkinter is the supported launch path.
- The system simulates tracking/alignment, not FSOC communication payload transfer or fine pointing.
