# Virtual Camera Specification

## Ownership and inputs

`core/camera/` converts an immutable Role #3 `SimulationSnapshot` into a grayscale `CameraFrame` and separately returns a `GroundTruthFrame`. It reads `snapshot.context.frame_id` and `snapshot.context.t_sim_s` directly; it creates no clock and never changes target truth or trajectories.

## Coordinates and projection

World axes are `(X east/right, Y north/forward, Z up)`. The camera frame is `(X right, Y down, Z forward)`. At pan and tilt zero, the optical axis is world `+Y`, image right is `+X`, and image down is `-Z`.

For pan `p`, tilt `q`, camera position `C`, and world target `P`, define `d=P-C` and these world-unit axes:

`right=(cos p,-sin p,0)`

`forward=(sin p cos q, cos p cos q, sin q)`

`up=(-sin p sin q,-cos p sin q,cos q)`

Camera coordinates are `x=d·right`, `y=-d·up`, and `z=d·forward`. Thus positive pan turns the optical axis right and positive tilt turns it upward.

For width `W`, height `H`, full FOVs `hfov` and `vfov`, intrinsics are `fx=W/(2 tan(hfov/2))`, `fy=H/(2 tan(vfov/2))`, and principal point `(u0,v0)=((W-1)/2,(H-1)/2)`. Projection is `u=u0+fx*x/z`, `v=v0+fy*y/z`.

## FOV, truth, and image formation

A target has `in_geometric_fov=True` exactly when `z>0` and its projected point is in `[0,W) × [0,H)`. This is independent of emission, configured visibility, sensor occlusion, and detector success. Every target receives a `ProjectedTargetTruth`; points outside FOV have `None` image center and box. `occluded` is currently always false.

The frame is a row-major 8-bit grayscale `bytes` payload. Geometrically visible targets with `visible_truth=True` and positive emission render as a compact radial bright spot. This respects the configured beacon emission schedule without leaking it as metadata. No designated flag, IDs, world points, boxes, or truth centers appear in `CameraFrame`; they exist only in `GroundTruthFrame`.

## State, mechanics, and extension hooks

`CameraState` uses the canonical names and radians. `set_state` accepts an absolute pose and clamps it to `CameraLimits`. `apply_rate_request(pan_rate_cmd_radps, tilt_rate_cmd_radps, dt_s)` accepts the rate-style request used by the architecture's `TrackingCommand`, clamps rates and resulting pose, and implements no control law.

Future disturbance code can supply an altered camera state before `observe`, transform the returned image bytes, or decide not to render a beacon while leaving `GroundTruthFrame` unchanged. This module does not implement those effects.
