# Role #13 Judge-Day Release Checklist

## Before the demo

- [ ] Use Python 3.11+ with Tkinter installed (`python -c "import tkinter"`).
- [ ] Confirm `assets/models/beacon_logistic_v1.json` is present and readable.
- [ ] From the repository root, launch `python -m gui.desktop`.
- [ ] Use a 1920×1080 display where possible; confirm the viewport, command bar, rails, and event log are visible.
- [ ] Ensure the chosen export directory is writable.

## Demonstration sequence

- [ ] Select **Clean Tracking**, start, and show acquire/lock and finite pan/tilt telemetry.
- [ ] Select **Temporary Occlusion**, start, and show occlusion, loss, and reacquisition.
- [ ] Select **ai-kalman-pid** and confirm model health shows loaded.
- [ ] Run Benchmark and show the real comparison CSV under `exports/`.
- [ ] Export Results and confirm the paired JSON report and telemetry CSV.
- [ ] Reset and confirm time, event history and state return to their initial state.

## Fallback plan

If Tkinter is unavailable, run the deterministic benchmark through Python and present the included exports/reports. The prototype is a software-first virtual-camera demonstration; do not claim that it validates a physical FSOC link, webcam, or servo hardware.
