# Perception Handoff for Role #6

Perception lives in `core/perception/beacon_detector.py`. Create `BeaconDetector` (optionally with `BeaconDetectorConfig`) and call it only with the Role #4 image:

```python
camera_frame, _ground_truth = camera.observe(engine.snapshot())
detections = detector.process(camera_frame)
```

`detections` is `tuple[DetectionResult, ...]`, one image candidate per bright component. Each result has canonical `frame_id`, `t_sim_s`, `detector_id`, `target_id`, `bbox_xywh_px`, `center_px`, `confidence`, `processing_ms`, and `status`. For this classical detector `target_id` is always `None`: Role #6 may use only the detection fields, its own prior state, and permitted camera-state data to associate/select a track. Do not use `GroundTruthFrame` in tracker runtime.

Results are deterministically ordered by descending confidence, then top-to-bottom and left-to-right. Confidence is an observable image-quality score from intensity and compactness, bounded `[0,1]`; it is not an identity probability. An empty tuple means no candidate was detected; it does not imply a coordinate at `(0,0)`.

The detector accepts the Role #4 row-major grayscale image, performs no physics or clock changes, and reports wall-clock `processing_ms` solely for profiling. Its `reset(config)`, `snapshot()`, and `health()` methods support pipeline lifecycle checks.

Run the complete suite from repository root:

```bash
python -m unittest discover -v
```
