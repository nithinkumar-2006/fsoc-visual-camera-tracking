# AI-Assisted Candidate Evaluation

## Protocol

The bundled model was trained with simulator seeds 11–14 and evaluated on held-out seeds 71–74. Each seed has a different deterministic false-object sequence and sensor-noise realization. Every evaluated frame contains the same rendered image for both methods: sensor noise plus two false bright objects. Offline truth was used only to score the results.

Classical baseline is `centroid-threshold-v1` (first, confidence-sorted candidate). AI is `ai-logistic-reid-v1` (trained visual likelihood plus observable continuity). Candidate labels use a 4.5 px centre-match threshold only during evaluation.

## Results

| Metric | Classical | AI-assisted |
|---|---:|---:|
| Held-out frames | 40 | 40 |
| Correct beacon selection | 39 / 40 (97.5%) | 40 / 40 (100.0%) |
| Candidate precision | not a binary classifier | 1.000 (40 TP, 0 FP) |
| Candidate recall | not a binary classifier | 1.000 (40 TP, 0 FN) |
| Candidate classification accuracy | not a binary classifier | 1.000 (119 candidates) |

These values are intentionally limited to the simulator distribution and should not be treated as real-camera performance. The small 1-frame selection improvement is reported without tuning the held-out seeds.

## Closed-loop evidence

`test_ai_kalman_pid_closed_loop` runs simulator → disturbances → actual saved-model inference → existing Kalman tracker → existing PID → camera update for 2 s. It verifies finite errors and convergence while using no runtime truth input.
