# Results Summary

> **SIMULATION RESULTS — NOT PHYSICAL FSOC LINK PERFORMANCE.**

## Recorded fair comparison

Source: `BENCHMARK_COMPARISON.csv`. All rows use scenario `combined_stress`, seed `17`, duration `3.0 s`, `0.05 s` fixed step (60 frames), and identical beacon/camera/disturbance configuration.

| Configuration | Avg. tracking error (px) | RMS (px) | Max (px) | Lock retention | Losses | Avg. reacquisition | Effective FPS | Mean pipeline latency |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Classical detector + reactive + proportional | 16.306 | 45.775 | 208.678 | 76.67% | 2 | 0.200 s | 75.76 | 13.169 ms |
| Classical detector + Kalman + PID | 4.807 | 9.741 | 35.501 | 88.33% | 1 | NA (unrecovered) | 75.46 | 13.212 ms |
| AI detector + Kalman + PID | 0.602 | 0.735 | 1.940 | 83.33% | 1 | 0.300 s | 74.45 | 13.402 ms |

All three acquired at `0.0 s`. “NA” is correctly retained where a loss was not reacquired within the 3 s run. Tracking error is estimated image centre versus projected ground-truth centre; it is different from the controller’s image-centre alignment error.

## Disturbance observations

| Evidence | Scenario/configuration | Observation |
|---|---|---|
| Sample report | Combined Stress, seed 17, AI/Kalman/PID, 3.0 s | One loss at 1.5 s; reacquired in 0.300 s; 57 valid paired frames of 60. |
| Application export | Temporary Occlusion, seed 17, Classical/Kalman/PID, 12.0 s | Occlusion 0.9–1.4 s; one loss; reacquired in 0.500 s; 94.17% lock retention. |
| AI evaluation | Held-out simulator seeds 71–74; noisy frames + two false objects | 40/40 correct beacon selections for AI versus 39/40 for classical. This is a small, simulator-distribution evaluation only. |

## QA and long run

| Check | Recorded evidence |
|---|---|
| Final regression | 63 passed, 0 failures, 0 errors, 0 skipped (`python -m unittest discover -v`) |
| Baseline before QA fix | 61 passed, 0 failures, 0 errors, 0 skipped |
| Soak | AI/Kalman/PID, Combined Stress, seed 59, 60.0 simulated s / 1,200 frames: 1 loss, mean 0.305 px, max 1.387 px, 50.69 effective FPS. |

QA-001 was a configuration-boundary defect: invalid camera/FOV, seed and disturbance values were accepted too far into execution. Validation was tightened; no algorithm, model, metric or disturbance formula changed.
