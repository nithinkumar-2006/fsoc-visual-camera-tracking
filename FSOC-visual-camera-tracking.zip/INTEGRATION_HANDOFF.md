# Role #12 Integration Handoff

## Launch

From any directory, run from the repository root:

```bash
python -m gui.desktop
```

Requirements: Python 3.11+ with Tkinter. The project is offline and uses only the Python standard library.

## Test

```bash
python -m unittest discover -v
```

The release contains 61 tests: existing unit/regression coverage plus `tests/integration/test_system_integration.py`.

## Judge demonstration

1. Start with **Clean Tracking** and `classical-kalman-pid`.
2. Use **Temporary Occlusion** or **Combined Stress**, reset, then start to show loss/reacquisition.
3. Select `ai-kalman-pid`; model health must show loaded.
4. Run Benchmark and export results.

Expected outputs are `<stem>_REPORT.json`, `<stem>_TELEMETRY.csv`, and `application_comparison.csv` under the selected export location.

## QA focus and limits

Aggressively verify GUI controls, repeated start/stop/reset, path permissions for exports, and Tkinter availability on the judge laptop. This is a deterministic simulation and benchmark; it is not validation of a physical FSOC link, webcam integration, or hardware servo control.
