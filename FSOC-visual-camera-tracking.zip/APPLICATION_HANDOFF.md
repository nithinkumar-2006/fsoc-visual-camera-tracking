# Role #11 Application Handoff

## Launch

From the repository root, use Python 3.11+:

```bash
python -m gui.desktop
```

Tkinter is included with normal Windows/macOS Python installers and most Linux Python packages. The tested core has no third-party runtime dependency.

## Controls and SIH demonstration

1. Select **Clean Tracking**, then **Start** to show acquisition, closed-loop pan/tilt correction and lock.
2. Select **Temporary Occlusion** or enable a disturbance, reset, and start to show loss/reacquisition.
3. Select `ai-kalman-pid` to show **AI-Assisted Detector** health and model-backed confidence.
4. Use **Run Benchmark** to generate a fair three-mode comparison under the selected scenario.
5. Use **Export Results** for JSON report and CSV telemetry.

Outputs are written under `exports/` from the launch directory: `application_run_REPORT.json`, `application_run_TELEMETRY.csv`, and `application_comparison.csv`.

## Tests and troubleshooting

Run all regression and Role #11 tests with:

```bash
python -m unittest discover -v
```

If the AI health panel reports the model missing, launch from the repository root so `assets/models/beacon_logistic_v1.json` resolves. Invalid controls and runtime failures appear in an operator error dialog; reset restores a clean preset configuration.
