# Installation Guide

## Verified path

Use Python **3.11 or newer** with Tkinter. The recorded repository reports Python 3.12.13; the application handoff specifies Python 3.11+. The core has no third-party runtime dependency.

1. Extract `ROLE_14_FINAL_SIH.zip` to a writable location.
2. Confirm Python: `python --version`.
3. Confirm Tkinter: `python -m tkinter` should open a small test window.
4. From the extracted repository root, launch:

```bash
python -m gui.desktop
```

The model must remain at `assets/models/beacon_logistic_v1.json`. Run from the repository root so packaged paths resolve consistently. Ensure the launch directory allows writing `exports/`; **Export Results** creates JSON and CSV files there.

For verification:

```bash
python -m unittest discover -v
```

No executable installer is provided or verified. The verified release path is Python/Tkinter.
