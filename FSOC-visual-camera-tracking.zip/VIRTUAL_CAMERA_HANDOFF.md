# Virtual Camera Handoff

Camera code is in `core/camera/model.py`; its public class is `PinholeCamera`. Camera DTOs are in `core/contracts/camera.py`.

```python
snapshot = engine.snapshot()              # Role #3 immutable snapshot
camera = PinholeCamera(initial_camera_state)
camera_frame, ground_truth = camera.observe(snapshot)
```

`camera_frame.image_gray8` is a row-major, 8-bit grayscale `bytes` image with dimensions `camera_frame.resolution_px` `(width, height)`. A CV module may reconstruct it using its preferred local image library, but must consume only `CameraFrame` for perception. Its safe metadata is frame ID, simulation timestamp, resolution, and camera pose.

`frame_id` and `t_sim_s` come exactly from the supplied snapshot's `FrameContext`; repeated calls with equal pose and snapshot create identical bytes. Projected target IDs, centers, boxes, FOV status, and occlusion truth are available only in the separately returned `GroundTruthFrame`, for benchmark/test paths.

The camera has no CV detector and does not infer target location. Use `apply_rate_request(...)` only after a later control component produces a canonical rate request.

Run all tests from the repository root:

```bash
python -m unittest discover -v
```
