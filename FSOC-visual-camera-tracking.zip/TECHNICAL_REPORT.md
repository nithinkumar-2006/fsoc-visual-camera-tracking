# AI-Assisted Virtual Camera Tracking for Coarse Alignment of Mobile FSOC Terminals

## 1. Executive Summary

This project is a software-first, standalone virtual-camera platform for the coarse Pointing, Acquisition and Tracking (PAT) stage of a mobile free-space optical communication (FSOC) concept. A deterministic moving optical beacon is rendered into a virtual pinhole camera. Classical and AI-assisted detection pipelines estimate the beacon position; tracking and constrained pan/tilt control reposition the camera; the benchmark layer measures the closed loop.

The deliverable is an algorithm-development and validation platform, not a complete FSOC communication link, a physical optical terminal, a fine-pointing system or evidence of real-world link performance. Its practical value is repeatable testing before committing to camera, servo and optical hardware.

## 2. Problem Statement and Motivation

A mobile optical terminal must bring a counterpart beacon into the camera field of view and keep it near the optical axis despite target motion and degraded observations. Physical prototypes can be costly and make controlled repeat experiments difficult. This platform provides a reproducible environment for comparing the exact same target motion and disturbances across alternative detection/tracking/control stacks.

## 3. Scope and Objectives

The objectives are to simulate a moving beacon and virtual camera; acquire/track/reacquire it; apply common observation and platform disturbances; compare three supported algorithm modes; expose a demonstrable GUI; and produce CSV/JSON evidence. The scope excludes payload communication, optical power budget, atmospheric channel validation, webcam validation, physical servo actuation and fine-pointing hardware.

## 4. System Architecture

The implemented closed loop is:

`Virtual Environment → Moving Optical Beacon → Virtual Camera → Disturbances → Beacon Detection → Position Estimation / Tracking → Pan/Tilt Controller → Virtual Camera Repositioning → Performance Measurement`

The simulation engine owns fixed-step time, scenario life cycle and seeded configuration. Target generation owns beacon kinematics. The camera owns projection, grey-scale image formation and mechanical pose limits. The disturbance engine modifies observation/camera conditions; detector, tracker and controller are separate components. The benchmark collector joins completed tracker output with truth only for scoring. The GUI calls the application composition layer rather than mutating core modules directly.

See [ARCHITECTURE_DIAGRAM.md](ARCHITECTURE_DIAGRAM.md) for the runtime and truth paths.

## 5. Coordinate and Data Conventions

World coordinates are right-handed: X east/right, Y north/forward, Z up (metres). Camera coordinates use +X image-right, +Y image-down and +Z optical-forward. Image pixels use top-left origin with `u` right and `v` down; principal point is `((W−1)/2,(H−1)/2)`. Positive pan turns right; positive tilt turns up. All public timestamps are monotonic simulation seconds (`t_sim_s`), not wall-clock time.

Camera frames carry image pixels and camera state. Detector outputs candidate boxes, centre, confidence and processing status. Tracker outputs an estimated centre/state or an honest missing estimate. Runtime components do not accept a `GroundTruthFrame`.

## 6. Simulation Environment and Moving Beacon

The repository uses validated experiment configurations with a seed, duration, fixed `simulation_dt_s`, camera, targets, disturbances, pipeline, lock policy, benchmark and export sections. The benchmark preset uses a target named `beacon` at `[2,10,0] m`, moving `[0.2,0,0] m/s`; it uses a 101×101 pixel camera with 90° horizontal and vertical FOV and a 0.05 s step. Configuration and per-module seeded randomness enable deterministic replay.

The state model supports stationary, linear, accelerated and manoeuvring target behavior in the simulation tests. A beacon is geometrically visible when in front of the camera and inside the projected image bounds; sensor occlusion is a distinct condition.

## 7. Virtual Camera and Pan/Tilt Control

The implemented camera is a pinhole model that projects visible target truth into a grey-scale synthetic frame. A virtual beacon is rendered as a bright local feature. Pan/tilt state is updated by the controller subject to configured angle/rate constraints. This is a virtual repositioning of the camera pose, not a command to a real servo.

The baseline controller is bounded proportional control. Advanced modes use PID with proportional, integral and derivative terms, anti-windup and saturation behavior tested by the regression suite. Controller input is image-centre alignment error—estimate relative to image centre—not ground-truth tracking error.

## 8. Disturbance Modelling

The disturbance engine composes platform vibration, camera/platform motion, sensor noise, motion blur, temporary occlusion, false bright objects and turbulence-like pixel effects. Vibration/camera motion affect effective pose; noise, blur and turbulence affect rendered pixels; occlusion hides the sensor-visible beacon without changing geometric truth; false spots produce candidates without becoming truth targets.

Each effect is controlled by deterministic seed, schedule and severity. This is essential for fair comparison: the same seed gives the same disturbance realization for every mode. These effects are deliberately not described as a complete physical atmospheric channel.

## 9. Classical Detection and Tracking

The classical detector segments bright connected components, calculates a clipped bounding box/centroid and produces a confidence. The reactive tracker associates candidates with a gating policy and responds directly to measured position. The Kalman tracker predicts and updates image-space state, gates associations, smooths noisy estimates and bridges short dropouts. Lifecycle states include search, acquisition, tracking/locked, lost and reacquiring.

Supported modes are intentionally limited to:

| Mode | Implemented chain |
|---|---|
| Baseline | Classical detector + reactive tracker + proportional controller |
| Classical Advanced | Classical detector + Kalman tracker + PID controller |
| AI Assisted | AI detector + Kalman tracker + PID controller |

Comparing these chains under identical conditions separates effects of candidate selection, prediction and control without changing the environment.

## 10. AI-Assisted Beacon Recognition

AI-assisted mode uses the saved `logistic-beacon-v1` model artifact (`assets/models/beacon_logistic_v1.json`). It is a lightweight deterministic logistic classifier, not a deep neural network, generative model, LLM or autonomous decision system. It extracts observable candidate features including intensity/contrast, connected-component area, fill, radial location, aspect ratio and energy; the detector adds observable continuity/re-identification scoring. It outputs candidate selection/centre/confidence. Kalman and PID remain responsible for state estimation and camera correction.

Training data is generated from simulator images. Offline labels are created in the training module; runtime inference has no truth input. The held-out simulator evaluation used train seeds 11–14 and evaluation seeds 71–74 with sensor noise and two false bright objects. It recorded 40/40 AI selections and 39/40 classical selections over 40 frames, with AI candidate precision/recall 1.000 over 119 candidates. This small, held-out simulator result must not be generalized to real-camera performance.

## 11. Application / GUI

The Tkinter desktop application launches with `python -m gui.desktop`. It presents preset and algorithm selectors; Start/Pause/Stop/Reset; virtual camera image with crosshair/detection/estimate overlays; disturbance toggles; runtime telemetry; tracking error/pose graph; event log; benchmark; and exports. A red ground-truth overlay is explicitly labelled “Evaluation / Ground Truth” and is toggleable. It should be hidden for realistic demonstrations.

The supplied presets are Clean Tracking, Vibration, Turbulence + Noise, False Bright Objects, Temporary Occlusion and Combined Stress. Application runs use a 12.0 s duration; benchmark sample evidence is a 3.0 s run unless explicitly stated otherwise.

## 12. Benchmark Methodology and Metrics

`BenchmarkRunner` executes simulation → camera → disturbances → detector → tracker → controller → camera update. It records tracker output first, then joins it to projected truth in `BenchmarkCollector`. Every compared mode uses identical initial state, trajectory, disturbances, duration and seed.

For paired frames, tracking error is `sqrt((u_est-u_truth)^2 + (v_est-v_truth)^2)` pixels. Average, RMS and maximum tracking errors use valid paired frames. Missing estimates remain null in telemetry. Controller alignment error is instead estimate relative to image centre.

Acquisition is time from `RUN_STARTED` to first estimate. Lock retention is locked valid frames divided by geometrically visible frames. A loss is a locked-to-not-locked transition; reacquisition is time from that loss to a re-acquire event. Configured FPS is frames/simulation duration, whereas effective processing FPS uses measured execution duration. Processing statistics report the separate pipeline stages.

## 13. Experimental Scenarios and Results

The recorded comparison uses **Combined Stress, seed 17, 3.0 simulation seconds, 0.05 s step, 60 frames**. It combines vibration (0.002 rad at 3 Hz), sensor noise (severity 0.12, sigma 5), turbulence (severity 0.35), one false object (severity 0.7) and an occlusion from 1.5 to 1.8 s.

| Mode | Avg/RMS/Max tracking error (px) | Lock retention | Losses | Reacquisition |
|---|---:|---:|---:|---:|
| Baseline | 16.306 / 45.775 / 208.678 | 76.67% | 2 | 0.200 s |
| Classical Advanced | 4.807 / 9.741 / 35.501 | 88.33% | 1 | NA |
| AI Assisted | 0.602 / 0.735 / 1.940 | 83.33% | 1 | 0.300 s |

All three rows acquired at 0.0 s. These are exact CSV values, not a percentage-performance claim. The separate sample report for AI Assisted records effective processing FPS 71.98 and mean pipeline timing 13.865 ms on the captured environment. An application export for Temporary Occlusion, seed 17, Classical Advanced, 12.0 s reports one 0.500 s reacquisition and 94.17% lock retention. Full context is in [RESULTS_SUMMARY.md](RESULTS_SUMMARY.md).

## 14. QA and Validation

Role #13 first established a baseline of 61 passing tests. QA found one confirmed defect, QA-001: invalid image/FOV, seed and disturbance boundary values could pass initial validation then fail later or be silently clamped. Validation now rejects invalid camera intrinsics, seed conversion, out-of-range disturbance severity and invalid schedules. No tracking algorithm, PID/Kalman behavior, model, metric or disturbance formula changed.

The inherited release candidate and this final documentation package were checked with `python -m unittest discover -v`: **63 passed, 0 failures, 0 errors, 0 skipped**. QA also recorded a 60.0 simulated-second, 1,200-frame AI/Kalman/PID Combined Stress soak (seed 59): one loss, 0.305 px mean error, 1.387 px maximum error and 50.69 effective FPS.

## 15. Limitations and Future Scope

This is software simulation validation only. It does not validate a physical optical link, link data transmission, range, webcam input, physical pan/tilt servo or fine-pointing subsystem. The final GUI needs a human visual check on the actual 1920×1080 demo laptop. A packaged executable is not included or verified; Python/Tkinter is the verified path.

Next steps are calibrated camera and actuator adapters, hardware-in-the-loop timing and safety tests, measured-disturbance characterization, optical-link experiments and a dedicated fine-pointing stage. Those steps require new evidence; they are not claimed by this release.

## 16. Conclusion

The release provides a reproducible, test-covered environment for comparing three coarse-alignment algorithm chains. Its engineering boundary is clear: truth is evaluation-only, results are simulator-specific, and the path to physical validation remains explicit. This makes the prototype appropriate for explaining and validating early PAT-algorithm choices at SIH while avoiding claims that exceed the implementation.
