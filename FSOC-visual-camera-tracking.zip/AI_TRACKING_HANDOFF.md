# AI Tracking Handoff

- Source: `core/ai/`; public detector: `AIAssistedBeaconDetector(AIDetectorConfig(...))`.
- Bundled model: `assets/models/beacon_logistic_v1.json`. Default config uses that relative path. Call `health()` after construction to inspect model loading/fallback status.
- Select classical mode with `BeaconDetector`; select AI mode with `AIAssistedBeaconDetector`. Both implement `reset`, `process(CameraFrame)`, `snapshot`, and `health`, and return canonical `DetectionResult` tuples.
- Feed AI detections into existing `TrackingInput` / `KalmanTracker`, then the existing PID controller. The detector emits no target ID and performs no camera motion.
- `processing_ms` is wall-clock profiling only; camera-frame `t_sim_s` flows through unchanged.
- Retrain deterministically: `python -m core.ai.training --output assets/models/beacon_logistic_v1.json`. The utility uses truth only for offline labels; never add truth to inference methods.
- Run all checks with `python -m unittest discover -v`.
