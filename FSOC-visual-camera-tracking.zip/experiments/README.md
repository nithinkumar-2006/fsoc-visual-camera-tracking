# Benchmark scenario presets

The canonical preset generator is `core.benchmarking.scenario_preset`. It provides deterministic `clean`, `vibration`, `turbulence_noise`, `false_bright_objects`, `temporary_occlusion`, and `combined_stress` configurations. Seed, duration, and algorithm mode are supplied by the benchmark runner so comparison trials retain the same scenario conditions.
