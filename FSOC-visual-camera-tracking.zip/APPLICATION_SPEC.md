# Role #11 Application Specification

## Technology and composition

The standalone desktop application uses Python's standard-library **Tkinter**. It is the smallest offline option that directly imports the existing Python core, supports a real-time image canvas, controls, tables/logs and simple engineering charts, and needs no server, browser, account or network connection.

`app/orchestrator.py` is the composition layer. It constructs the Role #3–#10 simulation, virtual camera, disturbance engine, selected detector/tracker/controller and benchmark runner. GUI callbacks call typed controller methods only; simulation, detection, Kalman and PID mathematics remain in `core/`.

## Runtime loop and state

Tkinter schedules `ApplicationController.tick()` every 50 ms while the fixed-step simulation engine remains the source of simulation time. Each tick executes: snapshot → disturbance/camera frame → detector → tracker → controller → constrained camera reposition → telemetry/event snapshot → simulation step.

The application translates observable tracker evidence into the canonical states: `IDLE`, `SEARCHING`, `ACQUIRING`, `TRACKING`, `LOCKED`, `LOST`, `REACQUIRING`, `STOPPED`, and `FAULTED`. `RUN_STARTED`, target/lock/loss/reacquisition, disturbance and stop/fault events are recorded in the event log.

## Operator interface

The top bar controls scenario, start/pause/stop/reset, benchmark and export. The central viewport renders the actual `CameraFrame` with optical-axis crosshair, detection boxes and tracking estimate. Evaluation truth is opt-in and visibly marked `EVALUATION / GROUND TRUTH`; it is never passed into the pipeline.

The left rail selects one of the real pipeline modes—baseline classical/reactive/P, classical/Kalman/PID, or AI/Kalman/PID—and enables actual disturbances. The right rail presents missing data as `—`, current state, active algorithms, confidence, estimate, control error, pose, processing FPS and latency. The bottom area plots live history and records real events. AI mode reports model-load health from `AIAssistedBeaconDetector.health()`.

## Benchmarking and export

`Run Benchmark` calls Role #10 `BenchmarkRunner.compare` under the selected preset and writes a genuine comparison CSV. `Export Results` calls the Role #10 exporter and writes summary JSON plus telemetry CSV. Errors are surfaced as operator messages and a runtime error produces `FAULTED` plus `RUN_FAULTED` rather than a silent fallback.
