# Role #13 QA Test Plan

## Scope and environment

This plan validates the integrated software simulation: application composition, GUI command wiring, simulation, virtual camera, disturbances, CV/AI detection, tracking, control, benchmarking, exports, and model-path discovery. It does not validate physical FSOC optics, a webcam, servo hardware, or an executable installer.

Environment: Python 3.11 with the repository's bundled model (`assets/models/beacon_logistic_v1.json`); standard-library `unittest`; Tkinter required for `python -m gui.desktop`.

## Test categories and acceptance criteria

| Category | Scenarios | Acceptance criteria |
|---|---|---|
| Baseline regression | Full test discovery before changes | All 61 inherited tests pass with no errors/skips. |
| Input boundaries | Invalid seed, resolution, FOV, severity, schedule | `ConfigError` at validation, not late crash or silent clamp. |
| End-to-end modes | All three modes × all six presets | Acquisition, finite telemetry, valid output and clean completion. |
| Occlusion/loss | Temporary Occlusion and Combined Stress | Loss/reacquisition semantics and no stale measurement regression. |
| Lifecycle | duplicate start; pause/resume; stop/reset/start | No duplicate loop; paused time unchanged; reset rebuilds state. |
| Determinism | identical combined-stress seed × 3 | Identical per-frame deterministic trace excluding wall-clock timings. |
| Export | nested new directory | JSON parses; CSV has header and a row per processed frame. |
| Isolation/honesty | runtime-call audit plus automated tests | Detector/tracker/controller receive no truth object; benchmark joins truth only after pipeline output. |
| Soak | AI/Kalman/PID Combined Stress | No crash, NaN/Inf, corrupted telemetry, or unstable camera state. |
| GUI readiness | Desktop module import and command mapping audit | GUI invokes typed controller actions; truth overlay remains explicitly evaluation-only. |

## Release criteria

All regression and QA tests must pass; confirmed defects require a minimal fix and regression test; known hardware and packaging limits must be disclosed rather than represented as verified.
