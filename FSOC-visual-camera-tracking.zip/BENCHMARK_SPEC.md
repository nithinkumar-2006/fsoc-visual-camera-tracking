# Role #10: Performance and Benchmark Specification

`core/benchmarking/` is an evaluation-only composition layer. It runs the existing simulation → camera → disturbance → detector → tracker → controller → camera loop and joins its output with `GroundTruthFrame` only after the tracker has produced an estimate. Truth is never supplied to perception, AI inference, tracking, or control.

For paired frames, benchmark error is `du = estimated_u - truth_u`, `dv = estimated_v - truth_v`, and `e = sqrt(du² + dv²)`. Average, RMS, maximum, and mean absolute horizontal/vertical errors use paired frames only; a missing estimate remains null in telemetry and increments `missing_estimate_visible_frames`.

Acquisition is the first measured estimate on a geometrically visible target, measured from `RUN_STARTED`. Lock is a configurable number of consecutive measured visible frames (default 3); retention is locked visible frames / geometrically visible frames. A loss is one locked→not-locked transition; a subsequent tracker `REACQUIRED` produces reacquisition time. Unrecovered losses are recorded with null duration.

Simulation duration uses `duration_s`; execution duration uses `perf_counter()` separately. Configured FPS is frames/simulation duration, while effective FPS is frames/wall-clock execution duration. Timing reports mean, max, and nearest-rank P95 for camera/render, disturbance, perception, tracking, controller, and full pipeline profiling.

Supported modes are `classical-reactive-proportional`, `classical-kalman-pid`, and `ai-kalman-pid`. Comparisons keep an identical config and seed for every mode. Presets are `clean`, `vibration`, `turbulence_noise`, `false_bright_objects`, `temporary_occlusion`, and `combined_stress`.

Reports contain run identity, deterministic SHA-256 configuration hash, seed, algorithm/scenario, metrics, disturbance configuration, and software metadata. CSV telemetry uses null/blank missing values; JSON and CSV reports describe simulation outcomes only and do not claim physical FSOC link performance.
