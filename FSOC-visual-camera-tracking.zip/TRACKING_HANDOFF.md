# Role #6 handoff to Role #7

Instantiate either `ReactiveTracker(TrackingConfig(...))` or
`KalmanTracker(TrackingConfig(...))`. For every `CameraFrame`, run the detector
and call:

```python
tracker.process(TrackingInput(frame.frame_id, frame.t_sim_s,
                              detector.process(frame), frame.camera_state))
```

The returned `TrackingOutput.error_px` is the controller input `(e_u,e_v)`:
positive `e_u` is right of center and positive `e_v` is below center. It is
image-center control error, not benchmark truth error.

Only consume a position when `estimated_center_px` is present. `measured=True`
means a fresh detection was associated. `COASTING` has a predicted position and
`measured=False`; it must never be shown as a fresh observation. `LOST` has no
position and should cause Role #7 to stop tracking commands / enter its
canonical lost-search behavior. `REACQUIRED` is a valid fresh observable
measurement after a lost period.

`frame_id` and `t_sim_s` are copied from the input frame. Confidence is `[0,1]`
and decays during coasting. `velocity_pxps` is image-space pixels/s. The tracker
does not make mechanical pan/tilt decisions and consumes no ground truth.

Run all regression tests with:

```bash
python -m unittest discover -v
```
