# Disturbance Engine Specification

## Scope and ordering

`core.disturbances.DisturbanceEngine` is an observation-side layer. For every fixed simulation frame it applies a fixed, explicit order:

1. nominal controller-owned `CameraState`;
2. platform vibration and external camera-motion offsets to produce an effective observation pose;
3. virtual-camera projection and rendering;
4. scheduled occlusion removal of emitted beacon pixels;
5. turbulence-like shimmer/scintillation, false bright objects, sensor noise, then directional motion blur;
6. detector-facing `CameraFrame`.

The camera's nominal pose is never overwritten by an observation disturbance. `PinholeCamera.observe(..., observation_state=...)` exposes the minimal public rendering seam needed for this integration.

## Configuration and schedule

The engine consumes the canonical `experiment.disturbances` mapping. Each named type (`platform_vibration`, `camera_motion`, `sensor_noise`, `motion_blur`, `occlusion`, `false_bright_objects`, `turbulence`) accepts `enabled`, `start_s`, `end_s`, `severity`, plus its documented optional parameters. A schedule is active on `[start_s, end_s)` against `t_sim_s`; wall-clock time is never used.

Vibration accepts `amplitude_rad`, per-axis amplitudes, frequency and phases. Camera movement supports `drift`, `step`, and `sinusoidal` mode with pan/tilt and optional world-position offsets. Noise uses Gaussian `sigma`; blur uses bounded kernel/strength and direction; false objects use count/intensity/size and either explicit positions or seeded positions. Turbulence is a lightweight bounded image shift plus intensity scintillation, not atmospheric wave propagation.

## Determinism and composition

Every pseudo-random effect derives a local PRNG from a BLAKE2 stable token: experiment seed, disturbance name, and frame id. Thus identical config/seed/frame sequences replay exactly and different seeds change stochastic effects. Effects compose; none disables another.

## Truth and events

Geometric FOV is calculated from the effective observation pose. Occlusion only suppresses sensor pixels and sets `ProjectedTargetTruth.occluded`; it does not alter target kinematics or change `in_geometric_fov`. `CameraFrame` carries no truth metadata.

State transitions emit `DISTURBANCE_CHANGED`; occlusion transitions emit `OCCLUSION_STARTED` and `OCCLUSION_ENDED`, all timestamped with `t_sim_s`. `DisturbanceSample` makes nominal/effective pose, active names, events and ground-truth frame available only to composition, telemetry, and benchmarking paths.

## Performance and extension

Processing uses byte arrays and small local kernels, suitable for the small synthetic frames used by the validation simulator. Extension points are additional named stages in the explicit `ORDER` sequence, with a stable RNG name and tests for bounds, determinism, scheduling and truth separation.
