"""FSOC virtual tracker core packages."""
