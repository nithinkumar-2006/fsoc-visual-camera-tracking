"""Classical connected-component beacon detector operating only on CameraFrame."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from time import perf_counter
from typing import Protocol

from core.contracts.camera import CameraFrame
from core.contracts.perception import DetectionResult


@dataclass(frozen=True, slots=True)
class BeaconDetectorConfig:
    intensity_threshold: int = 120
    min_area_px: int = 2
    max_area_px: int | None = None
    min_peak_intensity: int = 120
    min_mean_intensity: float = 120.0
    min_compactness: float = 0.0

    def __post_init__(self) -> None:
        if not 0 <= self.intensity_threshold <= 255:
            raise ValueError("intensity_threshold must be in [0, 255]")
        if self.min_area_px <= 0 or (self.max_area_px is not None and self.max_area_px < self.min_area_px):
            raise ValueError("invalid candidate area limits")
        if not 0 <= self.min_peak_intensity <= 255 or not 0 <= self.min_mean_intensity <= 255:
            raise ValueError("intensity limits must be in [0, 255]")
        if not 0 <= self.min_compactness <= 1:
            raise ValueError("min_compactness must be in [0, 1]")


class Detector(Protocol):
    def reset(self, config: BeaconDetectorConfig | None = None) -> None: ...
    def process(self, camera_frame: CameraFrame) -> tuple[DetectionResult, ...]: ...
    def snapshot(self) -> dict[str, object]: ...
    def health(self) -> dict[str, object]: ...


class BeaconDetector:
    """Deterministic 8-connected bright-blob detector with intensity centroids."""

    detector_id = "centroid-threshold-v1"

    def __init__(self, config: BeaconDetectorConfig | None = None) -> None:
        self.reset(config)

    def reset(self, config: BeaconDetectorConfig | None = None) -> None:
        self._config = config or BeaconDetectorConfig()
        self._frames_processed = 0
        self._last_frame_id: int | None = None
        self._last_detection_count = 0

    def process(self, camera_frame: CameraFrame) -> tuple[DetectionResult, ...]:
        start = perf_counter()
        width, height, pixels = self._validated_image(camera_frame)
        threshold = self._config.intensity_threshold
        visited = bytearray(width * height)
        candidates: list[tuple[tuple[int, int, int, int], tuple[float, float], float]] = []
        for index, intensity in enumerate(pixels):
            if visited[index] or intensity < threshold:
                continue
            component = self._component(index, pixels, visited, width, height, threshold)
            candidate = self._candidate(component, pixels, width)
            if candidate is not None:
                candidates.append(candidate)
        # Stable observable ordering: higher confidence, then image top-left.
        candidates.sort(key=lambda item: (-item[2], item[0][1], item[0][0]))
        elapsed_ms = (perf_counter() - start) * 1000.0
        results = tuple(DetectionResult(camera_frame.frame_id, camera_frame.t_sim_s,
            self.detector_id, None, bbox, center, confidence, elapsed_ms)
            for bbox, center, confidence in candidates)
        self._frames_processed += 1
        self._last_frame_id, self._last_detection_count = camera_frame.frame_id, len(results)
        return results

    def snapshot(self) -> dict[str, object]:
        return {"detector_id": self.detector_id, "config": asdict(self._config),
                "frames_processed": self._frames_processed, "last_frame_id": self._last_frame_id,
                "last_detection_count": self._last_detection_count}

    def health(self) -> dict[str, object]:
        return {"ok": True, "detector_id": self.detector_id,
                "frames_processed": self._frames_processed, "last_error": None}

    @staticmethod
    def _validated_image(frame: CameraFrame) -> tuple[int, int, bytes]:
        width, height = frame.resolution_px
        if not isinstance(width, int) or not isinstance(height, int) or width <= 0 or height <= 0:
            raise ValueError("CameraFrame resolution must contain positive integer dimensions")
        if not isinstance(frame.image_gray8, bytes) or len(frame.image_gray8) != width * height:
            raise ValueError("CameraFrame image_gray8 must be bytes matching resolution_px")
        return width, height, frame.image_gray8

    @staticmethod
    def _component(start: int, pixels: bytes, visited: bytearray, width: int, height: int, threshold: int) -> list[int]:
        stack, points = [start], []
        visited[start] = 1
        while stack:
            index = stack.pop(); points.append(index)
            x, y = index % width, index // width
            for ny in range(max(0, y - 1), min(height, y + 2)):
                for nx in range(max(0, x - 1), min(width, x + 2)):
                    neighbor = ny * width + nx
                    if not visited[neighbor] and pixels[neighbor] >= threshold:
                        visited[neighbor] = 1; stack.append(neighbor)
        return points

    def _candidate(self, points: list[int], pixels: bytes, width: int) -> tuple[tuple[int, int, int, int], tuple[float, float], float] | None:
        area = len(points)
        if area < self._config.min_area_px or (self._config.max_area_px is not None and area > self._config.max_area_px):
            return None
        xs, ys = [p % width for p in points], [p // width for p in points]
        values = [pixels[p] for p in points]
        peak, mean = max(values), sum(values) / area
        if peak < self._config.min_peak_intensity or mean < self._config.min_mean_intensity:
            return None
        left, top, right, bottom = min(xs), min(ys), max(xs), max(ys)
        bbox = (left, top, right - left + 1, bottom - top + 1)
        fill = area / (bbox[2] * bbox[3])
        if fill < self._config.min_compactness:
            return None
        total = sum(values)
        center = (sum(x * value for x, value in zip(xs, values)) / total,
                  sum(y * value for y, value in zip(ys, values)) / total)
        intensity_score = ((peak / 255.0) + (mean / 255.0)) / 2.0
        confidence = max(0.0, min(1.0, 0.65 * intensity_score + 0.35 * fill))
        return bbox, center, confidence
