"""Reproducible offline simulator-labelled dataset generation and model training."""
from __future__ import annotations
import argparse, math, random
from pathlib import Path
from core.ai.features import candidates_from_frame
from core.ai.model import LogisticBeaconModel
from core.camera import PinholeCamera
from core.contracts.camera import CameraState
from core.disturbances import DisturbanceEngine
from core.simulation import SimulationEngine,validate_experiment_config

def _config(seed:int): return validate_experiment_config({"schema_version":"2","experiment_id":"ai-data","seed":seed,"duration_s":1.,"simulation_dt_s":.1,"camera":{},"targets":[{"target_id":"beacon","position_w_m":[2,10,0],"designated":True}],"disturbances":{"sensor_noise":{"enabled":True,"severity":.15,"sigma":8},"false_bright_objects":{"enabled":True,"count":2,"intensity":220,"size_px":2}},"pipeline":{},"lock_policy":{},"benchmark":{},"export":{}})
def generate_dataset(seeds:tuple[int,...]=(11,12,13,14)):
    features=[]; labels=[]
    for seed in seeds:
        e=SimulationEngine(_config(seed)); e.start(); cam=PinholeCamera(CameraState(0,(0,0,0),0,0,0,0,math.pi/2,math.pi/2,(101,101))); d=DisturbanceEngine.from_experiment(e.config.raw)
        while e.status.name=="RUNNING":
            s=d.process(cam,e.snapshot()); truth=s.ground_truth.targets[0].image_center_px
            for c in candidates_from_frame(s.frame,threshold=100):
                # This is the offline-only label join. Runtime detector never imports GroundTruthFrame.
                features.append(c.feature); labels.append(int(truth is not None and math.dist(c.center_px,truth)<=4.5))
            e.step()
    return features,labels
def train_and_save(path:str|Path,seeds:tuple[int,...]=(11,12,13,14)):
    x,y=generate_dataset(seeds); model=LogisticBeaconModel.train(x,y); meta=dict(model.metadata); meta.update({"training_seeds":list(seeds),"split":"train seeds 11-14; held-out evaluation seeds 71-74","labeling":"offline GroundTruthFrame proximity <=4.5 px"}); model=LogisticBeaconModel(model.weights,model.bias,model.mean,model.scale,meta); model.save(path); return model
if __name__=="__main__":
 p=argparse.ArgumentParser(); p.add_argument("--output",default="assets/models/beacon_logistic_v1.json"); a=p.parse_args(); train_and_save(a.output)
