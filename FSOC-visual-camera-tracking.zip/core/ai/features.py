"""Observable candidate extraction and feature computation; no truth arguments exist here."""
from __future__ import annotations
from dataclasses import dataclass
from core.contracts.camera import CameraFrame

FEATURE_NAMES=("peak_norm","mean_norm","log_area","fill","contrast_norm","radial_drop","aspect","patch_energy")
@dataclass(frozen=True,slots=True)
class Candidate:
    bbox_xywh_px: tuple[int,int,int,int]; center_px: tuple[float,float]; feature: tuple[float,...]

def candidates_from_frame(frame: CameraFrame, *, threshold: int=100, min_area_px: int=1) -> tuple[Candidate,...]:
    w,h=frame.resolution_px; pix=frame.image_gray8
    if len(pix)!=w*h: raise ValueError("CameraFrame image_gray8 must match resolution")
    seen=bytearray(w*h); result=[]
    for start,v in enumerate(pix):
        if seen[start] or v<threshold: continue
        stack=[start]; seen[start]=1; pts=[]
        while stack:
            i=stack.pop(); pts.append(i); x,y=i%w,i//w
            for yy in range(max(0,y-1),min(h,y+2)):
                for xx in range(max(0,x-1),min(w,x+2)):
                    j=yy*w+xx
                    if not seen[j] and pix[j]>=threshold: seen[j]=1; stack.append(j)
        if len(pts)<min_area_px: continue
        xs=[p%w for p in pts]; ys=[p//w for p in pts]; vals=[pix[p] for p in pts]; total=sum(vals)
        left,top,right,bottom=min(xs),min(ys),max(xs),max(ys); bw,bh=right-left+1,bottom-top+1
        cx=sum(x*v for x,v in zip(xs,vals))/total; cy=sum(y*v for y,v in zip(ys,vals))/total
        peak=max(vals); mean=total/len(vals); fill=len(pts)/(bw*bh)
        # Pixels around bbox are observable local background; the radial statistic separates peaked beacons from flat discs.
        ring=[]
        for yy in range(max(0,top-1),min(h,bottom+2)):
            for xx in range(max(0,left-1),min(w,right+2)):
                if not (left<=xx<=right and top<=yy<=bottom): ring.append(pix[yy*w+xx])
        contrast=mean-(sum(ring)/len(ring) if ring else 0.0)
        core=[v for x,y,v in zip(xs,ys,vals) if (x-cx)**2+(y-cy)**2 <= max(1.0,min(bw,bh)**2/16)]
        radial=(sum(core)/len(core)-mean)/255.0 if core else 0.0
        feature=(peak/255.0,mean/255.0,__import__('math').log1p(len(pts)),fill,contrast/255.0,radial,min(bw,bh)/max(bw,bh),sum(v*v for v in vals)/(len(vals)*255*255))
        result.append(Candidate((left,top,bw,bh),(cx,cy),tuple(float(x) for x in feature)))
    return tuple(sorted(result,key=lambda c:(c.bbox_xywh_px[1],c.bbox_xywh_px[0])))
