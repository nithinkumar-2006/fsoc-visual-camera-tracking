"""Small deterministic trainable logistic model, serialized as JSON (no cloud/runtime truth)."""
from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
import numpy as np

MODEL_VERSION = "logistic-beacon-v1"
FEATURE_SCHEMA_VERSION = "blob-stats-v1"

class ModelArtifactError(RuntimeError): pass

@dataclass(frozen=True, slots=True)
class LogisticBeaconModel:
    weights: tuple[float, ...]
    bias: float
    mean: tuple[float, ...]
    scale: tuple[float, ...]
    metadata: dict[str, object]

    @classmethod
    def train(cls, features: list[tuple[float, ...]], labels: list[int], *, epochs: int = 500, learning_rate: float = .12, l2: float = .002) -> "LogisticBeaconModel":
        if len(features) < 2 or len(features) != len(labels) or len(set(labels)) != 2: raise ValueError("training needs aligned samples from both classes")
        x=np.asarray(features,dtype=float); y=np.asarray(labels,dtype=float)
        mean=x.mean(axis=0); scale=x.std(axis=0); scale[scale < 1e-9]=1.0; z=(x-mean)/scale
        w=np.zeros(z.shape[1]); b=0.0
        for _ in range(epochs):
            p=1/(1+np.exp(-np.clip(z@w+b,-50,50))); w-=learning_rate*((z.T@(p-y))/len(y)+l2*w); b-=learning_rate*float((p-y).mean())
        return cls(tuple(map(float,w)),float(b),tuple(map(float,mean)),tuple(map(float,scale)), {"model_version":MODEL_VERSION,"feature_schema_version":FEATURE_SCHEMA_VERSION,"epochs":epochs,"learning_rate":learning_rate,"l2":l2,"samples":len(labels)})

    def predict_proba(self, feature: tuple[float, ...]) -> float:
        if len(feature)!=len(self.weights): raise ValueError("feature schema incompatible with model")
        z=sum((v-m)/s*w for v,m,s,w in zip(feature,self.mean,self.scale,self.weights))+self.bias
        return float(1/(1+np.exp(-max(-50,min(50,z)))))

    def save(self, path: str | Path) -> None:
        payload={"weights":self.weights,"bias":self.bias,"mean":self.mean,"scale":self.scale,"metadata":self.metadata}
        Path(path).parent.mkdir(parents=True,exist_ok=True); Path(path).write_text(json.dumps(payload,sort_keys=True,indent=2),encoding="utf-8")

    @classmethod
    def load(cls,path: str | Path) -> "LogisticBeaconModel":
        try: raw=json.loads(Path(path).read_text(encoding="utf-8")); meta=raw["metadata"]
        except Exception as e: raise ModelArtifactError(f"cannot load model: {e}") from e
        if meta.get("model_version")!=MODEL_VERSION or meta.get("feature_schema_version")!=FEATURE_SCHEMA_VERSION: raise ModelArtifactError("incompatible model or feature schema")
        try:
            m=cls(tuple(map(float,raw["weights"])),float(raw["bias"]),tuple(map(float,raw["mean"])),tuple(map(float,raw["scale"])),dict(meta))
            if not m.weights or len(m.weights)!=len(m.mean) or len(m.weights)!=len(m.scale): raise ValueError("parameter lengths")
            return m
        except Exception as e: raise ModelArtifactError(f"invalid model parameters: {e}") from e
