"""AI detector: trained candidate likelihood plus observable temporal re-identification."""
from __future__ import annotations
from dataclasses import asdict,dataclass
from pathlib import Path
from time import perf_counter
import math
from core.contracts.camera import CameraFrame
from core.contracts.perception import DetectionResult
from .features import candidates_from_frame
from .model import LogisticBeaconModel,ModelArtifactError

@dataclass(frozen=True,slots=True)
class AIDetectorConfig:
    model_path: str="assets/models/beacon_logistic_v1.json"; threshold: float=.50; candidate_threshold: int=100; min_area_px:int=1; reid_sigma_px:float=35.0; fallback_to_classical:bool=True
    def __post_init__(self):
        if not 0<=self.threshold<=1 or self.candidate_threshold<0 or self.min_area_px<1 or self.reid_sigma_px<=0: raise ValueError("invalid AI detector configuration")

class AIAssistedBeaconDetector:
    detector_id="ai-logistic-reid-v1"
    def __init__(self,config:AIDetectorConfig|None=None): self.reset(config)
    def reset(self,config:AIDetectorConfig|None=None)->None:
        self._config=config or AIDetectorConfig(); self._model=None; self._model_error=None; self._previous_center=None; self._previous_t=None; self._frames=0; self._last_count=0
        try: self._model=LogisticBeaconModel.load(self._config.model_path)
        except ModelArtifactError as e: self._model_error=str(e)
    def process(self,camera_frame:CameraFrame)->tuple[DetectionResult,...]:
        start=perf_counter()
        cs=candidates_from_frame(camera_frame,threshold=self._config.candidate_threshold,min_area_px=self._config.min_area_px)
        scored=[]
        for c in cs:
            likelihood=self._model.predict_proba(c.feature) if self._model else 0.0
            continuity=1.0 if self._previous_center is None else math.exp(-math.dist(c.center_px,self._previous_center)**2/(2*self._config.reid_sigma_px**2))
            # association is explicit: product retains learned visual likelihood and an observable history preference.
            score=likelihood*(.45+.55*continuity)
            scored.append((c,score,likelihood))
        valid=[x for x in scored if x[1]>=self._config.threshold]
        if not valid and self._model is None and self._config.fallback_to_classical: valid=[(c, .5, .0) for c in cs]
        valid.sort(key=lambda x:(-x[1],x[0].bbox_xywh_px[1],x[0].bbox_xywh_px[0]) )
        if valid: self._previous_center=valid[0][0].center_px
        self._previous_t=camera_frame.t_sim_s; self._frames+=1; self._last_count=len(valid); elapsed=(perf_counter()-start)*1000
        return tuple(DetectionResult(camera_frame.frame_id,camera_frame.t_sim_s,self.detector_id,None,c.bbox_xywh_px,c.center_px,max(0,min(1,score)),elapsed) for c,score,_ in valid)
    def snapshot(self)->dict[str,object]: return {"detector_id":self.detector_id,"config":asdict(self._config),"frames_processed":self._frames,"last_detection_count":self._last_count,"previous_center_px":self._previous_center}
    def health(self)->dict[str,object]: return {"ok":self._model is not None or self._config.fallback_to_classical,"detector_id":self.detector_id,"model_loaded":self._model is not None,"fallback_active":self._model is None and self._config.fallback_to_classical,"last_error":self._model_error,"frames_processed":self._frames}
