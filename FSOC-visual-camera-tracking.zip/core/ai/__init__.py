"""Offline, truth-isolated AI-assisted beacon candidate classification."""

from .model import LogisticBeaconModel, ModelArtifactError
from .detector import AIAssistedBeaconDetector, AIDetectorConfig

__all__ = ["LogisticBeaconModel", "ModelArtifactError", "AIAssistedBeaconDetector", "AIDetectorConfig"]
