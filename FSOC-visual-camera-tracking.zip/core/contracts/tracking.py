"""Canonical image-space tracking DTOs; these never contain ground truth."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from core.contracts.camera import CameraState
from core.contracts.perception import DetectionResult


class TrackingStatus(str, Enum):
    TRACKING = "TRACKING"
    COASTING = "COASTING"
    LOST = "LOST"
    REACQUIRED = "REACQUIRED"


@dataclass(frozen=True, slots=True)
class TrackingInput:
    """All observable data offered to a tracker for one camera frame."""

    frame_id: int
    t_sim_s: float
    detections: tuple[DetectionResult, ...]
    camera_state: CameraState


@dataclass(frozen=True, slots=True)
class TrackingOutput:
    """Estimated target state in image pixels, or no estimate after loss."""

    frame_id: int
    t_sim_s: float
    target_id: str | None
    estimated_center_px: tuple[float, float] | None
    velocity_pxps: tuple[float, float] | None
    error_px: tuple[float, float] | None
    confidence: float
    status: TrackingStatus
    measured: bool
    hit_count: int
    miss_count: int

