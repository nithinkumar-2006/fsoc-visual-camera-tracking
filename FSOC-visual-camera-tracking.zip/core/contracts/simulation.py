"""Canonical simulation-side DTOs from MASTER_ARCHITECTURE_V2."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

Vector3 = tuple[float, float, float]


@dataclass(frozen=True, slots=True)
class FrameContext:
    """Immutable fixed-step context; frame_id equals the completed tick number."""

    frame_id: int
    tick_id: int
    t_sim_s: float
    simulation_dt_s: float


@dataclass(frozen=True, slots=True)
class TargetTruth:
    """Canonical world-space beacon truth. World is X east, Y north, Z up."""

    target_id: str
    t_sim_s: float
    position_w_m: Vector3
    velocity_w_mps: Vector3
    acceleration_w_mps2: Vector3
    emission: float
    designated: bool
    visible_truth: bool


@dataclass(frozen=True, slots=True)
class Event:
    """Canonical structured event. payload never contains perception/tracking facts."""

    event_id: str
    t_sim_s: float
    severity: str
    type: str
    target_id: str | None
    payload: Mapping[str, Any]
