"""Versioned shared contracts used by FSOC core modules."""

from .simulation import Event, FrameContext, TargetTruth
from .perception import DetectionResult, DetectionStatus
from .tracking import TrackingInput, TrackingOutput, TrackingStatus
from .control import ControlInput, ControlMode, TrackingCommand

__all__ = ["Event", "FrameContext", "TargetTruth", "DetectionResult", "DetectionStatus",
           "TrackingInput", "TrackingOutput", "TrackingStatus", "ControlInput", "ControlMode", "TrackingCommand"]
from core.contracts.camera import CameraFrame, CameraState, GroundTruthFrame, ProjectedTargetTruth

__all__ = ["CameraFrame", "CameraState", "GroundTruthFrame", "ProjectedTargetTruth"]
