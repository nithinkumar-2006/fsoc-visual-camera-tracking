"""Canonical controller DTOs; control consumes tracking estimates, never truth."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from core.contracts.camera import CameraState
from core.contracts.tracking import TrackingOutput


class ControlMode(str, Enum):
    TRACK = "TRACK"
    COAST = "COAST"
    NO_TRACK = "NO_TRACK"


@dataclass(frozen=True, slots=True)
class ControlInput:
    """Observable Role #6 result and camera state for one control update."""

    tracking: TrackingOutput
    camera_state: CameraState


@dataclass(frozen=True, slots=True)
class TrackingCommand:
    """Rate command for the public virtual-camera mechanical interface."""

    frame_id: int
    t_sim_s: float
    target_id: str | None
    mode: ControlMode
    pan_rate_cmd_radps: float
    tilt_rate_cmd_radps: float
    source: str
    saturated_pan: bool = False
    saturated_tilt: bool = False
    used_measured_estimate: bool = False
