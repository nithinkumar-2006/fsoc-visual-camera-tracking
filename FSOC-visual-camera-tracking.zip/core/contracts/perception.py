"""Canonical perception DTOs; detections are image-derived and unassociated."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class DetectionStatus(str, Enum):
    VALID = "VALID"


@dataclass(frozen=True, slots=True)
class DetectionResult:
    """One observable bright-region candidate from one CameraFrame.

    ``target_id`` is intentionally ``None`` for this baseline: a detector has no
    authority to identify a simulated target.  Association belongs to tracking.
    """

    frame_id: int
    t_sim_s: float
    detector_id: str
    target_id: str | None
    bbox_xywh_px: tuple[int, int, int, int]
    center_px: tuple[float, float]
    confidence: float
    processing_ms: float
    status: DetectionStatus = DetectionStatus.VALID
