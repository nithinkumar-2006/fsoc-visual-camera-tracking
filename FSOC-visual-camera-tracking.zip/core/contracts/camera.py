"""Canonical camera-side DTOs; image observations and truth stay separate."""

from __future__ import annotations

from dataclasses import dataclass

from core.contracts.simulation import Vector3


@dataclass(frozen=True, slots=True)
class CameraState:
    """Pose at simulation time. Angles are radians; camera axes follow V2."""

    t_sim_s: float
    position_w_m: Vector3
    pan_rad: float
    tilt_rad: float
    pan_rate_radps: float
    tilt_rate_radps: float
    hfov_rad: float
    vfov_rad: float
    resolution_px: tuple[int, int]


@dataclass(frozen=True, slots=True)
class ProjectedTargetTruth:
    """Image-space truth for benchmarking only, never included in CameraFrame."""

    target_id: str
    in_geometric_fov: bool
    image_center_px: tuple[float, float] | None
    bbox_xywh_px: tuple[int, int, int, int] | None
    occluded: bool


@dataclass(frozen=True, slots=True)
class GroundTruthFrame:
    frame_id: int
    t_sim_s: float
    targets: tuple[ProjectedTargetTruth, ...]


@dataclass(frozen=True, slots=True)
class CameraFrame:
    """Detector-facing grayscale image. Pixels are row-major 8-bit values only."""

    frame_id: int
    t_sim_s: float
    resolution_px: tuple[int, int]
    image_gray8: bytes
    camera_state: CameraState
