"""Pinhole projection and deterministic grayscale beacon rendering."""

from __future__ import annotations

from dataclasses import dataclass, replace
import math

from core.contracts.camera import CameraFrame, CameraState, GroundTruthFrame, ProjectedTargetTruth
from core.contracts.simulation import TargetTruth, Vector3
from core.simulation.engine import SimulationSnapshot


@dataclass(frozen=True, slots=True)
class CameraLimits:
    """Mechanical pose and slew limits. All values are canonical radians/rad/s."""

    pan_min_rad: float = -math.pi
    pan_max_rad: float = math.pi
    tilt_min_rad: float = -math.pi / 2
    tilt_max_rad: float = math.pi / 2
    max_pan_rate_radps: float = math.pi
    max_tilt_rate_radps: float = math.pi

    def __post_init__(self) -> None:
        if self.pan_min_rad > self.pan_max_rad or self.tilt_min_rad > self.tilt_max_rad:
            raise ValueError("camera angle minima must not exceed maxima")
        if self.max_pan_rate_radps < 0 or self.max_tilt_rate_radps < 0:
            raise ValueError("camera rate limits must be non-negative")


class PinholeCamera:
    """Owns camera pose and turns a Role #3 snapshot into observation plus truth.

    ``apply_rate_request`` accepts the rate-style request in the V2 TrackingCommand
    contract.  It is intentionally camera-side mechanics only, not a controller.
    """

    def __init__(self, initial_state: CameraState, limits: CameraLimits | None = None,
                 beacon_radius_px: int = 3, beacon_peak_intensity: int = 255) -> None:
        self._limits = limits or CameraLimits()
        self._radius = int(beacon_radius_px)
        self._peak = int(beacon_peak_intensity)
        if self._radius < 1 or not 0 <= self._peak <= 255:
            raise ValueError("beacon radius must be positive and intensity must be 0..255")
        self._state = self._constrain(initial_state)
        self._validate_intrinsics(self._state)

    @property
    def state(self) -> CameraState:
        return self._state

    @staticmethod
    def principal_point(resolution_px: tuple[int, int]) -> tuple[float, float]:
        width, height = resolution_px
        return ((width - 1) / 2.0, (height - 1) / 2.0)

    @staticmethod
    def focal_lengths_px(state: CameraState) -> tuple[float, float]:
        width, height = state.resolution_px
        return (width / (2.0 * math.tan(state.hfov_rad / 2.0)),
                height / (2.0 * math.tan(state.vfov_rad / 2.0)))

    def set_state(self, state: CameraState) -> CameraState:
        """Apply an absolute camera pose, constrained to configured mechanics."""
        self._validate_intrinsics(state)
        self._state = self._constrain(state)
        return self._state

    def apply_rate_request(self, pan_rate_cmd_radps: float, tilt_rate_cmd_radps: float,
                           dt_s: float, *, t_sim_s: float | None = None) -> CameraState:
        """Apply one externally supplied rate request for a known simulation duration."""
        if not math.isfinite(dt_s) or dt_s < 0:
            raise ValueError("dt_s must be a finite non-negative simulation duration")
        pan_rate = max(-self._limits.max_pan_rate_radps, min(self._limits.max_pan_rate_radps, float(pan_rate_cmd_radps)))
        tilt_rate = max(-self._limits.max_tilt_rate_radps, min(self._limits.max_tilt_rate_radps, float(tilt_rate_cmd_radps)))
        next_t = self._state.t_sim_s + dt_s if t_sim_s is None else float(t_sim_s)
        return self.set_state(replace(self._state, t_sim_s=next_t,
                                      pan_rad=self._state.pan_rad + pan_rate * dt_s,
                                      tilt_rad=self._state.tilt_rad + tilt_rate * dt_s,
                                      pan_rate_radps=pan_rate, tilt_rate_radps=tilt_rate))

    def observe(self, snapshot: SimulationSnapshot, *, observation_state: CameraState | None = None,
                occluded_target_ids: frozenset[str] = frozenset()) -> tuple[CameraFrame, GroundTruthFrame]:
        """Render a snapshot, optionally from a non-persistent effective observation pose.

        ``observation_state`` is deliberately an input rather than a mutation hook: a
        disturbance can perturb what the optics see without changing controller-owned
        camera mechanics.  The legacy no-argument path retains its original behavior.
        """
        state = replace(observation_state or self._state, t_sim_s=snapshot.context.t_sim_s)
        if observation_state is None:
            self._state = state
        self._validate_intrinsics(state)
        width, height = state.resolution_px
        pixels = bytearray(width * height)
        projected = tuple(self._project_target(target, state) for target in snapshot.targets)
        by_id = {entry.target_id: entry for entry in projected}
        for target in snapshot.targets:
            entry = by_id[target.target_id]
            # Emission schedule affects what optics receive, never geometric truth.
            if (entry.in_geometric_fov and target.visible_truth and target.emission > 0
                    and target.target_id not in occluded_target_ids):
                assert entry.image_center_px is not None
                self._render_beacon(pixels, width, height, entry.image_center_px, target.emission)
        truth = tuple(replace(item, occluded=item.target_id in occluded_target_ids) for item in projected)
        return (CameraFrame(snapshot.context.frame_id, snapshot.context.t_sim_s, state.resolution_px, bytes(pixels), state),
                GroundTruthFrame(snapshot.context.frame_id, snapshot.context.t_sim_s, truth))

    def world_to_camera(self, position_w_m: Vector3, state: CameraState | None = None) -> Vector3:
        """Transform world point into (+right,+down,+forward) camera coordinates."""
        s = state or self._state
        dx = tuple(position_w_m[i] - s.position_w_m[i] for i in range(3))
        cp, sp, ct, st = math.cos(s.pan_rad), math.sin(s.pan_rad), math.cos(s.tilt_rad), math.sin(s.tilt_rad)
        right = (cp, -sp, 0.0)
        forward = (sp * ct, cp * ct, st)
        up = (-sp * st, -cp * st, ct)
        return (sum(dx[i] * right[i] for i in range(3)),
                -sum(dx[i] * up[i] for i in range(3)),
                sum(dx[i] * forward[i] for i in range(3)))

    def _project_target(self, target: TargetTruth, state: CameraState) -> ProjectedTargetTruth:
        x, y, z = self.world_to_camera(target.position_w_m, state)
        if z <= 0:
            return ProjectedTargetTruth(target.target_id, False, None, None, False)
        fx, fy = self.focal_lengths_px(state)
        u0, v0 = self.principal_point(state.resolution_px)
        u, v = u0 + fx * x / z, v0 + fy * y / z
        width, height = state.resolution_px
        if not (0.0 <= u < width and 0.0 <= v < height):
            return ProjectedTargetTruth(target.target_id, False, None, None, False)
        radius = self._radius
        left, top = max(0, math.floor(u - radius)), max(0, math.floor(v - radius))
        right, bottom = min(width, math.ceil(u + radius) + 1), min(height, math.ceil(v + radius) + 1)
        return ProjectedTargetTruth(target.target_id, True, (u, v), (left, top, right - left, bottom - top), False)

    def _render_beacon(self, pixels: bytearray, width: int, height: int, center: tuple[float, float], emission: float) -> None:
        cx, cy = center
        intensity = max(0, min(self._peak, round(self._peak * min(1.0, float(emission)))))
        # Compact radial falloff is deterministic and gives simple CV algorithms a blob.
        for py in range(max(0, math.floor(cy - self._radius)), min(height, math.ceil(cy + self._radius) + 1)):
            for px in range(max(0, math.floor(cx - self._radius)), min(width, math.ceil(cx + self._radius) + 1)):
                distance = math.hypot(px - cx, py - cy)
                if distance <= self._radius:
                    value = round(intensity * (1.0 - 0.55 * distance / self._radius))
                    index = py * width + px
                    pixels[index] = max(pixels[index], value)

    def _constrain(self, state: CameraState) -> CameraState:
        return replace(state,
            pan_rad=max(self._limits.pan_min_rad, min(self._limits.pan_max_rad, state.pan_rad)),
            tilt_rad=max(self._limits.tilt_min_rad, min(self._limits.tilt_max_rad, state.tilt_rad)),
            pan_rate_radps=max(-self._limits.max_pan_rate_radps, min(self._limits.max_pan_rate_radps, state.pan_rate_radps)),
            tilt_rate_radps=max(-self._limits.max_tilt_rate_radps, min(self._limits.max_tilt_rate_radps, state.tilt_rate_radps)))

    @staticmethod
    def _validate_intrinsics(state: CameraState) -> None:
        width, height = state.resolution_px
        if width <= 0 or height <= 0 or not (0 < state.hfov_rad < math.pi and 0 < state.vfov_rad < math.pi):
            raise ValueError("resolution must be positive and FOVs must be in (0, pi) radians")
