"""Closed-loop deterministic benchmark composition and export helpers."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import asdict, dataclass
from enum import Enum
import csv, hashlib, json, math, platform
from pathlib import Path
from time import perf_counter
from typing import Any, Mapping, Sequence

from core.ai import AIAssistedBeaconDetector, AIDetectorConfig
from core.camera import PinholeCamera
from core.contracts.camera import CameraState
from core.contracts.control import ControlInput
from core.contracts.tracking import TrackingInput
from core.control import ControllerConfig, PIDController, ProportionalController, apply_tracking_command
from core.disturbances import DisturbanceEngine
from core.perception import BeaconDetector, BeaconDetectorConfig
from core.simulation import SimulationEngine, validate_experiment_config
from core.tracking import KalmanTracker, ReactiveTracker, TrackingConfig
from .metrics import BenchmarkCollector, BenchmarkMetrics

REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
MODEL_PATH = REPOSITORY_ROOT / "assets" / "models" / "beacon_logistic_v1.json"

class AlgorithmMode(str, Enum):
    BASELINE = "classical-reactive-proportional"
    CLASSICAL_ADVANCED = "classical-kalman-pid"
    AI_ASSISTED = "ai-kalman-pid"

def _camera_state(raw: Mapping[str, Any]) -> CameraState:
    cfg = raw.get("camera", {})
    return CameraState(0.0, tuple(cfg.get("position_w_m", (0, 0, 0))), float(cfg.get("pan_rad", 0)), float(cfg.get("tilt_rad", 0)), 0, 0,
                       float(cfg.get("hfov_rad", math.pi/2)), float(cfg.get("vfov_rad", math.pi/2)), tuple(cfg.get("resolution_px", (101, 101))))

def configuration_hash(config: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(config, sort_keys=True, separators=(",", ":"), default=list).encode()).hexdigest()

def scenario_preset(name: str, *, seed: int = 17, duration_s: float = 3.0) -> dict[str, Any]:
    disturbances: dict[str, Any] = {}
    if name == "vibration": disturbances = {"platform_vibration": {"enabled": True, "severity": 1, "amplitude_rad": .003, "frequency_hz": 3}}
    elif name == "turbulence_noise": disturbances = {"turbulence": {"enabled": True, "severity": .5, "jitter_px": 1}, "sensor_noise": {"enabled": True, "severity": .15, "sigma": 6}}
    elif name == "false_bright_objects": disturbances = {"false_bright_objects": {"enabled": True, "severity": 1, "count": 2, "intensity": 230, "size_px": 2}}
    elif name == "temporary_occlusion": disturbances = {"occlusion": {"enabled": True, "start_s": .9, "end_s": 1.4, "severity": 1}}
    elif name == "combined_stress": disturbances = {"platform_vibration": {"enabled": True, "severity": 1, "amplitude_rad": .002, "frequency_hz": 3}, "sensor_noise": {"enabled": True, "severity": .12, "sigma": 5}, "turbulence": {"enabled": True, "severity": .35}, "false_bright_objects": {"enabled": True, "severity": .7, "count": 1, "size_px": 2}, "occlusion": {"enabled": True, "start_s": 1.5, "end_s": 1.8}}
    elif name != "clean": raise ValueError("unknown preset")
    return {"schema_version":"2", "experiment_id":f"benchmark-{name}", "seed":seed, "duration_s":duration_s, "simulation_dt_s":.05,
            "camera":{"position_w_m":[0,0,0],"hfov_rad":math.pi/2,"vfov_rad":math.pi/2,"resolution_px":[101,101]},
            "targets":[{"target_id":"beacon", "position_w_m":[2,10,0], "velocity_w_mps":[.2,0,0], "designated":True}], "disturbances":disturbances,
            "pipeline":{}, "lock_policy":{"consecutive_valid_detections":3}, "benchmark":{}, "export":{}}

@dataclass(frozen=True, slots=True)
class ExperimentResult:
    mode: AlgorithmMode
    scenario: str
    seed: int
    configuration_hash: str
    metrics: BenchmarkMetrics
    telemetry: tuple[Mapping[str, Any], ...]
    report: Mapping[str, Any]

class BenchmarkRunner:
    def run(self, config: Mapping[str, Any], mode: AlgorithmMode, *, scenario: str = "custom") -> ExperimentResult:
        raw = deepcopy(dict(config)); engine = SimulationEngine(validate_experiment_config(raw)); camera = PinholeCamera(_camera_state(raw)); disturbance = DisturbanceEngine.from_experiment(engine.config.raw)
        if mode is AlgorithmMode.BASELINE:
            detector, tracker, controller = BeaconDetector(BeaconDetectorConfig(intensity_threshold=100, min_area_px=2, min_mean_intensity=100)), ReactiveTracker(TrackingConfig(gating_radius_px=55)), ProportionalController(ControllerConfig(kp_pan=1.2,kp_tilt=1.2,max_pan_rate_radps=.5,max_tilt_rate_radps=.5))
        elif mode is AlgorithmMode.CLASSICAL_ADVANCED:
            detector, tracker, controller = BeaconDetector(BeaconDetectorConfig(intensity_threshold=100, min_area_px=2, min_mean_intensity=100)), KalmanTracker(TrackingConfig(gating_radius_px=55)), PIDController(ControllerConfig(kp_pan=1.2,kp_tilt=1.2,ki_pan=.03,ki_tilt=.03,kd_pan=.01,kd_tilt=.01,max_pan_rate_radps=.5,max_tilt_rate_radps=.5))
        else:
            model = str(MODEL_PATH)
            detector, tracker, controller = AIAssistedBeaconDetector(AIDetectorConfig(model_path=model, threshold=.2)), KalmanTracker(TrackingConfig(gating_radius_px=55)), PIDController(ControllerConfig(kp_pan=1.2,kp_tilt=1.2,ki_pan=.03,ki_tilt=.03,kd_pan=.01,kd_tilt=.01,max_pan_rate_radps=.5,max_tilt_rate_radps=.5))
        collector = BenchmarkCollector(lock_consecutive_frames=int(raw.get("lock_policy",{}).get("consecutive_valid_detections",3)))
        start = perf_counter(); collector.record_events(engine.start())
        while engine.status.name == "RUNNING":
            pipeline_start = perf_counter(); snapshot = engine.snapshot(); t0 = perf_counter(); sample = disturbance.process(camera, snapshot); disturbance_ms=(perf_counter()-t0)*1000
            t0=perf_counter(); detections=detector.process(sample.frame); perception_ms=(perf_counter()-t0)*1000
            t0=perf_counter(); output=tracker.process(TrackingInput(sample.frame.frame_id,sample.frame.t_sim_s,detections,sample.frame.camera_state)); tracking_ms=(perf_counter()-t0)*1000
            t0=perf_counter(); command=controller.process(ControlInput(output,sample.frame.camera_state)); controller_ms=(perf_counter()-t0)*1000
            apply_tracking_command(camera, command, snapshot.context.simulation_dt_s)
            collector.record_events(sample.events); collector.record_frame(truth=sample.ground_truth, tracking=output, detector_id=detector.detector_id, controller_id=controller.controller_id, camera_pan_rad=camera.state.pan_rad, camera_tilt_rad=camera.state.tilt_rad, active_disturbances=sample.active, timings_ms={"camera_render":0.0,"disturbance":disturbance_ms,"perception":perception_ms,"tracking":tracking_ms,"controller":controller_ms,"frame_pipeline":(perf_counter()-pipeline_start)*1000})
            snapshot, events=engine.step(); collector.record_events(events)
        metrics=collector.finish(simulation_duration_s=engine.config.duration_s, execution_duration_s=perf_counter()-start)
        report={"experiment_id":raw["experiment_id"],"configuration_hash":configuration_hash(raw),"seed":raw["seed"],"scenario":scenario,"algorithm":mode.value,"simulation_duration_s":metrics.simulation_duration_s,"metrics":asdict(metrics),"disturbances":raw["disturbances"],"software":{"python":platform.python_version(),"benchmark":"role-10"},"limitations":"Simulation-only benchmark. Ground truth is evaluation-only and does not enter detector, tracker, or controller."}
        return ExperimentResult(mode,scenario,int(raw["seed"]),configuration_hash(raw),metrics,tuple(collector.telemetry),report)

    @staticmethod
    def export(result: ExperimentResult, directory: str | Path, *, stem: str) -> tuple[Path, Path]:
        out=Path(directory); out.mkdir(parents=True,exist_ok=True); report=out/f"{stem}_REPORT.json"; telemetry=out/f"{stem}_TELEMETRY.csv"; report.write_text(json.dumps(result.report,indent=2,default=list)+"\n")
        fields=list(result.telemetry[0]) if result.telemetry else ["frame_id","t_sim_s"]
        with telemetry.open("w",newline="") as handle:
            writer=csv.DictWriter(handle,fieldnames=fields); writer.writeheader(); writer.writerows(result.telemetry)
        return report,telemetry

    def compare(self, config: Mapping[str, Any], modes: Sequence[AlgorithmMode], *, scenario: str, seeds: Sequence[int]) -> list[ExperimentResult]:
        result=[]
        for seed in seeds:
            for mode in modes:
                trial=deepcopy(dict(config)); trial["seed"]=int(seed); result.append(self.run(trial,mode,scenario=scenario))
        return result

    @staticmethod
    def export_comparison(results: Sequence[ExperimentResult], path: str | Path) -> Path:
        rows=[]
        for r in results:
            m=r.metrics; rows.append({"Scenario":r.scenario,"Seed":r.seed,"Algorithm":r.mode.value,"Acquisition Time":m.acquisition_time_s,"Avg Error":m.average_tracking_error_px,"RMS Error":m.rms_tracking_error_px,"Max Error":m.maximum_tracking_error_px,"Lock Retention":m.lock_retention_percent,"Loss Count":m.target_loss_count,"Avg Reacquisition":m.average_reacquisition_time_s,"FPS":m.effective_processing_fps,"Mean Latency":m.processing_timing["frame_pipeline"]["mean_ms"]})
        target=Path(path); target.parent.mkdir(parents=True,exist_ok=True)
        with target.open("w",newline="") as handle:
            writer=csv.DictWriter(handle,fieldnames=list(rows[0]) if rows else ["Scenario"]); writer.writeheader(); writer.writerows(rows)
        return target
