"""Metrics and telemetry collection; truth enters only at this evaluation boundary."""
from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from statistics import mean
from typing import Any, Iterable, Mapping

from core.contracts.camera import GroundTruthFrame
from core.contracts.simulation import Event
from core.contracts.tracking import TrackingOutput, TrackingStatus


def _stat(values: Iterable[float]) -> dict[str, float | None]:
    data = sorted(float(x) for x in values)
    if not data: return {"mean_ms": None, "max_ms": None, "p95_ms": None}
    index = max(0, math.ceil(.95 * len(data)) - 1)
    return {"mean_ms": mean(data), "max_ms": max(data), "p95_ms": data[index]}


@dataclass(frozen=True, slots=True)
class BenchmarkMetrics:
    simulation_duration_s: float
    execution_duration_s: float
    processed_frames: int
    configured_fps: float
    effective_processing_fps: float | None
    acquisition_time_s: float | None
    average_tracking_error_px: float | None
    rms_tracking_error_px: float | None
    maximum_tracking_error_px: float | None
    average_absolute_horizontal_error_px: float | None
    average_absolute_vertical_error_px: float | None
    valid_paired_frames: int
    missing_estimate_visible_frames: int
    lock_retention_percent: float | None
    eligible_visible_frames: int
    locked_valid_frames: int
    target_loss_count: int
    loss_timestamps_s: tuple[float, ...]
    loss_durations_s: tuple[float | None, ...]
    reacquisition_times_s: tuple[float, ...]
    average_reacquisition_time_s: float | None
    maximum_reacquisition_time_s: float | None
    processing_timing: Mapping[str, Mapping[str, float | None]]


class BenchmarkCollector:
    """Collect immutable joined observations. It never returns truth to the pipeline."""
    def __init__(self, *, lock_consecutive_frames: int = 3) -> None:
        self.lock_consecutive_frames = max(1, int(lock_consecutive_frames))
        self.telemetry: list[dict[str, Any]] = []
        self._errors: list[tuple[float, float, float]] = []
        self._visible = self._locked = self._missing = 0
        self._acquisition: float | None = None
        self._losses: list[float] = []
        self._open_loss: float | None = None
        self._reacq: list[float] = []
        self._run_started: float | None = None
        self._consecutive_measured = 0
        self._previous_locked = False
        self._timings: dict[str, list[float]] = {k: [] for k in ("camera_render", "disturbance", "perception", "tracking", "controller", "frame_pipeline")}

    @staticmethod
    def _truth(truth: GroundTruthFrame) -> tuple[float, float] | None:
        for item in truth.targets:
            if item.in_geometric_fov and item.image_center_px is not None:
                return item.image_center_px
        return None

    def record_events(self, events: Iterable[Event]) -> None:
        for event in events:
            if event.type == "RUN_STARTED": self._run_started = event.t_sim_s

    def record_frame(self, *, truth: GroundTruthFrame, tracking: TrackingOutput, detector_id: str,
                     controller_id: str, camera_pan_rad: float, camera_tilt_rad: float,
                     active_disturbances: tuple[str, ...], timings_ms: Mapping[str, float]) -> None:
        truth_pos = self._truth(truth)
        comparable = truth_pos is not None
        estimated = tracking.estimated_center_px
        if comparable: self._visible += 1
        if tracking.measured: self._consecutive_measured += 1
        else: self._consecutive_measured = 0
        locked = comparable and self._consecutive_measured >= self.lock_consecutive_frames and tracking.status in (TrackingStatus.TRACKING, TrackingStatus.REACQUIRED)
        if locked: self._locked += 1
        acquired_now = self._acquisition is None and tracking.measured and comparable
        if acquired_now: self._acquisition = tracking.t_sim_s - (self._run_started if self._run_started is not None else 0.0)
        if self._previous_locked and not locked and self._open_loss is None:
            self._losses.append(tracking.t_sim_s); self._open_loss = tracking.t_sim_s
        if self._open_loss is not None and tracking.status is TrackingStatus.REACQUIRED and tracking.measured:
            self._reacq.append(tracking.t_sim_s - self._open_loss); self._open_loss = None
        self._previous_locked = locked
        error_u = error_v = error = None
        if comparable and estimated is not None:
            error_u, error_v = estimated[0] - truth_pos[0], estimated[1] - truth_pos[1]
            error = math.hypot(error_u, error_v); self._errors.append((error_u, error_v, error))
        elif comparable: self._missing += 1
        for name, value in timings_ms.items():
            if name in self._timings and math.isfinite(value): self._timings[name].append(value)
        self.telemetry.append({
            "frame_id": tracking.frame_id, "t_sim_s": tracking.t_sim_s, "detector_mode": detector_id,
            "tracker_mode": tracking.status.value, "controller_mode": controller_id,
            "detection_confidence": tracking.confidence, "estimated_u_px": None if estimated is None else estimated[0],
            "estimated_v_px": None if estimated is None else estimated[1], "truth_u_px": None if truth_pos is None else truth_pos[0],
            "truth_v_px": None if truth_pos is None else truth_pos[1], "tracking_error_px": error,
            "horizontal_error_px": error_u, "vertical_error_px": error_v,
            "control_error_u_px": None if tracking.error_px is None else tracking.error_px[0],
            "control_error_v_px": None if tracking.error_px is None else tracking.error_px[1],
            "camera_pan_rad": camera_pan_rad, "camera_tilt_rad": camera_tilt_rad,
            "tracking_status": tracking.status.value, "measured": tracking.measured,
            "active_disturbances": "|".join(active_disturbances), **{f"{k}_ms": timings_ms.get(k) for k in self._timings},
        })

    def finish(self, *, simulation_duration_s: float, execution_duration_s: float) -> BenchmarkMetrics:
        errors = [x[2] for x in self._errors]
        loss_durations = tuple((r if i < len(self._reacq) else None) for i, r in enumerate(self._reacq))
        # A loss can remain open at the end; preserve it as unrecovered rather than making up a duration.
        if len(loss_durations) < len(self._losses): loss_durations += (None,) * (len(self._losses) - len(loss_durations))
        return BenchmarkMetrics(simulation_duration_s, execution_duration_s, len(self.telemetry),
            (len(self.telemetry) / simulation_duration_s) if simulation_duration_s else 0.0,
            (len(self.telemetry) / execution_duration_s) if execution_duration_s else None, self._acquisition,
            mean(errors) if errors else None, math.sqrt(mean(x*x for x in errors)) if errors else None, max(errors) if errors else None,
            mean(abs(x[0]) for x in self._errors) if self._errors else None, mean(abs(x[1]) for x in self._errors) if self._errors else None,
            len(errors), self._missing, (100 * self._locked / self._visible) if self._visible else None, self._visible, self._locked,
            len(self._losses), tuple(self._losses), loss_durations, tuple(self._reacq), mean(self._reacq) if self._reacq else None,
            max(self._reacq) if self._reacq else None, {k: _stat(v) for k, v in self._timings.items()})
