"""Deterministic target and beacon truth generation."""

from .generator import TargetGenerator

__all__ = ["TargetGenerator"]
