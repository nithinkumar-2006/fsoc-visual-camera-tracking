"""Target trajectory factory and deterministic truth generation."""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
import random
from typing import Callable, Iterable, Mapping

from core.contracts.simulation import TargetTruth, Vector3


def _v(value: Iterable[float], name: str) -> Vector3:
    values = tuple(float(x) for x in value)
    if len(values) != 3 or not all(math.isfinite(x) for x in values):
        raise ValueError(f"{name} must contain three finite numbers")
    return values  # type: ignore[return-value]


def _add(a: Vector3, b: Vector3) -> Vector3:
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _scale(a: Vector3, k: float) -> Vector3:
    return (a[0] * k, a[1] * k, a[2] * k)


@dataclass(frozen=True, slots=True)
class KinematicState:
    position: Vector3
    velocity: Vector3
    acceleration: Vector3


class Trajectory:
    """Extension point: implement reset() and state_at()."""

    def reset(self) -> None:
        pass

    def state_at(self, t_sim_s: float) -> KinematicState:
        raise NotImplementedError


class AnalyticTrajectory(Trajectory):
    def __init__(self, position: Vector3, velocity: Vector3, acceleration: Vector3) -> None:
        self.position, self.velocity, self.acceleration = position, velocity, acceleration


class StationaryTrajectory(AnalyticTrajectory):
    def state_at(self, t_sim_s: float) -> KinematicState:
        return KinematicState(self.position, (0.0, 0.0, 0.0), (0.0, 0.0, 0.0))


class LinearTrajectory(AnalyticTrajectory):
    def state_at(self, t_sim_s: float) -> KinematicState:
        return KinematicState(_add(self.position, _scale(self.velocity, t_sim_s)), self.velocity, (0.0, 0.0, 0.0))


class AcceleratedTrajectory(AnalyticTrajectory):
    def state_at(self, t_sim_s: float) -> KinematicState:
        p = _add(_add(self.position, _scale(self.velocity, t_sim_s)), _scale(self.acceleration, 0.5 * t_sim_s * t_sim_s))
        return KinematicState(p, _add(self.velocity, _scale(self.acceleration, t_sim_s)), self.acceleration)


class SinusoidalTrajectory(Trajectory):
    def __init__(self, base_position: Vector3, amplitude_m: float, frequency_hz: float, phase_rad: float, axis: Vector3) -> None:
        norm = math.sqrt(sum(x * x for x in axis))
        if norm == 0 or amplitude_m < 0 or frequency_hz < 0:
            raise ValueError("sinusoidal axis must be nonzero; amplitude/frequency must be non-negative")
        self.base_position, self.amplitude, self.frequency, self.phase = base_position, amplitude_m, frequency_hz, phase_rad
        self.axis = _scale(axis, 1.0 / norm)

    def state_at(self, t_sim_s: float) -> KinematicState:
        omega = 2.0 * math.pi * self.frequency
        angle = omega * t_sim_s + self.phase
        return KinematicState(
            _add(self.base_position, _scale(self.axis, self.amplitude * math.sin(angle))),
            _scale(self.axis, self.amplitude * omega * math.cos(angle)),
            _scale(self.axis, -self.amplitude * omega * omega * math.sin(angle)),
        )


class RandomMotionTrajectory(Trajectory):
    """Seeded random acceleration, integrated once per fixed simulation step."""

    def __init__(self, initial: KinematicState, seed: int, acceleration_std_mps2: float, max_speed_mps: float) -> None:
        if acceleration_std_mps2 < 0 or max_speed_mps <= 0:
            raise ValueError("random motion limits must be positive")
        self.initial, self.seed = initial, seed
        self.acceleration_std, self.max_speed = acceleration_std_mps2, max_speed_mps
        self.reset()

    def reset(self) -> None:
        self._rng = random.Random(self.seed)
        self._state = self.initial
        self._time = 0.0

    def state_at(self, t_sim_s: float) -> KinematicState:
        if t_sim_s < self._time - 1e-12:
            raise ValueError("random trajectory cannot move backwards; reset it first")
        while self._time < t_sim_s - 1e-12:
            # Simulation engine only asks at its validated fixed tick times.
            dt = min(t_sim_s - self._time, t_sim_s - self._time)
            a = tuple(self._rng.gauss(0.0, self.acceleration_std) for _ in range(3))
            new_v = _add(self._state.velocity, _scale(a, dt))
            speed = math.sqrt(sum(x * x for x in new_v))
            if speed > self.max_speed:
                new_v = _scale(new_v, self.max_speed / speed)
            new_p = _add(self._state.position, _add(_scale(self._state.velocity, dt), _scale(a, 0.5 * dt * dt)))
            self._state = KinematicState(new_p, new_v, a)  # type: ignore[arg-type]
            self._time = t_sim_s
        return self._state


class SuddenManeuverTrajectory(Trajectory):
    """Piecewise accelerated movement with explicitly scheduled changes."""

    def __init__(self, initial: KinematicState, maneuvers: list[Mapping[str, object]]) -> None:
        self.initial = initial
        parsed: list[tuple[float, Vector3 | None, Vector3 | None]] = []
        last = -1.0
        for item in maneuvers:
            at = float(item["at_s"])
            if at < 0 or at < last:
                raise ValueError("maneuvers must be non-negative and time-ordered")
            parsed.append((at, _v(item["velocity_w_mps"], "maneuver velocity") if "velocity_w_mps" in item else None,
                           _v(item["acceleration_w_mps2"], "maneuver acceleration") if "acceleration_w_mps2" in item else None))
            last = at
        self.maneuvers = parsed

    def state_at(self, t_sim_s: float) -> KinematicState:
        state, cursor = self.initial, 0.0
        for at, velocity, acceleration in self.maneuvers:
            if at > t_sim_s:
                break
            state = _integrate(state, at - cursor)
            state = KinematicState(state.position, velocity if velocity is not None else state.velocity,
                                   acceleration if acceleration is not None else state.acceleration)
            cursor = at
        return _integrate(state, t_sim_s - cursor)


def _integrate(state: KinematicState, dt: float) -> KinematicState:
    return KinematicState(_add(_add(state.position, _scale(state.velocity, dt)), _scale(state.acceleration, 0.5 * dt * dt)),
                          _add(state.velocity, _scale(state.acceleration, dt)), state.acceleration)


@dataclass(frozen=True, slots=True)
class VisibilitySchedule:
    default_enabled: bool
    intervals: tuple[tuple[float, float, bool], ...]

    def enabled_at(self, t_sim_s: float) -> bool:
        for start, end, enabled in self.intervals:
            if start <= t_sim_s < end:
                return enabled
        return self.default_enabled


@dataclass(slots=True)
class TargetRuntime:
    target_id: str
    designated: bool
    emission: float
    trajectory: Trajectory
    visibility: VisibilitySchedule


class TargetGenerator:
    """Owns target truth only; it deliberately exposes no detection/projection API."""

    def __init__(self, targets: list[TargetRuntime]) -> None:
        if not targets:
            raise ValueError("at least one target is required")
        ids = [t.target_id for t in targets]
        if len(set(ids)) != len(ids) or sum(t.designated for t in targets) != 1:
            raise ValueError("target ids must be unique and exactly one target designated")
        self._targets = tuple(targets)

    @classmethod
    def from_config(cls, configs: Iterable[Mapping[str, object]], experiment_seed: int) -> "TargetGenerator":
        return cls([_target_from_config(c, experiment_seed) for c in configs])

    def reset(self) -> None:
        for target in self._targets:
            target.trajectory.reset()

    def truth_at(self, t_sim_s: float) -> tuple[TargetTruth, ...]:
        return tuple(TargetTruth(t.target_id, t_sim_s, s.position, s.velocity, s.acceleration, t.emission,
                                 t.designated, t.visibility.enabled_at(t_sim_s))
                     for t in self._targets for s in (t.trajectory.state_at(t_sim_s),))


def _target_from_config(config: Mapping[str, object], experiment_seed: int) -> TargetRuntime:
    target_id = str(config["target_id"])
    p = _v(config["position_w_m"], "position_w_m")  # type: ignore[arg-type]
    velocity = _v(config.get("velocity_w_mps", (0, 0, 0)), "velocity_w_mps")  # type: ignore[arg-type]
    acceleration = _v(config.get("acceleration_w_mps2", (0, 0, 0)), "acceleration_w_mps2")  # type: ignore[arg-type]
    trajectory_data = config.get("trajectory", {"type": "stationary"})
    if not isinstance(trajectory_data, Mapping):
        raise ValueError("trajectory must be an object")
    kind = trajectory_data.get("type", "stationary")
    initial = KinematicState(p, velocity, acceleration)
    if kind == "stationary": trajectory: Trajectory = StationaryTrajectory(p, velocity, acceleration)
    elif kind == "linear": trajectory = LinearTrajectory(p, velocity, acceleration)
    elif kind == "accelerated": trajectory = AcceleratedTrajectory(p, velocity, acceleration)
    elif kind == "sinusoidal": trajectory = SinusoidalTrajectory(p, float(trajectory_data["amplitude_m"]), float(trajectory_data["frequency_hz"]), float(trajectory_data.get("phase_rad", 0.0)), _v(trajectory_data["axis_w"], "axis_w"))  # type: ignore[arg-type]
    elif kind == "random":
        material = f"{experiment_seed}:targets:{target_id}".encode("utf-8")
        seed = int.from_bytes(hashlib.sha256(material).digest()[:8], "big")
        trajectory = RandomMotionTrajectory(initial, seed, float(trajectory_data.get("acceleration_std_mps2", 1.0)), float(trajectory_data.get("max_speed_mps", 5.0)))
    elif kind == "sudden_maneuver":
        raw = trajectory_data.get("maneuvers", [])
        if not isinstance(raw, (list, tuple)): raise ValueError("maneuvers must be a list")
        trajectory = SuddenManeuverTrajectory(initial, raw)  # type: ignore[arg-type]
    else: raise ValueError(f"unsupported trajectory type: {kind}")
    vis = config.get("visibility", {})
    if not isinstance(vis, Mapping): raise ValueError("visibility must be an object")
    raw_intervals = vis.get("intervals", [])
    if not isinstance(raw_intervals, (list, tuple)): raise ValueError("visibility intervals must be a list")
    intervals = tuple((float(x["start_s"]), float(x["end_s"]), bool(x["enabled"])) for x in raw_intervals)  # type: ignore[union-attr]
    if any(start < 0 or end <= start for start, end, _ in intervals): raise ValueError("visibility intervals must have 0 <= start < end")
    return TargetRuntime(target_id, bool(config.get("designated", False)), float(config.get("emission", 1.0)), trajectory,
                         VisibilitySchedule(bool(vis.get("default_enabled", True)), intervals))
