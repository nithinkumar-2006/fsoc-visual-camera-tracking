"""Deterministic detection-only tracking baselines for the FSOC pipeline."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Protocol

from core.camera.model import PinholeCamera
from core.contracts.perception import DetectionResult
from core.contracts.tracking import TrackingInput, TrackingOutput, TrackingStatus


@dataclass(frozen=True, slots=True)
class TrackingConfig:
    """Observable-only association and short-dropout policy."""

    gating_radius_px: float = 30.0
    max_consecutive_misses: int = 3
    confidence_decay: float = 0.75
    min_detection_confidence: float = 0.0
    process_noise: float = 5.0
    measurement_noise: float = 4.0

    def __post_init__(self) -> None:
        if self.gating_radius_px <= 0 or self.max_consecutive_misses < 0:
            raise ValueError("gating_radius_px must be positive and max_consecutive_misses non-negative")
        if not 0 <= self.confidence_decay <= 1 or not 0 <= self.min_detection_confidence <= 1:
            raise ValueError("confidence values must be in [0, 1]")
        if self.process_noise <= 0 or self.measurement_noise <= 0:
            raise ValueError("Kalman noise parameters must be positive")


class Tracker(Protocol):
    def reset(self, config: TrackingConfig | None = None) -> None: ...
    def process(self, input: TrackingInput) -> TrackingOutput: ...
    def snapshot(self) -> dict[str, object]: ...
    def health(self) -> dict[str, object]: ...


class _BaseTracker:
    tracker_id = "base"

    def __init__(self, config: TrackingConfig | None = None) -> None: self.reset(config)

    def reset(self, config: TrackingConfig | None = None) -> None:
        self._config = config or TrackingConfig()
        self._position: tuple[float, float] | None = None
        self._velocity = (0.0, 0.0)
        self._last_t: float | None = None
        self._last_frame_id: int | None = None
        self._confidence = 0.0
        self._hits = self._misses = self._frames_processed = 0
        self._lost = False
        self._last_error: str | None = None

    def _validate(self, input: TrackingInput) -> None:
        if input.frame_id < 0 or not math.isfinite(input.t_sim_s): raise ValueError("frame_id and t_sim_s must be valid")
        if self._last_frame_id is not None and input.frame_id <= self._last_frame_id:
            raise ValueError("tracker requires strictly increasing frame_id")
        if self._last_t is not None and input.t_sim_s < self._last_t:
            raise ValueError("tracker requires nondecreasing t_sim_s")
        for d in input.detections:
            if d.frame_id != input.frame_id or d.t_sim_s != input.t_sim_s:
                raise ValueError("every detection must belong to TrackingInput frame/time")

    def _candidates(self, detections: tuple[DetectionResult, ...]) -> list[DetectionResult]:
        return [d for d in detections if d.confidence >= self._config.min_detection_confidence]

    def _associate(self, candidates: list[DetectionResult], predicted: tuple[float, float] | None) -> DetectionResult | None:
        if not candidates: return None
        if predicted is None:
            # Initial/reacquisition policy: confidence, then top-to-bottom and left-to-right.
            return min(candidates, key=lambda d: (-d.confidence, d.center_px[1], d.center_px[0]))
        within = [d for d in candidates if math.dist(d.center_px, predicted) <= self._config.gating_radius_px]
        if not within: return None
        return min(within, key=lambda d: (math.dist(d.center_px, predicted), -d.confidence, d.center_px[1], d.center_px[0]))

    def _output(self, input: TrackingInput, status: TrackingStatus, measured: bool) -> TrackingOutput:
        error = None if self._position is None else tuple(a - b for a, b in zip(self._position, PinholeCamera.principal_point(input.camera_state.resolution_px)))
        return TrackingOutput(input.frame_id, input.t_sim_s, None, self._position,
                              self._velocity if self._position is not None else None, error,
                              self._confidence, status, measured, self._hits, self._misses)

    def snapshot(self) -> dict[str, object]:
        return {"tracker_id": self.tracker_id, "config": asdict(self._config), "position_px": self._position,
                "velocity_pxps": self._velocity, "confidence": self._confidence, "hit_count": self._hits,
                "miss_count": self._misses, "frames_processed": self._frames_processed, "lost": self._lost}

    def health(self) -> dict[str, object]:
        return {"ok": self._last_error is None, "tracker_id": self.tracker_id,
                "frames_processed": self._frames_processed, "last_error": self._last_error}


class ReactiveTracker(_BaseTracker):
    """Centroid/continuity baseline: measurement follow with deterministic gating."""
    tracker_id = "centroid-reactive-v1"

    def process(self, input: TrackingInput) -> TrackingOutput:
        self._validate(input); dt = 0.0 if self._last_t is None else input.t_sim_s - self._last_t
        predicted = None if self._position is None else (self._position[0] + self._velocity[0] * dt, self._position[1] + self._velocity[1] * dt)
        detection = self._associate(self._candidates(input.detections), None if self._lost else predicted)
        was_lost = self._lost
        if detection is not None:
            old = self._position; self._position = detection.center_px
            if old is not None and dt > 0: self._velocity = ((self._position[0] - old[0]) / dt, (self._position[1] - old[1]) / dt)
            self._confidence = detection.confidence; self._hits += 1; self._misses = 0; self._lost = False
            status = TrackingStatus.REACQUIRED if was_lost else TrackingStatus.TRACKING; measured = True
        else:
            self._misses += 1; self._hits = 0; self._confidence *= self._config.confidence_decay
            if self._position is not None and self._misses <= self._config.max_consecutive_misses:
                self._position = predicted; status = TrackingStatus.COASTING; measured = False
            else:
                self._position = None; self._velocity = (0.0, 0.0); self._lost = True; status = TrackingStatus.LOST; measured = False
        self._last_t, self._last_frame_id = input.t_sim_s, input.frame_id; self._frames_processed += 1
        return self._output(input, status, measured)


class KalmanTracker(_BaseTracker):
    """Lightweight constant-velocity [u, v, du/dt, dv/dt] Kalman tracker."""
    tracker_id = "kalman-cv-v1"

    def reset(self, config: TrackingConfig | None = None) -> None:
        super().reset(config); self._x: list[float] | None = None; self._p: list[list[float]] | None = None

    def _predict(self, dt: float) -> tuple[float, float] | None:
        if self._x is None or self._p is None: return None
        f = [[1,0,dt,0],[0,1,0,dt],[0,0,1,0],[0,0,0,1]]
        self._x = [sum(f[i][j] * self._x[j] for j in range(4)) for i in range(4)]
        fp = [[sum(f[i][k] * self._p[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
        q = self._config.process_noise * max(dt, 1e-6)
        self._p = [[sum(fp[i][k] * f[j][k] for k in range(4)) + (q if i == j else 0.0) for j in range(4)] for i in range(4)]
        return (self._x[0], self._x[1])

    def _update(self, z: tuple[float, float]) -> None:
        assert self._x is not None and self._p is not None
        s00, s01 = self._p[0][0] + self._config.measurement_noise, self._p[0][1]
        s10, s11 = self._p[1][0], self._p[1][1] + self._config.measurement_noise
        det = s00 * s11 - s01 * s10; inv = [[s11/det, -s01/det], [-s10/det, s00/det]]
        k = [[self._p[i][0]*inv[0][j] + self._p[i][1]*inv[1][j] for j in range(2)] for i in range(4)]
        residual = [z[0] - self._x[0], z[1] - self._x[1]]
        self._x = [self._x[i] + k[i][0]*residual[0] + k[i][1]*residual[1] for i in range(4)]
        hp = [self._p[0][:], self._p[1][:]]
        self._p = [[self._p[i][j] - k[i][0]*hp[0][j] - k[i][1]*hp[1][j] for j in range(4)] for i in range(4)]

    def process(self, input: TrackingInput) -> TrackingOutput:
        self._validate(input); dt = 0.0 if self._last_t is None else input.t_sim_s - self._last_t
        predicted = self._predict(dt); detection = self._associate(self._candidates(input.detections), None if self._lost else predicted)
        was_lost = self._lost
        if detection is not None:
            if self._x is None: self._x = [detection.center_px[0], detection.center_px[1], 0.0, 0.0]; self._p = [[100.0 if i == j else 0.0 for j in range(4)] for i in range(4)]
            else: self._update(detection.center_px)
            self._position, self._velocity = (self._x[0], self._x[1]), (self._x[2], self._x[3])
            self._confidence = detection.confidence; self._hits += 1; self._misses = 0; self._lost = False; status = TrackingStatus.REACQUIRED if was_lost else TrackingStatus.TRACKING; measured = True
        else:
            self._misses += 1; self._hits = 0; self._confidence *= self._config.confidence_decay
            if predicted is not None and self._misses <= self._config.max_consecutive_misses:
                self._position, self._velocity = (self._x[0], self._x[1]), (self._x[2], self._x[3]); status = TrackingStatus.COASTING; measured = False
            else:
                self._position = None; self._velocity = (0.0, 0.0); self._x = self._p = None; self._lost = True; status = TrackingStatus.LOST; measured = False
        self._last_t, self._last_frame_id = input.t_sim_s, input.frame_id; self._frames_processed += 1
        return self._output(input, status, measured)
