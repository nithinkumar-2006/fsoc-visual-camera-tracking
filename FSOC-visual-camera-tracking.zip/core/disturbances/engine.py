"""Composable deterministic camera-observation disturbances.

This module deliberately has no dependency on perception, tracking, or control.
All pseudo-random values are a pure function of seed, stable disturbance name and
frame id, which makes replay independent of call order.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import math
import random
from typing import Any, Mapping

from core.camera import PinholeCamera
from core.contracts.camera import CameraFrame, CameraState, GroundTruthFrame
from core.contracts.simulation import Event
from core.simulation.engine import SimulationSnapshot


@dataclass(frozen=True, slots=True)
class DisturbanceSample:
    frame: CameraFrame
    ground_truth: GroundTruthFrame
    nominal_camera_state: CameraState
    effective_camera_state: CameraState
    active: tuple[str, ...]
    events: tuple[Event, ...]


class DisturbanceEngine:
    """Applies fixed-order pose then image effects to a public camera interface.

    Configuration is the canonical ``experiment.disturbances`` mapping. Each entry
    accepts enabled/start_s/end_s/severity plus type-specific numeric parameters.
    ``end_s`` is exclusive, making adjacent schedules unambiguous.
    """
    ORDER = ("platform_vibration", "camera_motion", "occlusion", "turbulence",
             "false_bright_objects", "sensor_noise", "motion_blur")

    def __init__(self, config: Mapping[str, Any] | None = None, *, experiment_seed: int = 0) -> None:
        self._config = dict(config or {})
        self._seed = int(experiment_seed)
        self._previous_active: set[str] = set()
        self._event_seq = 0

    @classmethod
    def from_experiment(cls, raw_experiment: Mapping[str, Any]) -> "DisturbanceEngine":
        return cls(raw_experiment.get("disturbances", {}), experiment_seed=int(raw_experiment.get("seed", 0)))

    def process(self, camera: PinholeCamera, snapshot: SimulationSnapshot) -> DisturbanceSample:
        t, fid = snapshot.context.t_sim_s, snapshot.context.frame_id
        entries = {name: self._entry(name) for name in self.ORDER}
        active = tuple(name for name in self.ORDER if self._active(entries[name], t))
        events = self._transition_events(set(active), t)
        nominal = replace(camera.state, t_sim_s=t)
        effective = self._effective_state(nominal, entries, t)
        occluded = frozenset(target.target_id for target in snapshot.targets
                             if self._active(entries["occlusion"], t))
        frame, truth = camera.observe(snapshot, observation_state=effective, occluded_target_ids=occluded)
        pixels = bytearray(frame.image_gray8)
        width, height = frame.resolution_px
        # Explicit deterministic image ordering; no mapping iteration affects output.
        if self._active(entries["turbulence"], t): self._turbulence(pixels, width, height, entries["turbulence"], fid)
        if self._active(entries["false_bright_objects"], t): self._false_spots(pixels, width, height, entries["false_bright_objects"], fid)
        if self._active(entries["sensor_noise"], t): self._noise(pixels, entries["sensor_noise"], fid)
        if self._active(entries["motion_blur"], t): self._blur(pixels, width, height, entries["motion_blur"])
        return DisturbanceSample(replace(frame, image_gray8=bytes(pixels)), truth, nominal, effective, active, events)

    def _entry(self, name: str) -> Mapping[str, Any]:
        # Supports both {type: {...}} and a list-like stable id cannot be ambiguous.
        entry = self._config.get(name, {})
        return entry if isinstance(entry, Mapping) else {}

    @staticmethod
    def _active(entry: Mapping[str, Any], t: float) -> bool:
        return bool(entry.get("enabled", False)) and float(entry.get("start_s", 0.0)) <= t < float(entry.get("end_s", math.inf))

    @staticmethod
    def _severity(entry: Mapping[str, Any]) -> float:
        return max(0.0, min(1.0, float(entry.get("severity", 1.0))))

    def _rng(self, name: str, frame_id: int) -> random.Random:
        token = f"{self._seed}:{name}:{frame_id}".encode()
        return random.Random(int.from_bytes(hashlib.blake2b(token, digest_size=8).digest(), "big"))

    def _effective_state(self, nominal: CameraState, entries: Mapping[str, Mapping[str, Any]], t: float) -> CameraState:
        pan = tilt = 0.0; dx = dy = dz = 0.0
        vibration = entries["platform_vibration"]
        if self._active(vibration, t):
            s = self._severity(vibration); freq = float(vibration.get("frequency_hz", 8.0)); phase = float(vibration.get("phase_rad", 0.0))
            pan += float(vibration.get("pan_amplitude_rad", vibration.get("amplitude_rad", 0.0))) * s * math.sin(2*math.pi*freq*t + phase)
            tilt += float(vibration.get("tilt_amplitude_rad", vibration.get("amplitude_rad", 0.0))) * s * math.sin(2*math.pi*freq*t + phase + float(vibration.get("tilt_phase_rad", math.pi/2)))
        motion = entries["camera_motion"]
        if self._active(motion, t):
            s = self._severity(motion); kind = str(motion.get("mode", "drift")); elapsed = t - float(motion.get("start_s", 0.0))
            scale = 1.0 if kind == "step" else (math.sin(2*math.pi*float(motion.get("frequency_hz", .25))*elapsed + float(motion.get("phase_rad", 0))) if kind == "sinusoidal" else elapsed)
            pan += s * float(motion.get("pan_rad", motion.get("pan_rate_radps", 0.0))) * scale
            tilt += s * float(motion.get("tilt_rad", motion.get("tilt_rate_radps", 0.0))) * scale
            offset = motion.get("position_offset_w_m", (0.0, 0.0, 0.0))
            if isinstance(offset, (tuple, list)) and len(offset) == 3: dx, dy, dz = (s * float(v) * scale for v in offset)
        return replace(nominal, pan_rad=nominal.pan_rad + pan, tilt_rad=nominal.tilt_rad + tilt,
                       position_w_m=(nominal.position_w_m[0]+dx, nominal.position_w_m[1]+dy, nominal.position_w_m[2]+dz))

    def _noise(self, pixels: bytearray, e: Mapping[str, Any], fid: int) -> None:
        sigma = float(e.get("sigma", e.get("intensity", 18.0))) * self._severity(e); rng = self._rng("sensor_noise", fid)
        for i, value in enumerate(pixels): pixels[i] = max(0, min(255, round(value + rng.gauss(0.0, sigma))))

    def _blur(self, pixels: bytearray, w: int, h: int, e: Mapping[str, Any]) -> None:
        radius = max(1, int(round(float(e.get("kernel", e.get("strength", 1))) * self._severity(e))))
        source = bytes(pixels); horizontal = str(e.get("direction", "horizontal")) != "vertical"
        for y in range(h):
            for x in range(w):
                values = [source[(y if horizontal else yy) * w + (xx if horizontal else x)] for d in range(-radius, radius+1)
                          for xx, yy in [(min(w-1,max(0,x+d)), min(h-1,max(0,y+d)))]]
                pixels[y*w+x] = sum(values)//len(values)

    def _false_spots(self, pixels: bytearray, w: int, h: int, e: Mapping[str, Any], fid: int) -> None:
        rng = self._rng("false_bright_objects", fid); count = int(e.get("count", 1)); intensity = int(max(0,min(255,float(e.get("intensity", 235))*self._severity(e))))
        size = max(1, int(e.get("size_px", 2))); positions = e.get("positions_px", ())
        for i in range(max(0, count)):
            if isinstance(positions, (list, tuple)) and i < len(positions) and len(positions[i]) == 2: cx, cy = map(int, positions[i])
            else: cx, cy = rng.randrange(w), rng.randrange(h)
            for y in range(max(0,cy-size), min(h,cy+size+1)):
                for x in range(max(0,cx-size), min(w,cx+size+1)):
                    if (x-cx)**2+(y-cy)**2 <= size**2: pixels[y*w+x] = max(pixels[y*w+x], intensity)

    def _turbulence(self, pixels: bytearray, w: int, h: int, e: Mapping[str, Any], fid: int) -> None:
        # Bounded shimmer/scintillation: cheap, deterministic approximation, not wave optics.
        rng = self._rng("turbulence", fid); sev = self._severity(e); shift_x = int(round(rng.uniform(-1,1)*float(e.get("jitter_px", 2))*sev)); shift_y = int(round(rng.uniform(-1,1)*float(e.get("jitter_px", 2))*sev)); scint = 1 + rng.uniform(-.35,.35)*sev
        source = bytes(pixels)
        for y in range(h):
            for x in range(w):
                sx, sy = min(w-1,max(0,x-shift_x)), min(h-1,max(0,y-shift_y))
                pixels[y*w+x] = max(0,min(255,round(source[sy*w+sx]*scint)))

    def _transition_events(self, active: set[str], t: float) -> tuple[Event, ...]:
        events: list[Event] = []
        for name in self.ORDER:
            if (name in active) != (name in self._previous_active):
                if name == "occlusion": event_type = "OCCLUSION_STARTED" if name in active else "OCCLUSION_ENDED"
                else: event_type = "DISTURBANCE_CHANGED"
                self._event_seq += 1; events.append(Event(f"dist-{self._event_seq:06d}", t, "INFO", event_type, None, {"disturbance": name, "active": name in active}))
        self._previous_active = active
        return tuple(events)
