"""Fixed-step, wall-clock-independent lifecycle and environment foundation."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import math
from types import MappingProxyType
from typing import Any, Mapping

from core.contracts.simulation import Event, FrameContext, TargetTruth
from core.targets.generator import TargetGenerator


class ConfigError(ValueError): pass


class LifecycleStatus(str, Enum):
    IDLE = "IDLE"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    STOPPED = "STOPPED"
    COMPLETED = "COMPLETED"
    FAULTED = "FAULTED"


@dataclass(frozen=True, slots=True)
class WorldEnvironment:
    bounds_w_m: tuple[tuple[float, float], tuple[float, float], tuple[float, float]] | None
    background: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class ExperimentConfig:
    schema_version: str
    experiment_id: str
    seed: int
    duration_s: float
    simulation_dt_s: float
    targets: tuple[Mapping[str, Any], ...]
    environment: WorldEnvironment
    raw: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class SimulationSnapshot:
    status: LifecycleStatus
    context: FrameContext
    targets: tuple[TargetTruth, ...]
    environment: WorldEnvironment


_TOP_LEVEL = {"schema_version", "experiment_id", "seed", "duration_s", "simulation_dt_s", "camera", "targets", "disturbances", "pipeline", "lock_policy", "benchmark", "export", "environment"}
_TARGET = {"target_id", "position_w_m", "velocity_w_mps", "acceleration_w_mps2", "designated", "emission", "visibility", "trajectory"}


def _freeze(value: Any) -> Any:
    """Prevent callers from changing a validated scenario after engine construction."""
    if isinstance(value, Mapping): return MappingProxyType({str(k): _freeze(v) for k, v in value.items()})
    if isinstance(value, list): return tuple(_freeze(v) for v in value)
    if isinstance(value, tuple): return tuple(_freeze(v) for v in value)
    return value


def validate_experiment_config(data: Mapping[str, Any]) -> ExperimentConfig:
    unknown = set(data) - _TOP_LEVEL
    required = {"schema_version", "experiment_id", "seed", "duration_s", "simulation_dt_s", "camera", "targets", "disturbances", "pipeline", "lock_policy", "benchmark", "export"}
    if unknown or required - set(data):
        raise ConfigError(f"invalid ExperimentConfig keys; unknown={sorted(unknown)}, missing={sorted(required - set(data))}")
    try:
        seed = int(data["seed"])
        duration, dt = float(data["duration_s"]), float(data["simulation_dt_s"])
    except (TypeError, ValueError) as exc:
        raise ConfigError("seed, duration_s and simulation_dt_s must be numeric") from exc
    if not math.isfinite(duration) or not math.isfinite(dt) or duration <= 0 or dt <= 0:
        raise ConfigError("duration_s and simulation_dt_s must be positive finite values")
    if not math.isclose(duration / dt, round(duration / dt), abs_tol=1e-9):
        raise ConfigError("duration_s must be an integer multiple of simulation_dt_s")
    camera = data["camera"]
    if not isinstance(camera, Mapping):
        raise ConfigError("camera must be an object")
    try:
        resolution = camera.get("resolution_px", (101, 101))
        if not isinstance(resolution, (list, tuple)) or len(resolution) != 2:
            raise ValueError("resolution")
        width, height = (int(resolution[0]), int(resolution[1]))
        hfov = float(camera.get("hfov_rad", math.pi / 2))
        vfov = float(camera.get("vfov_rad", math.pi / 2))
    except (TypeError, ValueError, OverflowError) as exc:
        raise ConfigError("camera resolution_px and FOV values must be numeric") from exc
    if width <= 0 or height <= 0 or not (0 < hfov < math.pi and 0 < vfov < math.pi):
        raise ConfigError("camera resolution must be positive and FOVs must be in (0, pi) radians")
    disturbances = data["disturbances"]
    # Older fixtures use [] to mean no disturbances; a configured mapping is strict.
    if isinstance(disturbances, Mapping):
        for name, entry in disturbances.items():
            if not isinstance(entry, Mapping):
                raise ConfigError(f"disturbance {name!r} must be an object")
            try:
                severity = float(entry.get("severity", 1.0))
                start = float(entry.get("start_s", 0.0))
                end = float(entry.get("end_s", math.inf))
            except (TypeError, ValueError) as exc:
                raise ConfigError(f"disturbance {name!r} has non-numeric schedule or severity") from exc
            if not (math.isfinite(severity) and 0.0 <= severity <= 1.0):
                raise ConfigError(f"disturbance {name!r} severity must be finite and within [0, 1]")
            if not (math.isfinite(start) and (math.isfinite(end) or end == math.inf) and start <= end):
                raise ConfigError(f"disturbance {name!r} schedule must satisfy finite start_s <= end_s")
    if not isinstance(data["targets"], list): raise ConfigError("targets must be a list")
    targets: list[Mapping[str, Any]] = []
    for t in data["targets"]:
        if not isinstance(t, Mapping) or set(t) - _TARGET:
            raise ConfigError("target has unknown fields or is not an object")
        if {"target_id", "position_w_m"} - set(t): raise ConfigError("each target requires target_id and position_w_m")
        targets.append(_freeze(t))
    env_data = data.get("environment", {})
    if not isinstance(env_data, Mapping) or set(env_data) - {"bounds_w_m", "background"}: raise ConfigError("invalid environment")
    bounds = env_data.get("bounds_w_m")
    parsed_bounds = None
    if bounds is not None:
        if not isinstance(bounds, (list, tuple)) or len(bounds) != 3: raise ConfigError("bounds_w_m must be three [min,max] pairs")
        parsed_bounds = tuple(tuple(float(x) for x in pair) for pair in bounds)  # type: ignore[assignment]
        if any(len(x) != 2 or x[0] >= x[1] for x in parsed_bounds): raise ConfigError("each world bound must be [min,max]")
    raw = _freeze(data)
    return ExperimentConfig(str(data["schema_version"]), str(data["experiment_id"]), int(data["seed"]), duration, dt, tuple(targets),
                            WorldEnvironment(parsed_bounds, MappingProxyType(dict(env_data.get("background", {})))), raw)


class SimulationEngine:
    """Public simulation boundary. Snapshots are immutable and state has no public mutators."""

    def __init__(self, config: ExperimentConfig) -> None:
        self._config = config
        self._targets = TargetGenerator.from_config(config.targets, config.seed)
        self._event_sequence = 0
        self.reset()

    @property
    def config(self) -> ExperimentConfig: return self._config

    @property
    def status(self) -> LifecycleStatus: return self._status

    def start(self) -> tuple[Event, ...]:
        if self._status is not LifecycleStatus.IDLE: raise RuntimeError("start is only valid from IDLE")
        self._status = LifecycleStatus.RUNNING
        return (self._event("RUN_STARTED", "INFO", {"experiment_id": self._config.experiment_id}),)

    def pause(self) -> None:
        if self._status is not LifecycleStatus.RUNNING: raise RuntimeError("pause is only valid while running")
        self._status = LifecycleStatus.PAUSED

    def resume(self) -> None:
        if self._status is not LifecycleStatus.PAUSED: raise RuntimeError("resume is only valid while paused")
        self._status = LifecycleStatus.RUNNING

    def stop(self) -> tuple[Event, ...]:
        if self._status not in (LifecycleStatus.RUNNING, LifecycleStatus.PAUSED): raise RuntimeError("stop is only valid for an active run")
        self._status = LifecycleStatus.STOPPED
        return (self._event("RUN_STOPPED", "INFO", {"reason": "operator_stop"}),)

    def fault(self, message: str) -> tuple[Event, ...]:
        """Contain an unrecoverable composed-runtime error without advancing time."""
        if self._status not in (LifecycleStatus.RUNNING, LifecycleStatus.PAUSED):
            raise RuntimeError("fault is only valid for an active run")
        self._status = LifecycleStatus.FAULTED
        self._snapshot = self._make_snapshot()
        return (self._event("RUN_FAULTED", "ERROR", {"message": str(message)}),)

    def reset(self) -> None:
        self._targets.reset()
        self._status, self._tick = LifecycleStatus.IDLE, 0
        self._snapshot = self._make_snapshot()

    def step(self) -> tuple[SimulationSnapshot, tuple[Event, ...]]:
        """Advance exactly one configured step; never consults wall-clock time."""
        if self._status is LifecycleStatus.PAUSED:
            return self._snapshot, ()
        if self._status is not LifecycleStatus.RUNNING:
            raise RuntimeError("step is only valid while running")
        self._tick += 1
        self._snapshot = self._make_snapshot()
        if self._snapshot.context.t_sim_s >= self._config.duration_s:
            self._status = LifecycleStatus.COMPLETED
            self._snapshot = self._make_snapshot()
            return self._snapshot, (self._event("RUN_STOPPED", "INFO", {"reason": "duration_completed"}),)
        return self._snapshot, ()

    def snapshot(self) -> SimulationSnapshot: return self._snapshot

    def _make_snapshot(self) -> SimulationSnapshot:
        t = self._tick * self._config.simulation_dt_s
        context = FrameContext(self._tick, self._tick, t, self._config.simulation_dt_s)
        return SimulationSnapshot(self._status, context, self._targets.truth_at(t), self._config.environment)

    def _event(self, event_type: str, severity: str, payload: Mapping[str, Any]) -> Event:
        self._event_sequence += 1
        return Event(f"sim-{self._event_sequence:06d}", self._tick * self._config.simulation_dt_s, severity, event_type, None, MappingProxyType(dict(payload)))
