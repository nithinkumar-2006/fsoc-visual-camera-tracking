"""Truth-isolated baseline controllers for virtual FSOC coarse alignment."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Protocol

from core.camera.model import PinholeCamera
from core.contracts.camera import CameraState
from core.contracts.control import ControlInput, ControlMode, TrackingCommand
from core.contracts.tracking import TrackingStatus


@dataclass(frozen=True, slots=True)
class ControllerConfig:
    kp_pan: float = 1.0
    kp_tilt: float = 1.0
    ki_pan: float = 0.0
    ki_tilt: float = 0.0
    kd_pan: float = 0.0
    kd_tilt: float = 0.0
    deadband_u_px: float = 0.0
    deadband_v_px: float = 0.0
    max_pan_rate_radps: float = 1.0
    max_tilt_rate_radps: float = 1.0
    coast_gain_scale: float = 0.35
    reset_integral_on_lost: bool = True

    def __post_init__(self) -> None:
        values = (self.kp_pan, self.kp_tilt, self.ki_pan, self.ki_tilt, self.kd_pan, self.kd_tilt,
                  self.deadband_u_px, self.deadband_v_px, self.max_pan_rate_radps, self.max_tilt_rate_radps,
                  self.coast_gain_scale)
        if not all(math.isfinite(v) for v in values):
            raise ValueError("controller values must be finite")
        if self.deadband_u_px < 0 or self.deadband_v_px < 0 or self.max_pan_rate_radps < 0 or self.max_tilt_rate_radps < 0:
            raise ValueError("deadbands and rate limits must be non-negative")
        if not 0 <= self.coast_gain_scale <= 1:
            raise ValueError("coast_gain_scale must be in [0, 1]")


class Controller(Protocol):
    def reset(self, config: ControllerConfig | None = None) -> None: ...
    def process(self, input: ControlInput) -> TrackingCommand: ...
    def snapshot(self) -> dict[str, object]: ...
    def health(self) -> dict[str, object]: ...


def apply_tracking_command(camera: PinholeCamera, command: TrackingCommand, dt_s: float) -> CameraState:
    """Route a command through the camera's public final-limit authority."""
    return camera.apply_rate_request(command.pan_rate_cmd_radps, command.tilt_rate_cmd_radps, dt_s, t_sim_s=command.t_sim_s + dt_s)


class _BaseController:
    controller_id = "base"

    def __init__(self, config: ControllerConfig | None = None) -> None:
        self.reset(config)

    def reset(self, config: ControllerConfig | None = None) -> None:
        self._config = config or ControllerConfig()
        self._last_t: float | None = None
        self._last_frame_id: int | None = None
        self._frames_processed = 0
        self._last_error: str | None = None

    def _validate(self, input: ControlInput) -> None:
        output = input.tracking
        if output.frame_id < 0 or not math.isfinite(output.t_sim_s):
            raise ValueError("tracking frame/time must be valid")
        if self._last_frame_id is not None and output.frame_id <= self._last_frame_id:
            raise ValueError("controller requires strictly increasing frame_id")
        if self._last_t is not None and output.t_sim_s < self._last_t:
            raise ValueError("controller requires nondecreasing simulation time")

    @staticmethod
    def _normalised(error_px: tuple[float, float], state: CameraState, config: ControllerConfig) -> tuple[float, float]:
        # Half-image dimensions make gains resolution independent and preserve image sign.
        width, height = state.resolution_px
        u, v = error_px
        u = 0.0 if abs(u) <= config.deadband_u_px else u
        v = 0.0 if abs(v) <= config.deadband_v_px else v
        return (u / max(1.0, (width - 1) / 2.0), v / max(1.0, (height - 1) / 2.0))

    def _neutral(self, input: ControlInput) -> TrackingCommand:
        out = input.tracking
        return TrackingCommand(out.frame_id, out.t_sim_s, out.target_id, ControlMode.NO_TRACK, 0.0, 0.0, self.controller_id)

    def _eligible(self, input: ControlInput) -> tuple[bool, float, ControlMode]:
        out = input.tracking
        if out.status is TrackingStatus.LOST or out.estimated_center_px is None or out.error_px is None:
            return False, 0.0, ControlMode.NO_TRACK
        if out.measured:
            return True, 1.0, ControlMode.TRACK
        if out.status is TrackingStatus.COASTING:
            return True, self._config.coast_gain_scale, ControlMode.COAST
        return False, 0.0, ControlMode.NO_TRACK

    def _finish(self, input: ControlInput, command: TrackingCommand) -> TrackingCommand:
        self._last_t, self._last_frame_id = input.tracking.t_sim_s, input.tracking.frame_id
        self._frames_processed += 1
        return command

    def snapshot(self) -> dict[str, object]:
        return {"controller_id": self.controller_id, "config": asdict(self._config), "frames_processed": self._frames_processed}

    def health(self) -> dict[str, object]:
        return {"ok": self._last_error is None, "controller_id": self.controller_id, "frames_processed": self._frames_processed, "last_error": self._last_error}


class ProportionalController(_BaseController):
    """Reactive bounded rate controller: +u maps +pan; +v maps -tilt."""
    controller_id = "proportional-v1"

    def process(self, input: ControlInput) -> TrackingCommand:
        self._validate(input)
        eligible, scale, mode = self._eligible(input)
        if not eligible:
            return self._finish(input, self._neutral(input))
        eu, ev = self._normalised(input.tracking.error_px, input.camera_state, self._config)  # type: ignore[arg-type]
        requested_pan, requested_tilt = self._config.kp_pan * eu * scale, -self._config.kp_tilt * ev * scale
        pan = max(-self._config.max_pan_rate_radps, min(self._config.max_pan_rate_radps, requested_pan))
        tilt = max(-self._config.max_tilt_rate_radps, min(self._config.max_tilt_rate_radps, requested_tilt))
        cmd = TrackingCommand(input.tracking.frame_id, input.tracking.t_sim_s, input.tracking.target_id, mode, pan, tilt,
                              self.controller_id, pan != requested_pan, tilt != requested_tilt, input.tracking.measured)
        return self._finish(input, cmd)


class PIDController(_BaseController):
    """Independent pan/tilt PID with conditional-integration anti-windup."""
    controller_id = "pid-v1"

    def reset(self, config: ControllerConfig | None = None) -> None:
        super().reset(config)
        self._integral = [0.0, 0.0]
        self._previous_error: tuple[float, float] | None = None

    def process(self, input: ControlInput) -> TrackingCommand:
        self._validate(input)
        eligible, scale, mode = self._eligible(input)
        if not eligible:
            if self._config.reset_integral_on_lost:
                self._integral = [0.0, 0.0]
                self._previous_error = None
            return self._finish(input, self._neutral(input))
        errors = self._normalised(input.tracking.error_px, input.camera_state, self._config)  # type: ignore[arg-type]
        dt = 0.0 if self._last_t is None else input.tracking.t_sim_s - self._last_t
        derivative = (0.0, 0.0) if dt <= 0 or self._previous_error is None else ((errors[0] - self._previous_error[0]) / dt, (errors[1] - self._previous_error[1]) / dt)
        # Use a candidate integral, only commit it if it does not push further into saturation.
        candidate = self._integral[:] if dt <= 0 else [self._integral[0] + errors[0] * dt, self._integral[1] + errors[1] * dt]
        raw_pan = (self._config.kp_pan * errors[0] + self._config.ki_pan * candidate[0] + self._config.kd_pan * derivative[0]) * scale
        raw_tilt = -(self._config.kp_tilt * errors[1] + self._config.ki_tilt * candidate[1] + self._config.kd_tilt * derivative[1]) * scale
        pan = max(-self._config.max_pan_rate_radps, min(self._config.max_pan_rate_radps, raw_pan))
        tilt = max(-self._config.max_tilt_rate_radps, min(self._config.max_tilt_rate_radps, raw_tilt))
        # Conditional integration prevents wind-up, but permits unwinding toward the legal range.
        if pan == raw_pan or raw_pan * errors[0] < 0:
            self._integral[0] = candidate[0]
        if tilt == raw_tilt or raw_tilt * (-errors[1]) < 0:
            self._integral[1] = candidate[1]
        self._previous_error = errors
        cmd = TrackingCommand(input.tracking.frame_id, input.tracking.t_sim_s, input.tracking.target_id, mode, pan, tilt,
                              self.controller_id, pan != raw_pan, tilt != raw_tilt, input.tracking.measured)
        return self._finish(input, cmd)

    def snapshot(self) -> dict[str, object]:
        value = super().snapshot()
        value.update({"integral": tuple(self._integral), "previous_error": self._previous_error})
        return value
