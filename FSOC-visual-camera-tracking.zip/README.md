# AI-Assisted Virtual Camera Tracking for Coarse Alignment of Mobile FSOC Terminals

A standalone, deterministic software platform for developing and comparing coarse Pointing, Acquisition and Tracking (PAT) algorithms for a moving optical beacon. It simulates a virtual camera, image disturbances, beacon detection, tracking and pan/tilt correction; it is **not** a physical FSOC link, fine-pointing system, or real-world link-performance validation.

## Capabilities

- Deterministic moving-beacon and pinhole-camera simulation
- Classical detection, reactive/Kalman tracking and proportional/PID control
- Lightweight model-backed beacon candidate classification/re-identification aid
- Vibration, camera motion, sensor noise, blur, occlusion, false bright objects and turbulence-like effects
- Same-seed fair benchmarks, CSV telemetry and JSON reports
- Offline Tkinter engineering console and localhost-only browser interface

## Architecture

`environment → beacon → virtual camera/disturbances → detector → tracker → controller → camera pose → metrics`

Ground truth is retained by the simulator and joined only by the benchmark collector after the runtime tracker/controller have run.

## Algorithm modes

| Mode | Pipeline |
|---|---|
| Baseline | Classical detector + reactive tracker + proportional controller |
| Classical Advanced | Classical detector + Kalman tracker + PID controller |
| AI Assisted | AI detector + Kalman tracker + PID controller |

## Scenarios

Clean Tracking, Vibration, Turbulence + Noise, False Bright Objects, Temporary Occlusion and Combined Stress.

## Quick start

Requires Python 3.11+ with Tkinter. From the repository root:

```bash
python -m gui.desktop
```

Or start the local browser interface (no extra packages required):

```bash
python -m gui.web
```

Then open `http://127.0.0.1:8000`. The server rejects non-local bind addresses.

Run regression tests:

```bash
python -m unittest discover -v
```

## Benchmark outputs

`BENCHMARK_COMPARISON.csv` and `BENCHMARK_SAMPLE_REPORT.json` are recorded Combined Stress, seed 17, 3.0 simulated-second results. Application exports are written to `exports/` as CSV and JSON. See [RESULTS_SUMMARY.md](RESULTS_SUMMARY.md) for context and limits.

## Structure

`app/` composition layer; `core/` simulation, camera, disturbances, perception, tracking, control and benchmarking; `gui/` Tkinter and local web consoles; `assets/models/` model artifact; `tests/` regression suite; `exports/` generated evidence.

## Limitations

Validated path: Python/Tkinter simulation. Webcam, physical pan/tilt servos, a packaged executable and physical optical-link performance are not validated in this release.
