"""Local browser interface for the FSOC laboratory. Launch: python -m gui.web"""
from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import threading
import time
from dataclasses import fields, is_dataclass
from enum import Enum
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from app import ApplicationController
from app.orchestrator import PRESETS, REPOSITORY_ROOT
from core.benchmarking import AlgorithmMode, BenchmarkRunner

STATIC_ROOT = Path(__file__).resolve().parent / "web_static"
EXPORT_ROOT = REPOSITORY_ROOT / "exports"


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {field.name: _jsonable(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict) or hasattr(value, "items"):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_jsonable(item) for item in value]
    return value


class LaboratoryService:
    """Thread-safe adapter around the validated application composition layer."""

    def __init__(self) -> None:
        self.controller = ApplicationController()
        self.lock = threading.RLock()
        self.closed = threading.Event()
        self.worker = threading.Thread(target=self._tick_loop, daemon=True, name="fsoc-simulation")
        self.worker.start()

    def _tick_loop(self) -> None:
        while not self.closed.is_set():
            started = time.monotonic()
            with self.lock:
                self.controller.tick()
                interval = float(self.controller.config["simulation_dt_s"])
            self.closed.wait(max(0.001, interval - (time.monotonic() - started)))

    def close(self) -> None:
        self.closed.set()
        self.worker.join(timeout=1)

    def state(self, include_truth: bool = False) -> dict[str, Any]:
        with self.lock:
            snap = self.controller.snapshot()
            context = self.controller.engine.snapshot().context
            frame = None
            if snap.frame is not None:
                width, height = snap.frame.resolution_px
                frame = {
                    "id": snap.frame.frame_id,
                    "width": width,
                    "height": height,
                    "gray8": base64.b64encode(bytes(snap.frame.image_gray8)).decode("ascii"),
                }
            truth = []
            if include_truth and snap.truth is not None:
                truth = [list(target.image_center_px) for target in snap.truth.targets if target.image_center_px]
            return {
                "state": snap.state.value,
                "engine_status": self.controller.engine.status.value,
                "time_s": context.t_sim_s,
                "duration_s": self.controller.config["duration_s"],
                "preset": self.controller.preset_name,
                "algorithm": self.controller.mode.value,
                "presets": list(PRESETS),
                "algorithms": [mode.value for mode in AlgorithmMode],
                "disturbances": {
                    name: {
                        "enabled": bool(self.controller.config["disturbances"].get(name, {}).get("enabled", False)),
                        "severity": float(self.controller.config["disturbances"].get(name, {}).get("severity", 1.0)),
                    }
                    for name in self.controller.disturbance.ORDER
                },
                "frame": frame,
                "detections": [
                    {"bbox": list(item.bbox_xywh_px), "center": list(item.center_px), "confidence": item.confidence}
                    for item in snap.detections
                ],
                "estimate": None if snap.tracking is None else _jsonable(snap.tracking.estimated_center_px),
                "truth": truth,
                "telemetry": _jsonable(snap.telemetry),
                "events": _jsonable(snap.events),
                "history": _jsonable(self.controller.history[-400:]),
                "model_health": _jsonable(snap.model_health),
                "error": snap.error,
            }

    def command(self, body: dict[str, Any]) -> dict[str, Any]:
        action = body.get("action")
        with self.lock:
            if action in {"start", "pause", "stop", "reset"}:
                getattr(self.controller, action)()
            elif action == "preset":
                self.controller.select_preset(str(body["value"]))
            elif action == "algorithm":
                self.controller.select_algorithm(AlgorithmMode(str(body["value"])))
            elif action == "disturbance":
                self.controller.set_disturbance(
                    str(body["name"]), enabled=bool(body["enabled"]), severity=float(body.get("severity", 1.0))
                )
            else:
                raise ValueError(f"unsupported action: {action}")
        return self.state()

    def benchmark(self, trials: int) -> dict[str, Any]:
        if trials < 1 or trials > 10:
            raise ValueError("trials must be between 1 and 10")
        with self.lock:
            results = self.controller.run_benchmark(trials=trials)
            path = BenchmarkRunner.export_comparison(results, EXPORT_ROOT / "application_comparison.csv")
        return {"results": _jsonable(results), "download": f"/exports/{path.name}"}

    def export(self) -> dict[str, Any]:
        with self.lock:
            paths = self.controller.export(EXPORT_ROOT)
        return {"files": [{"name": path.name, "download": f"/exports/{path.name}"} for path in paths]}


class LaboratoryHandler(BaseHTTPRequestHandler):
    service: LaboratoryService
    server_version = "FSOCLocal/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def _send(self, status: int, data: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _json(self, status: int, payload: Any) -> None:
        self._send(status, json.dumps(payload, separators=(",", ":")).encode(), "application/json; charset=utf-8")

    def _body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length > 1_000_000:
            raise ValueError("request body is too large")
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/api/state":
                self._json(HTTPStatus.OK, self.service.state("truth=1" in parsed.query))
                return
            if parsed.path.startswith("/exports/"):
                name = Path(unquote(parsed.path.removeprefix("/exports/"))).name
                path = EXPORT_ROOT / name
                if not path.is_file():
                    self._json(HTTPStatus.NOT_FOUND, {"error": "export not found"})
                    return
                self._send(HTTPStatus.OK, path.read_bytes(), mimetypes.guess_type(path.name)[0] or "application/octet-stream")
                return
            name = "index.html" if parsed.path == "/" else Path(unquote(parsed.path)).name
            path = STATIC_ROOT / name
            if not path.is_file():
                self._json(HTTPStatus.NOT_FOUND, {"error": "not found"})
                return
            self._send(HTTPStatus.OK, path.read_bytes(), mimetypes.guess_type(path.name)[0] or "application/octet-stream")
        except Exception as exc:
            self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})

    def do_POST(self) -> None:  # noqa: N802
        try:
            body = self._body()
            if self.path == "/api/control":
                result = self.service.command(body)
            elif self.path == "/api/benchmark":
                result = self.service.benchmark(int(body.get("trials", 1)))
            elif self.path == "/api/export":
                result = self.service.export()
            else:
                self._json(HTTPStatus.NOT_FOUND, {"error": "not found"})
                return
            self._json(HTTPStatus.OK, result)
        except (KeyError, TypeError, ValueError, RuntimeError) as exc:
            self._json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
        except Exception as exc:
            self._json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})


def create_server(host: str = "127.0.0.1", port: int = 8000) -> tuple[ThreadingHTTPServer, LaboratoryService]:
    if host not in {"127.0.0.1", "localhost"}:
        raise ValueError("the FSOC web interface may only bind to localhost")
    service = LaboratoryService()
    handler = type("BoundLaboratoryHandler", (LaboratoryHandler,), {"service": service})
    return ThreadingHTTPServer((host, port), handler), service


def main() -> None:
    parser = argparse.ArgumentParser(description="FSOC local web laboratory")
    parser.add_argument("--host", default="127.0.0.1", choices=("127.0.0.1", "localhost"))
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    server, service = create_server(args.host, args.port)
    print(f"FSOC web laboratory running at http://{args.host}:{server.server_port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        service.close()


if __name__ == "__main__":
    main()
