"""Offline Tkinter engineering console. Launch: python -m gui.desktop"""
from __future__ import annotations
import math, tkinter as tk
from tkinter import ttk, messagebox
from app import ApplicationController
from core.benchmarking import AlgorithmMode, BenchmarkRunner

def show(v): return "—" if v is None else (f"{v:.2f}" if isinstance(v,float) else str(v))
class Laboratory(tk.Tk):
 def __init__(self):
  super().__init__(); self.title("FSOC Optical Tracking Simulation Laboratory"); self.geometry("1540x900"); self.configure(bg="#161b20"); self.controller=ApplicationController(); self.truth=tk.BooleanVar(value=False); self.running=True
  self._top(); self._main(); self.after(50,self._loop)
 def _top(self):
  b=ttk.Frame(self,padding=8); b.pack(fill="x"); ttk.Label(b,text="FSOC OPTICAL TRACKING LABORATORY",font=("TkDefaultFont",14,"bold")).pack(side="left",padx=8)
  self.preset=ttk.Combobox(b,values=list(__import__('app.orchestrator',fromlist=['PRESETS']).PRESETS),state="readonly",width=20);self.preset.set("Clean Tracking");self.preset.pack(side="left",padx=5);self.preset.bind("<<ComboboxSelected>>",lambda e:self._safe(lambda:self.controller.select_preset(self.preset.get())))
  for text,fn in [("Start",self.controller.start),("Pause",self.controller.pause),("Stop",self.controller.stop),("Reset",self.controller.reset),("Run Benchmark",self._benchmark),("Export Results",self._export)]: ttk.Button(b,text=text,command=lambda f=fn:self._safe(f)).pack(side="left",padx=3)
  self.timer=ttk.Label(b,text="t=0.00 s");self.timer.pack(side="right",padx=10)
 def _main(self):
  body=ttk.Panedwindow(self,orient="horizontal");body.pack(fill="both",expand=True,padx=8,pady=4); left=ttk.Labelframe(body,text="EXPERIMENT CONTROLS",padding=8,width=240); center=ttk.Frame(body); right=ttk.Labelframe(body,text="RUNTIME TELEMETRY",padding=8,width=280);body.add(left,weight=1);body.add(center,weight=4);body.add(right,weight=1)
  ttk.Label(left,text="Algorithm mode").pack(anchor="w");self.alg=ttk.Combobox(left,values=[x.value for x in AlgorithmMode],state="readonly",width=28);self.alg.set(AlgorithmMode.CLASSICAL_ADVANCED.value);self.alg.pack(fill="x");self.alg.bind("<<ComboboxSelected>>",lambda e:self._safe(lambda:self.controller.select_algorithm(AlgorithmMode(self.alg.get()))))
  ttk.Separator(left).pack(fill="x",pady=10);ttk.Label(left,text="Disturbances",font=("TkDefaultFont",10,"bold")).pack(anchor="w")
  self.dist={};
  for name in self.controller.disturbance.ORDER:
   v=tk.BooleanVar(value=False); self.dist[name]=v;ttk.Checkbutton(left,text=name.replace("_"," "),variable=v,command=lambda n=name,x=v:self._safe(lambda:self.controller.set_disturbance(n,enabled=x.get()))).pack(anchor="w")
  ttk.Checkbutton(left,text="Evaluation / Ground Truth",variable=self.truth).pack(anchor="w",pady=12)
  self.canvas=tk.Canvas(center,bg="#080d11",highlightthickness=1,highlightbackground="#4d5a63");self.canvas.pack(fill="both",expand=True); self.canvas.bind("<Configure>",lambda e:self._draw())
  self.state=ttk.Label(center,text="IDLE",font=("TkDefaultFont",14,"bold"));self.state.pack(anchor="w",pady=4)
  self.values={};
  for k in ("state","detector","tracker","controller","confidence","estimated","error","pan","tilt","fps","latency_ms","active"):
   row=ttk.Frame(right);row.pack(fill="x",pady=2);ttk.Label(row,text=k.replace("_"," ")+":",width=13).pack(side="left");x=ttk.Label(row,text="—");x.pack(side="right");self.values[k]=x
  bottom=ttk.Notebook(self);bottom.pack(fill="x",padx=8,pady=4); self.graph=tk.Canvas(bottom,height=145,bg="#10161a",highlightthickness=0);bottom.add(self.graph,text="Tracking Error / Pose");self.events=tk.Text(bottom,height=8,bg="#10161a",fg="#d8e0e5",state="disabled");bottom.add(self.events,text="Event Log")
 def _safe(self,f):
  try:f()
  except Exception as e:messagebox.showerror("FSOC operator message",str(e))
 def _loop(self):
  if self.running:
   s=self.controller.tick(); self.timer.configure(text=f"t={self.controller.engine.snapshot().context.t_sim_s:.2f} s"); self._update(s); self.after(50,self._loop)
 def _update(self,s):
  self.state.configure(text=s.state.value);t=s.telemetry
  vals={"state":s.state.value,"detector":t['detector'],"tracker":t['tracker'],"controller":t['controller'],"confidence":t['confidence'],"estimated":t['estimated'],"error":t['error'],"pan":t['pan'],"tilt":t['tilt'],"fps":t['fps'],"latency_ms":t['latency_ms'],"active":", ".join(s.active_disturbances) or "—"}
  for k,v in vals.items():self.values[k].configure(text=show(v))
  def event_line(e):
   if isinstance(e,dict): return f"{e['t_sim_s']:5.2f}  {e['type']}"
   return f"{e.t_sim_s:5.2f}  {e.type}"
  self.events.configure(state="normal");self.events.delete("1.0","end");self.events.insert("end","\n".join(event_line(e) for e in s.events));self.events.configure(state="disabled");self._draw(s);self._graph()
 def _draw(self,s=None):
  if s is None:s=self.controller.snapshot()
  c=self.canvas;c.delete("all");w,h=max(c.winfo_width(),10),max(c.winfo_height(),10); c.create_line(w/2,0,w/2,h,fill="#6f7d85");c.create_line(0,h/2,w,h/2,fill="#6f7d85");c.create_text(8,8,anchor="nw",fill="#c2d0d8",text="VIRTUAL CAMERA  •  live pipeline frame")
  if not s.frame:return
  fw,fh=s.frame.resolution_px; scale=min((w-20)/fw,(h-30)/fh);ox=(w-fw*scale)/2;oy=(h-fh*scale)/2+12
  # pixels deliberately shown as actual frame data, decimated only by canvas rendering.
  for y in range(fh):
   for x in range(fw):
    v=s.frame.image_gray8[y*fw+x]
    if v>30:c.create_rectangle(ox+x*scale,oy+y*scale,ox+(x+1)*scale,oy+(y+1)*scale,outline="",fill=f"#{v:02x}{v:02x}{v:02x}")
  for d in s.detections:
   x,y,bw,bh=d.bbox_xywh_px;c.create_rectangle(ox+x*scale,oy+y*scale,ox+(x+bw)*scale,oy+(y+bh)*scale,outline="#ffb000",width=2)
  if s.tracking and s.tracking.estimated_center_px:
   x,y=s.tracking.estimated_center_px;c.create_oval(ox+x*scale-4,oy+y*scale-4,ox+x*scale+4,oy+y*scale+4,outline="#42d3b1",width=2)
  if self.truth.get() and s.truth:
   for q in s.truth.targets:
    if q.image_center_px:
     x,y=q.image_center_px;c.create_line(ox+(x-5)*scale,oy+y*scale,ox+(x+5)*scale,oy+y*scale,fill="#ff4e5b",width=2);c.create_line(ox+x*scale,oy+(y-5)*scale,ox+x*scale,oy+(y+5)*scale,fill="#ff4e5b",width=2)
   c.create_text(8,h-8,anchor="sw",fill="#ff7180",text="EVALUATION / GROUND TRUTH")
 def _graph(self):
  c=self.graph;c.delete("all");w,h=max(c.winfo_width(),10),max(c.winfo_height(),10);hist=self.controller.history;c.create_text(8,8,anchor="nw",fill="#bccbd4",text="Error px (amber)  |  pan rad ×100 (cyan)")
  if len(hist)<2:return
  for key,color,scale in (("error","#e4a83b",1),("pan","#3bc6cf",100)):
   pts=[]
   vals=[x[key] for x in hist if x[key] is not None];m=max(max(map(abs,vals),default=1),1)
   for i,x in enumerate(hist):
    if x[key] is not None:pts += [10+i*(w-20)/(len(hist)-1),h-10-(x[key]*scale/m)*(h-25)]
   if len(pts)>=4:c.create_line(*pts,fill=color,width=2)
 def _benchmark(self):
  results=self.controller.run_benchmark(); out=BenchmarkRunner.export_comparison(results,"exports/application_comparison.csv");messagebox.showinfo("Benchmark complete",f"Actual comparison saved to {out}")
 def _export(self):
  paths=self.controller.export();messagebox.showinfo("Export complete","\n".join(map(str,paths)))
if __name__=="__main__":Laboratory().mainloop()
