"""Tkinter desktop interface for the FSOC operator laboratory."""
