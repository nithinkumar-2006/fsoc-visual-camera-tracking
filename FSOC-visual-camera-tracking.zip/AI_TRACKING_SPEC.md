# AI-Assisted Tracking Specification

## Purpose

The AI option improves discrimination between the rendered beacon and bright distractors before the existing Kalman/PID path. It operates on `CameraFrame` grayscale pixels only; it does not replace the classical detector, Kalman tracker, or controller.

## Model and inputs

`core.ai.LogisticBeaconModel` is a genuine, CPU-only binary logistic-regression model. Its version is `logistic-beacon-v1`; input schema is `blob-stats-v1`. For every threshold-connected image region, it consumes eight observable features: normalized peak/mean, log area, fill, local contrast, radial brightness drop, aspect ratio, and normalized patch energy. The bounded sigmoid output is the likelihood that the observed component resembles a rendered beacon under the training distribution. It is not a truth-distance confidence.

`AIAssistedBeaconDetector` creates candidates, scores each with the learned model, then multiplies likelihood by an explicit observable temporal-continuity term based on prior selected image centre. This re-identification term helps retain the same visually plausible beacon through distractors and short turbulence. No target ID, world coordinate, trajectory, or `GroundTruthFrame` is accepted by its inference API.

## Offline dataset, labels, and split

`python -m core.ai.training --output assets/models/beacon_logistic_v1.json` runs the simulator with deterministic train seeds 11–14, a beacon, sensor noise, and false bright objects. Candidate regions are extracted from rendered disturbed frames. Only in that offline utility, candidate centres are joined to `GroundTruthFrame`; distance <=4.5 px is label 1. Ground truth is not saved as a model feature and `core.ai.detector` never imports it.

The bundled model uses 120 samples (40 beacon / 80 non-beacon). Held-out evaluation uses seeds 71–74: different deterministic disturbance RNG sequences and false-spot positions. Training initializes weights to zero and uses fixed full-batch gradient descent, so the artifact is reproducible.

## Artifact, inference, fallback, and timing

The JSON artifact is `assets/models/beacon_logistic_v1.json`; it stores weights, standardization parameters, feature-schema/model versions, seeds and hyperparameters. `process(CameraFrame)` reports detector wall-clock `processing_ms` only; it never changes `t_sim_s`. A missing, invalid, or incompatible artifact leaves the detector healthy only when its explicit classical-candidate fallback is enabled; `health()` exposes `model_loaded`, `fallback_active`, and `last_error`.

## Limitations

This small model is trained on simulated radial beacons and simple distractors; performance may fall on unrepresented optical hardware, severe saturation, or arbitrary background texture. It is a candidate classifier—not an FSOC link-quality model—and must be retrained with representative simulator scenarios before claims about physical deployment.
