# MASTER ARCHITECTURE V2

**Project:** AI-Assisted Virtual Camera Tracking for Coarse Alignment of Mobile FSOC Terminals  
**Status:** Authoritative architecture and master integration contract  
**Scope:** Software-first, standalone simulation and algorithm-validation platform for coarse Pointing, Acquisition and Tracking (PAT).  

## 1. Purpose and scope

The application validates how a virtual pan-tilt camera detects, acquires, tracks and keeps a moving optical beacon within its field of view (FOV). It is **not** an end-to-end optical communication implementation, a cloud service, or a hardware-dependent project.

The mandatory closed loop is:

`Environment → beacon(s) → virtual camera image → detection → position estimate → tracker/controller → pan/tilt command → camera pose → measurement`

The simulation remains deterministic and repeatable when its seed and configuration are unchanged. Webcam validation and physical servo output are optional adapters only; neither may affect the simulation core.

### Architecture priorities

1. Official SIH requirements
2. Measurable tracking performance
3. Simulation correctness and reproducibility
4. Modular compatibility and reliability
5. Professional engineering GUI
6. Optional real-camera/hardware extensions

## 2. Operating model

The app runs a fixed-step simulation clock (`t_sim`) and a render loop. At each simulation tick, the engine updates truth state, applies disturbances, renders a synthetic camera frame, runs the selected perception/tracking/control pipeline, updates camera pose subject to mechanical limits, and records telemetry. Rendering may skip frames under load, but simulation and metric timestamps must remain correct.

```mermaid
flowchart LR
  A[Scenario config] --> B[Simulation Engine]
  B --> C[Truth + Target Generator]
  C --> D[Virtual Camera + Disturbance]
  D --> E[Detection / CV]
  E --> F[Tracking Algorithm]
  F --> G[Pan-Tilt Controller]
  G --> B
  B --> H[Benchmark + Logs]
  H --> I[GUI / Report Export]
```

## 3. Module boundaries

| Module | Owns | Inputs | Outputs | Must not own |
|---|---|---|---|---|
| Simulation Engine | clock, tick ordering, scenario lifecycle, reproducible RNG registry | `ExperimentConfig`, commands | `FrameContext`, lifecycle events | detection or control logic |
| Target/Beacon Generator | target kinematics, trajectories, visibility schedule, beacon appearance truth | target config, `t_sim` | `TargetTruth[]` | image disturbances/camera projection |
| Virtual Camera | camera pose, FOV projection, synthetic image formation, actuator limits | truth, `CameraState`, rendered disturbance field | `CameraFrame`, image-space truth | detector decisions |
| Disturbance Engine | vibration, camera motion, noise, blur, occlusion, false spots, turbulence | config, seed, time | `DisturbanceSample` | target truth or tracker state |
| Beacon Detection / CV | image-based candidate extraction and confidence | `CameraFrame` | `DetectionResult[]` | ground truth, pan/tilt commands |
| Tracking Algorithms | target association, state estimate, lock/lost/reacquire policy recommendation | detections, prior estimate, camera state | `TrackingOutput` | actuator implementation, metrics |
| Pan-Tilt/Control Engine | PID/reactive control, slew/angle limits, command application | tracking output, camera state | `TrackingCommand`, next camera pose request | image detection |
| Ground-Truth Engine | canonical truth snapshot/projection and evaluation joins | simulation truth/camera state | `GroundTruthFrame` | modifying physical simulated world |
| Performance & Benchmark Engine | metric computation, trials, comparison aggregation | joined telemetry/events | `MetricSnapshot`, reports | simulation outcomes |
| GUI/Application Layer | display, user input, view models | immutable snapshots/events | typed app commands | direct cross-module mutations |
| Logging/Report Generator | structured run logs, CSV/JSON, report tables | telemetry/config/metrics | export files | recalculating simulation state |
| Configuration/Experiment Manager | schema validation, presets, run matrix, seed assignment | JSON configs | validated configs/trial plans | runtime algorithm internals |
| Testing | contract, deterministic, unit, integration, benchmark tests | public interfaces | test evidence | production decisions |

## 4. Repository structure

```text
fsoc-virtual-tracker/
  app/                       # application composition root and desktop entry point
  core/
    contracts/               # versioned shared models, enums, interfaces only
    simulation/              # Simulation Engine
    targets/                 # Target/Beacon Generator
    camera/                  # Virtual Camera and projection
    disturbances/            # Disturbance Engine
    truth/                   # Ground-Truth Engine
    perception/              # detector implementations
    tracking/                # association, state estimators, policy algorithms
    control/                 # reactive/PID actuator controller
    benchmarking/            # metrics, trials, comparison
    logging/                 # telemetry writers, report builder
    configuration/           # schema, defaults, presets
  gui/                       # views, controls, charts, view models
  adapters/                  # optional webcam and future servo adapters
  assets/                    # icons, themes, sample scenarios
  experiments/               # versioned JSON scenarios and benchmark matrices
  tests/
    unit/ contract/ integration/ regression/ fixtures/
  docs/                      # report figures, user manual source
  exports/                   # gitignored run outputs
```

Only `core/contracts` may be imported by more than one core subsystem. A module may depend inward on contracts and its declared input interfaces, never on GUI or another module's private implementation. The composition root wires implementations together.

## 5. Shared integration contract

### 5.1 Coordinate systems, units, and time

| Name | Convention | Unit |
|---|---|---|
| World `W` | right-handed: X east/right, Y north/forward, Z up | m, m/s, m/s² |
| Camera body `C` | +X image-right, +Y image-down, +Z optical axis forward | m |
| Image `I` | origin top-left; `u` right, `v` down; principal point `(Wpx-1)/2,(Hpx-1)/2` | px |
| Pan | positive rotates optical axis right about world +Z | rad (UI may display °) |
| Tilt | positive rotates optical axis up | rad (UI may display °) |
| FOV | full horizontal/vertical angular extent | rad |
| Time | monotonic simulation time; wall-clock only for UI/file metadata | seconds |

All public timestamps use `t_sim_s: float`, start at `0.0`, are monotonically nondecreasing, and are never taken from system time. Every random disturbance source is seeded from `experiment.seed` plus its stable module name.

Projection is pinhole by default. A target is geometrically in FOV only if it is in front of the camera and its projected point is within `[0,Wpx) × [0,Hpx)` before sensor-level occlusion.

### 5.2 Canonical data models (language-neutral JSON notation)

```json
{
  "TargetTruth": {"target_id":"beacon-01","t_sim_s":12.500,"position_w_m":[12.1,35.2,4.0],"velocity_w_mps":[1.0,0.0,0.0],"acceleration_w_mps2":[0,0,0],"emission":1.0,"designated":true,"visible_truth":true},
  "CameraState": {"t_sim_s":12.500,"position_w_m":[0,0,2],"pan_rad":0.12,"tilt_rad":-0.03,"pan_rate_radps":0.2,"tilt_rate_radps":0.1,"hfov_rad":0.79,"vfov_rad":0.59,"resolution_px":[1280,720]},
  "GroundTruthFrame": {"t_sim_s":12.500,"targets":[{"target_id":"beacon-01","in_geometric_fov":true,"image_center_px":[644.2,351.8],"bbox_xywh_px":[638,346,12,12],"occluded":false}]},
  "DetectionResult": {"frame_id":1250,"t_sim_s":12.500,"detector_id":"centroid-threshold-v1","target_id":"beacon-01","bbox_xywh_px":[637,345,13,13],"center_px":[643.5,351.5],"confidence":0.93,"processing_ms":3.1,"status":"VALID"},
  "TrackingCommand": {"t_sim_s":12.500,"target_id":"beacon-01","mode":"TRACK","pan_rate_cmd_radps":0.19,"tilt_rate_cmd_radps":0.08,"source":"pid-v1"}
}
```

`target_id` is immutable within one experiment. `null` target IDs are allowed only for unassociated detections. Bounding boxes use `[x,y,width,height]`, are image-clipped, and must have positive width/height. Confidence is `[0,1]`. No perception or tracking interface receives ground truth except test fixtures and the Benchmark Engine.

### 5.3 State machine and events

`IDLE → SEARCHING → ACQUIRING → TRACKING → LOCKED`; `TRACKING/LOCKED → LOST → REACQUIRING → ACQUIRING`. `STOPPED` and `FAULTED` are terminal for a run.

`LOCKED` requires configurable consecutive valid associated detections and error below the lock threshold. `LOST` occurs after configured consecutive missed frames or an out-of-FOV condition. Search is a bounded raster/spiral scan; reacquisition is the first valid association after loss, followed by normal acquisition confirmation.

Events use `{event_id, t_sim_s, severity, type, target_id?, payload}`. Required types: `RUN_STARTED`, `TARGET_ACQUIRED`, `LOCK_ENTERED`, `LOCK_LOST`, `REACQUIRED`, `TARGET_OUT_OF_FOV`, `OCCLUSION_STARTED/ENDED`, `DISTURBANCE_CHANGED`, `RUN_STOPPED`, `RUN_FAULTED`.

### 5.4 Configuration contract

Each experiment is a validated JSON file with `schema_version`, `experiment_id`, `seed`, `duration_s`, `simulation_dt_s`, `camera`, `targets`, `disturbances`, `pipeline`, `lock_policy`, `benchmark`, and `export` sections. Unknown keys fail validation; configs are immutable after a run begins and are copied verbatim into exports.

`pipeline` names exactly one detector, one tracker, and one controller profile. Benchmark matrices may vary only declared fields; all non-varied fields, initial state, target trajectory, disturbance schedule, seed list, warm-up, duration, and scoring rules must remain identical across compared algorithms.

### 5.5 Disturbance contract

Each disturbance has `enabled`, `start_s`, `end_s`, `severity`, and deterministic parameters. Supported types are `platform_vibration`, `camera_motion`, `sensor_noise`, `motion_blur`, `occlusion`, `false_bright_objects`, `turbulence`. Camera motion and vibration change camera pose; image noise/blur/turbulence change rendered pixels; occlusion changes sensor-visible beacon state but not geometric truth; false bright objects produce image candidates but never a truth target. Disturbances expose their active state in telemetry.

## 6. Algorithm pipeline

1. **Centroid/reactive:** threshold or blob segmentation finds bright beacon candidates; selected centroid produces bounded proportional pan/tilt rate. Baseline for speed and explainability.
2. **PID-based:** uses image-center error `e=[u-u0,v-v0]` and PID control with anti-windup/saturation. Detection remains a separate CV stage.
3. **Kalman-filter-assisted:** predicts image/angle state between observations, gates associations, smooths noisy estimates, and bridges short dropouts. Control remains PID/reactive.
4. **Optical flow:** tracks an already acquired image feature between adjacent frames; only valid with adequate texture/continuity and must fall back to detector after confidence failure. It is not the primary acquisition method for an isolated blinking beacon.
5. **AI-assisted:** an interchangeable detector/re-identification model classifies beacon candidates under noise, blur, turbulence, partial occlusion and false bright distractors. It outputs boxes/centers/confidence only. Classical geometry, Kalman estimation, and constrained control still determine motion—AI does not replace safety-critical control logic.

All implementations implement: `reset(config)`, `process(input) -> output`, `snapshot()`, and `health()`. Inputs and outputs are contract DTOs; implementations cannot update GUI, metrics, truth, or other modules directly.

## 7. Metrics and benchmark definitions

Let `g_i=(u_g,v_g)` be truth image center and `p_i=(u_p,v_p)` be associated estimated center for evaluated frame `i`; `N` is the number of valid paired frames.

| Metric | Definition |
|---|---|
| Simulation duration | `t_end - t_start` in simulation seconds |
| FPS | processed frames divided by simulation duration; separately report rendered FPS if different |
| Per-frame tracking error | `e_i = sqrt((u_p-u_g)^2 + (v_p-v_g)^2)` px |
| Average error | `(1/N) Σ e_i` px |
| Maximum error | `max(e_i)` px |
| RMS error | `sqrt((1/N) Σ e_i²)` px |
| Horizontal/vertical error | `e_u=u_p-u0`, `e_v=v_p-v0`; control uses estimate relative to image center `(u0,v0)` |
| Acquisition time | `t(TARGET_ACQUIRED)-t(RUN_STARTED)`; report `NA` if never acquired |
| Lock retention rate | `locked_valid_frames / geometrically_visible_frames × 100%` |
| Processing time | mean/median/p95 detector+tracker+controller compute time per frame, ms |
| Frame-processing latency | completion timestamp minus frame capture simulation timestamp; report simulated pipeline latency and wall-clock profiling separately |
| Target-loss events | count of `LOCK_LOST` transitions |
| Reacquisition time | for each loss: `t(REACQUIRED)-t(LOCK_LOST)`; report mean and p95, `NA` if unrecovered |

Metrics exclude frames where the target is not geometrically visible from tracking-error aggregates, but occluded/undetected visible frames remain in lock retention and loss analysis. Every report records these denominators. Reports include seed, config hash, software version, chosen algorithm, platform, timestamp, and raw per-frame telemetry CSV plus summary JSON.

## 8. GUI specification

The desktop UI is a dark, restrained optical-tracking laboratory console. It prioritizes observation and controls over decorative dashboard cards.

| Region | Required content |
|---|---|
| Top command bar | run/pause/reset, scenario preset, experiment/benchmark launch, export report, clear emergency stop |
| Central viewport | virtual camera image, optical-axis crosshair, truth marker (clearly labeled/switchable), detected box/marker, selected target ID, FOV/lost overlay |
| Left control rail | target trajectory/position/velocity/acceleration/maneuver controls; camera FOV/pan-tilt limits; disturbance controls |
| Right status rail | state badge, algorithm selector, pan/tilt gauges, target/estimated coordinates, confidence, error, FPS and latency |
| Bottom analysis area | scrolling error-vs-time graph, telemetry table, event log, benchmark comparison table |

Truth overlays are visibly styled differently and can be hidden for a realistic demonstration. The UI sends typed commands to the application layer; it never controls module state by direct field mutation.

## 9. Logging, errors, exports, and packaging

Structured JSONL event logs use UTC wall-clock metadata plus `t_sim_s`. Frame telemetry is CSV; scenario, summary metrics, and benchmark comparisons are JSON and CSV. Failed exports must never corrupt a completed run; write to a temporary location then atomically publish.

Expected runtime faults are typed: `CONFIG_INVALID`, `ASSET_UNAVAILABLE`, `ALGORITHM_HEALTH_FAILED`, `NUMERIC_INVALID`, `EXPORT_FAILED`, `CAMERA_ADAPTER_UNAVAILABLE`. On a fault, emit `RUN_FAULTED`, preserve last valid snapshot/logs, show operator-actionable text, and stop only the affected run. No silent fallback between algorithms is allowed.

Package the local desktop application with bundled runtime, assets, presets, and an `exports/` folder. Startup requires no account, network, database, or cloud dependency. Optional webcam support is an adapter behind the same `CameraFrame` contract and must visibly label mode `REAL_CAMERA_VALIDATION`.

## 10. Testing contract

Every module must supply unit tests for public behavior, malformed input tests, and deterministic-seed tests. Contract tests verify DTO validation, units, coordinate direction, event transitions, and JSON schema compatibility. Integration tests run the complete loop with a fixed seed; regression fixtures assert metric ranges and event sequences. Benchmark tests run each selected algorithm using the exact same trial matrix. GUI tests verify state presentation and typed-command dispatch; they do not duplicate core simulation tests.

Acceptance minimums: a configured beacon can be acquired, centered by pan/tilt, lost during disappearance/occlusion, searched for, reacquired, and reported; all mandatory disturbances can be activated; a repeat run with the same config and seed produces identical truth/event sequence and statistically identical numerical metrics within documented floating-point tolerance.

## 11. Requirement Traceability Matrix

| Mandatory SIH need | Satisfying module(s) | Verification evidence |
|---|---|---|
| Configurable virtual environment and moving beacon(s) | Simulation Engine; Target/Beacon Generator | scenario test and rendered viewport |
| Position, velocity, acceleration, trajectories, maneuvers | Target/Beacon Generator | truth telemetry and maneuver fixture |
| Pan-tilt virtual camera, FOV, optical axis | Virtual Camera; Pan-Tilt/Control | pose/FOV unit and integration tests |
| Detect, estimate, acquire, continuously track beacon | Detection/CV; Tracking; Control | acquisition-to-lock run log |
| Ground truth and error calculation | Ground-Truth; Benchmark | paired frame telemetry and metric report |
| Keep target in FOV, loss, search and reacquisition | Control; Tracking; Simulation | loss/reacquisition event fixture |
| Vibration, camera motion, noise, blur, occlusion, false objects, turbulence | Disturbance Engine; Virtual Camera | one test/preset per disturbance |
| Interchangeable centroid, PID, Kalman, optical flow, AI | Perception; Tracking; Control; Configuration | identical benchmark matrix comparison |
| Real-time statistics and professional interface | GUI; Benchmark; Logging | live viewport and telemetry screenshot |
| Repeatable experiments and CSV/JSON reporting | Configuration; Benchmark; Logging | repeated-seed test and exported report |
| Standalone SIH deliverables | App; Logging; docs/; tests/ | packaged app, source, manual, report artifacts |

## 12. Specialist handoff rule

Before merging work, each specialist must: implement only its owned module; consume/emit contract models without local variants; add tests named after the contract they prove; document any new config field/schema migration; and obtain integration approval for any change to `core/contracts`, coordinate conventions, state events, or metric definitions. These four areas are versioned project-wide interfaces and cannot be changed unilaterally.
