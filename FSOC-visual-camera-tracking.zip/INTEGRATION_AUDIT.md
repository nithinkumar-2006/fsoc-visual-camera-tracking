# Role #12 Integration Audit

## Audited modules and interfaces

Audited `app/`, `gui/`, simulation, target generation, camera, disturbances, classical/AI perception, tracking, control, benchmarking, exports, assets, tests, contracts, and Role #3–#11 specs/handoffs. Checked Simulation→Camera→Disturbance→Perception→Tracking→Control→Camera plus Runtime→GUI/Benchmark/Export boundaries for public DTOs, frame IDs, `t_sim_s`, image coordinates, confidence and missing-value handling.

## Defects found and corrected

- AI model paths were relative to the process CWD. Model discovery is now repository-relative in live and benchmark pipelines.
- A runtime pipeline exception left the simulation engine running. `SimulationEngine.fault()` now contains it without advancing time and produces canonical `RUN_FAULTED`.
- The controller reached LOCKED without routing `LOCK_ENTERED`. It now emits the event once on the evidence-based transition.

## Truth-isolation audit

The detector gets `CameraFrame`; trackers get detections and camera state; controllers get tracking output and camera state. None accept `TargetTruth` or `GroundTruthFrame`. Truth is separately supplied to `BenchmarkCollector.record_frame` after tracking. Existing and added tests cover this separation.

## Determinism, lifecycle, and long-run evidence

Pause/reset replay and model discovery outside the repository CWD passed. Existing seeded replay tests verify same-seed repeatability and changed-seed stochastic variation. A 60-second combined-stress AI run completed 1,200 fixed steps with 1 loss, mean error 0.315 px, maximum error 1.273 px, finite telemetry, and no crash.

## Dependency/path audit and limitations

Runtime requires Python and Tkinter only. Model resolution is repository-relative; export directories are created on demand. Experiment presets are code-defined in the benchmark module rather than separate JSON files. GUI rendering is intentionally sanity-tested through controller integration rather than brittle pixel tests. Physical camera, optical link, and servo behavior remain outside this software simulation.
