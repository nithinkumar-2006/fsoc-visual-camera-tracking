# Final Demonstration Flow

```mermaid
flowchart TD
  A[Launch] --> B[Select Scenario]
  B --> C[Select Algorithm]
  C --> D[Start]
  D --> E[Acquire]
  E --> F[Track]
  F --> G[Disturb]
  G --> H[Lose]
  H --> I[Reacquire]
  I --> J[Benchmark]
  J --> K[Compare]
  K --> L[Export]
  L --> M[Reset]
```

Use **Clean Tracking** first. Then choose **Temporary Occlusion** or **Combined Stress**, press **Reset**, and start again so the preset takes effect from time zero. The truth overlay is evaluation-only and should be kept off for the realistic demonstration.
