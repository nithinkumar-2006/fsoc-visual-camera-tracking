# SIH Live Demo Script (about 4½ minutes)

| Time | Presenter says | Presenter clicks | Judge should observe |
|---|---|---|---|
| 0:00–0:30 | “Mobile FSOC terminals must first point a wide field-of-view camera toward the other terminal’s beacon. We validate that coarse alignment loop in software before expensive optical and pan/tilt hardware.” | Launch the app. | Engineering console and virtual camera. |
| 0:30–1:00 | “The loop is beacon, virtual camera, image disturbances, detector, tracker, controller and camera repositioning. Ground truth is only for scoring, not for driving the tracker.” | Point to crosshair, right telemetry and event log; keep truth overlay off. | Image-centre reference and telemetry. |
| 1:00–1:40 | “First, the clean case: it acquires the bright beacon and corrects camera pose to hold it near centre.” | Select Clean Tracking; choose Classical Advanced; Reset; Start. | State moves to Locked, cyan estimate and pose/error change. |
| 1:40–2:30 | “Now we introduce an observation failure. The physical geometry can remain valid while the camera cannot see the beacon; the tracker reports loss and then reacquires from new detections.” | Select Temporary Occlusion; Reset; Start. | Loss/reacquisition events and recovery. |
| 2:30–3:15 | “AI here is deliberately narrow: a lightweight logistic candidate classifier/re-identification aid. It scores observable blob features and continuity. Kalman prediction and PID control remain conventional and constrained.” | Select `ai-kalman-pid`; Reset; Start; briefly show model health. | AI detector mode and model-backed run. |
| 3:15–4:15 | “For fairness, benchmark runs use the same scenario and seed for every mode. This recorded Combined Stress run, seed 17 over 3 seconds, reports 0.602 px mean tracking error for AI/Kalman/PID; it is simulation evidence, not physical-link proof.” | Use Run Benchmark and open/view comparison CSV if already prepared. | Side-by-side modes and explicit metrics. |
| 4:15–4:45 | “The value is faster repeatable algorithm validation. Next is hardware-in-the-loop: a calibrated real camera, pan/tilt actuator and optical-link tests. We do not claim those are validated today.” | Export Results; Reset. | CSV/JSON outputs and safe finish. |

## Fallback if GUI fails

Say: “The software release was regression-tested with 63 passing tests.” Show `QA_REPORT.md`, `RESULTS_SUMMARY.md`, `BENCHMARK_COMPARISON.csv`, and `BENCHMARK_SAMPLE_REPORT.json`. Explain the same truth boundary and limitations; do not simulate a live result from memory.
