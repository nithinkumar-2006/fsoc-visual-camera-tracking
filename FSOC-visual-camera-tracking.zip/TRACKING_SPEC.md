# Tracking subsystem specification

## Public interface

`Tracker` implementations provide `reset(config)`, `process(input) -> output`,
`snapshot()`, and `health()`. They receive a `TrackingInput` containing a frame
ID, simulation time, camera state, and image-derived `DetectionResult` values.
They return `TrackingOutput` in image pixels.

## Truth isolation

Runtime tracking imports no truth contracts and accepts no `TargetTruth`,
`GroundTruthFrame`, projected truth position, designated-target flag, or hidden
target ID. `target_id` remains `None` because Role #5 detections are unassociated.
Truth is used only by integration-test assertions.

## Association and reactive tracking

Initial acquisition, and reacquisition after loss, select the observable
candidate with greatest confidence; ties resolve by smaller `v`, then smaller
`u`. While active, candidates outside `gating_radius_px` of the predicted image
position are rejected. The nearest remaining candidate wins; ties resolve by
higher confidence, then top-to-bottom/left-to-right position. This makes the
policy deterministic and avoids arbitrary distractor jumps.

`ReactiveTracker` treats the selected centroid as the measurement. Velocity is
the latest measured pixel displacement divided by `t_sim_s` delta.

## Centering error and lifecycle

`error_px = (estimated_u - principal_u, estimated_v - principal_v)`, with
`principal = ((width-1)/2, (height-1)/2)`. Positive horizontal error means the
beacon is right of the optical axis; positive vertical error means below.

On a miss, the tracker coasts using the last estimated velocity, marks
`measured=False`, and decays confidence. Once misses exceed
`max_consecutive_misses`, it emits `LOST` with no estimate. The first later
observable acquisition emits `REACQUIRED`. These are tracker-local evidence,
not a replacement for the application state machine.

## Kalman option

`KalmanTracker` uses a constant-velocity state `[u, v, du/dt, dv/dt]` and
transition `F=[[1,0,dt,0],[0,1,0,dt],[0,0,1,0],[0,0,0,1]]`. It predicts with
`x=Fx`, `P=FPFᵀ+Q`, gates candidates around the predicted `(u,v)`, then updates
with the position measurement through the standard `K=P Hᵀ(HPHᵀ+R)⁻¹` update.
It coasts and loses/reacquires under the same explicit policy.

## Extension point

Optical flow is deliberately not faked. A later optical-flow tracker can
implement the same `Tracker` protocol, using a real adjacent-frame feature
track and detector fallback after confidence failure.
