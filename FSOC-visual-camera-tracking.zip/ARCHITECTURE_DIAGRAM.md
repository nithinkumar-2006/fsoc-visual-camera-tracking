# Architecture and Truth Boundary

```mermaid
flowchart TD
  A[Experiment configuration + seed] --> B[Simulation engine / moving beacon]
  B --> C[Virtual camera]
  C --> D[Disturbance engine]
  D --> E[Camera frame]
  E --> F[Detector: classical or AI-assisted]
  F --> G[Tracker: reactive or Kalman]
  G --> H[Controller: proportional or PID]
  H --> C
  B --> I[Ground-truth frame]
  G --> J[Benchmark collector]
  I -. evaluation-only join .-> J
  J --> K[CSV telemetry / JSON report / comparison]
```

The solid path is the runtime algorithm path. Ground truth is produced from the simulated geometry, but it has no runtime API path into the detector, AI inference, tracker or controller. The dotted join occurs only after the tracker output is available, for offline error and benchmark calculation.

Camera body axes are image-right (+X), image-down (+Y), and optical-forward (+Z). Image origin is top-left; `u` increases right and `v` down. The image centre is `((W−1)/2, (H−1)/2)`. Pan positive is right and tilt positive is up; time is monotonic simulation time in seconds.
