# Role #8 Disturbance Handoff

Disturbance code lives in `core/disturbances/engine.py`. Construct it with `DisturbanceEngine.from_experiment(engine.config.raw)` and apply it after obtaining a `SimulationSnapshot`:

```python
sample = disturbances.process(camera, snapshot)
detections = detector.process(sample.frame)
tracking = tracker.process(TrackingInput(sample.frame.frame_id, sample.frame.t_sim_s,
                                          detections, sample.frame.camera_state))
```

`sample.frame` is the only object perception/tracking should receive. It is an ordinary disturbed `CameraFrame` and contains no truth identifiers. Benchmarking/logging may use `sample.ground_truth`, `nominal_camera_state`, `effective_camera_state`, `active`, and `events`.

The order is nominal pose → pose disturbances → render/occlusion → turbulence → false spots → noise → blur. All schedules use simulation time with an exclusive end boundary. Seeded effects use experiment seed + disturbance type + frame id, so a replay is stable regardless of call order.

Occlusion emits `OCCLUSION_STARTED`/`OCCLUSION_ENDED`; other activation transitions emit `DISTURBANCE_CHANGED`. Camera vibration/motion are temporary rendering offsets, not controller commands, so they do not permanently change the camera's state.

Run the complete regression suite from repository root:

```bash
python -m unittest discover -v
```
