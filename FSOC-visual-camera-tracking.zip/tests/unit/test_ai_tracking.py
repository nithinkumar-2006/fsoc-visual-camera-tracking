from __future__ import annotations
import math, os, tempfile, unittest
from core.ai import AIAssistedBeaconDetector,AIDetectorConfig,LogisticBeaconModel
from core.ai.features import candidates_from_frame,FEATURE_NAMES
from core.ai.training import generate_dataset
from core.camera import PinholeCamera
from core.contracts.camera import CameraFrame,CameraState
from core.contracts.control import ControlInput
from core.disturbances import DisturbanceEngine
from core.control import PIDController,apply_tracking_command
from core.simulation import SimulationEngine,validate_experiment_config
from core.tracking import KalmanTracker,TrackingConfig

ROOT=os.path.dirname(os.path.dirname(os.path.dirname(__file__))); MODEL=os.path.join(ROOT,"assets/models/beacon_logistic_v1.json")
def state(): return CameraState(0,(0,0,0),0,0,0,0,math.pi/2,math.pi/2,(101,101))
def frame(points=()):
 p=bytearray(101*101)
 for x,y,v in points:p[y*101+x]=v
 return CameraFrame(0,0,(101,101),bytes(p),state())
def config(seed=71,duration=1.): return validate_experiment_config({"schema_version":"2","experiment_id":"ai-test","seed":seed,"duration_s":duration,"simulation_dt_s":.1,"camera":{},"targets":[{"target_id":"beacon","position_w_m":[2,10,0],"designated":True}],"disturbances":{"sensor_noise":{"enabled":True,"severity":.15,"sigma":8},"turbulence":{"enabled":True,"severity":.5},"false_bright_objects":{"enabled":True,"count":2,"intensity":220,"size_px":2}},"pipeline":{},"lock_policy":{},"benchmark":{},"export":{}})

class AITest(unittest.TestCase):
 def test_features_are_observable_and_deterministic(self):
  a=candidates_from_frame(frame([(50,50,255),(49,50,160),(51,50,160)]),threshold=100); self.assertEqual(len(a),1); self.assertEqual(len(a[0].feature),len(FEATURE_NAMES)); self.assertEqual(a,candidates_from_frame(frame([(50,50,255),(49,50,160),(51,50,160)]),threshold=100))
 def test_data_split_and_actual_training(self):
  x,y=generate_dataset((31,32)); m=LogisticBeaconModel.train(x,y,epochs=60); self.assertEqual(len(x),len(y)); self.assertEqual(set(y),{0,1}); self.assertGreater(m.predict_proba(x[0]),-1)
  held,_=generate_dataset((71,)); self.assertNotEqual(x[0],held[0])
 def test_serialization_loading_and_bounds(self):
  x,y=generate_dataset((41,42)); m=LogisticBeaconModel.train(x,y,epochs=40)
  with tempfile.TemporaryDirectory() as d:
   path=os.path.join(d,"m.json");m.save(path); loaded=LogisticBeaconModel.load(path); self.assertEqual(m.predict_proba(x[0]),loaded.predict_proba(x[0])); self.assertTrue(all(0<=loaded.predict_proba(v)<=1 for v in x))
 def test_camera_frame_only_multiple_scoring_and_determinism(self):
  d=AIAssistedBeaconDetector(AIDetectorConfig(model_path=MODEL,threshold=.1)); f=frame([(50,50,255),(49,50,160),(51,50,160),(20,20,220),(21,20,220)])
  a,b=d.process(f),d.process(f);self.assertTrue(a);self.assertEqual([(x.bbox_xywh_px,x.confidence) for x in a],[(x.bbox_xywh_px,x.confidence) for x in b]);self.assertTrue(all(x.target_id is None for x in a)); self.assertFalse(hasattr(f,"ground_truth"))
 def test_missing_model_fallback_health(self):
  d=AIAssistedBeaconDetector(AIDetectorConfig(model_path="missing.json")); self.assertTrue(d.health()["fallback_active"]);self.assertTrue(d.process(frame([(1,1,255)])))
 def test_disturbed_inference_rejects_false_and_tracker_integration(self):
  e=SimulationEngine(config());e.start();cam=PinholeCamera(state());sample=DisturbanceEngine.from_experiment(e.config.raw).process(cam,e.snapshot());d=AIAssistedBeaconDetector(AIDetectorConfig(model_path=MODEL,threshold=.2));outs=d.process(sample.frame);self.assertTrue(outs); tr=KalmanTracker(TrackingConfig(gating_radius_px=50)); out=tr.process(__import__('core.contracts.tracking',fromlist=['TrackingInput']).TrackingInput(sample.frame.frame_id,sample.frame.t_sim_s,outs,sample.frame.camera_state));self.assertIsNotNone(out.estimated_center_px)
 def test_ai_kalman_pid_closed_loop(self):
  e=SimulationEngine(config(duration=2));e.start();cam=PinholeCamera(state());de=DisturbanceEngine.from_experiment(e.config.raw);det=AIAssistedBeaconDetector(AIDetectorConfig(model_path=MODEL,threshold=.2));tr=KalmanTracker(TrackingConfig(gating_radius_px=55));ctl=PIDController();errs=[]
  while e.status.name=="RUNNING":
   s=de.process(cam,e.snapshot());out=tr.process(__import__('core.contracts.tracking',fromlist=['TrackingInput']).TrackingInput(s.frame.frame_id,s.frame.t_sim_s,det.process(s.frame),s.frame.camera_state));cmd=ctl.process(ControlInput(out,s.frame.camera_state));apply_tracking_command(cam,cmd,e.snapshot().context.simulation_dt_s)
   if out.error_px:errs.append(math.hypot(*out.error_px))
   e.step()
  self.assertGreater(len(errs),10);self.assertTrue(all(math.isfinite(x) for x in errs));self.assertLess(errs[-1],errs[0])
