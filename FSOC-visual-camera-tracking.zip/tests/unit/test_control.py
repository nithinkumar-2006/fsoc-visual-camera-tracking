from __future__ import annotations

import math
import unittest

from core.camera import CameraLimits, PinholeCamera
from core.contracts.camera import CameraState
from core.contracts.control import ControlInput, ControlMode
from core.contracts.tracking import TrackingInput, TrackingOutput, TrackingStatus
from core.control import ControllerConfig, PIDController, ProportionalController, apply_tracking_command
from core.perception import BeaconDetector, BeaconDetectorConfig
from core.simulation import SimulationEngine, validate_experiment_config
from core.tracking import ReactiveTracker


def state(t=0.0, **changes):
    base = dict(t_sim_s=t, position_w_m=(0.0, 0.0, 0.0), pan_rad=0.0, tilt_rad=0.0,
                pan_rate_radps=0.0, tilt_rate_radps=0.0, hfov_rad=math.pi / 2, vfov_rad=math.pi / 2,
                resolution_px=(101, 101))
    base.update(changes)
    return CameraState(**base)


def tracking(frame=0, t=0.0, error=(0.0, 0.0), *, status=TrackingStatus.TRACKING, measured=True):
    center = (50.0 + error[0], 50.0 + error[1]) if status is not TrackingStatus.LOST else None
    return TrackingOutput(frame, t, "beacon", center, (0.0, 0.0) if center else None, error if center else None,
                          .9 if center else 0.0, status, measured, 1, 0)


def control_input(frame=0, t=0.0, error=(0.0, 0.0), **kwargs):
    return ControlInput(tracking(frame, t, error, **kwargs), state(t))


class ProportionalControlTests(unittest.TestCase):
    def test_zero_deadband_and_all_four_signs(self):
        c = ProportionalController(ControllerConfig(kp_pan=2, kp_tilt=2))
        self.assertEqual((c.process(control_input(0)).pan_rate_cmd_radps, c.process(control_input(1, .1)).tilt_rate_cmd_radps), (0.0, 0.0))
        # positive u/right -> positive pan; negative u/left -> negative pan.
        self.assertGreater(ProportionalController().process(control_input(0, error=(10, 0))).pan_rate_cmd_radps, 0)
        self.assertLess(ProportionalController().process(control_input(0, error=(-10, 0))).pan_rate_cmd_radps, 0)
        # positive v/below -> negative tilt; negative v/above -> positive tilt.
        self.assertLess(ProportionalController().process(control_input(0, error=(0, 10))).tilt_rate_cmd_radps, 0)
        self.assertGreater(ProportionalController().process(control_input(0, error=(0, -10))).tilt_rate_cmd_radps, 0)

    def test_gain_deadband_saturation_coast_and_lost(self):
        cfg = ControllerConfig(kp_pan=2, kp_tilt=2, deadband_u_px=2, deadband_v_px=3, max_pan_rate_radps=.1, max_tilt_rate_radps=.2, coast_gain_scale=.5)
        c = ProportionalController(cfg)
        self.assertEqual(c.process(control_input(0, error=(2, 3))).pan_rate_cmd_radps, 0.0)
        saturate = c.process(control_input(1, .1, (50, -50)))
        self.assertEqual((saturate.pan_rate_cmd_radps, saturate.tilt_rate_cmd_radps), (.1, .2)); self.assertTrue(saturate.saturated_pan and saturate.saturated_tilt)
        coast = c.process(control_input(2, .2, (10, 0), status=TrackingStatus.COASTING, measured=False))
        self.assertEqual(coast.mode, ControlMode.COAST); self.assertAlmostEqual(coast.pan_rate_cmd_radps, .1)
        lost = c.process(control_input(3, .3, status=TrackingStatus.LOST, measured=False))
        self.assertEqual((lost.mode, lost.pan_rate_cmd_radps, lost.tilt_rate_cmd_radps), (ControlMode.NO_TRACK, 0.0, 0.0))


class PIDControlTests(unittest.TestCase):
    def test_proportional_integral_derivative_reset_and_invalid_dt(self):
        p = PIDController(ControllerConfig(kp_pan=1, max_pan_rate_radps=10))
        self.assertAlmostEqual(p.process(control_input(0, 0, (25, 0))).pan_rate_cmd_radps, .5)
        i = PIDController(ControllerConfig(kp_pan=0, ki_pan=1, max_pan_rate_radps=10))
        i.process(control_input(0, 0, (25, 0)))
        self.assertAlmostEqual(i.process(control_input(1, 1, (25, 0))).pan_rate_cmd_radps, .5)
        d = PIDController(ControllerConfig(kp_pan=0, kd_pan=1, max_pan_rate_radps=10))
        d.process(control_input(0, 0, (0, 0)))
        self.assertAlmostEqual(d.process(control_input(1, 1, (25, 0))).pan_rate_cmd_radps, .5)
        d.reset(); self.assertEqual(d.snapshot()["integral"], (0.0, 0.0))
        same_time = d.process(control_input(0, 0, (25, 0)))
        self.assertTrue(math.isfinite(same_time.pan_rate_cmd_radps))

    def test_anti_windup_and_lost_reset(self):
        c = PIDController(ControllerConfig(ki_pan=10, max_pan_rate_radps=.1))
        c.process(control_input(0, 0, (50, 0))); c.process(control_input(1, 1, (50, 0))); c.process(control_input(2, 2, (50, 0)))
        self.assertLessEqual(abs(c.snapshot()["integral"][0]), 1.0)
        c.process(control_input(3, 3, status=TrackingStatus.LOST, measured=False))
        self.assertEqual(c.snapshot()["integral"], (0.0, 0.0))


class ClosedLoopControlTests(unittest.TestCase):
    @staticmethod
    def config(position, velocity=(0, 0, 0), dt=.05, duration=3):
        return validate_experiment_config({"schema_version":"2", "experiment_id":"control-loop", "seed":4, "duration_s":duration, "simulation_dt_s":dt,
            "camera":{}, "targets":[{"target_id":"beacon", "position_w_m":list(position), "velocity_w_mps":list(velocity), "designated":True}],
            "disturbances":{}, "pipeline":{}, "lock_policy":{}, "benchmark":{}, "export":{}})

    def run_loop(self, engine, camera, controller, count):
        detector = BeaconDetector(BeaconDetectorConfig(intensity_threshold=100, min_area_px=2, min_mean_intensity=100))
        tracker = ReactiveTracker(); errors = []; pans = []
        engine.start()
        for _ in range(count):
            snap = engine.snapshot(); frame, truth = camera.observe(snap)
            output = tracker.process(TrackingInput(frame.frame_id, frame.t_sim_s, detector.process(frame), frame.camera_state))
            command = controller.process(ControlInput(output, frame.camera_state))
            apply_tracking_command(camera, command, snap.context.simulation_dt_s)
            if output.error_px is not None: errors.append(abs(output.error_px[0]) + abs(output.error_px[1]))
            pans.append(camera.state.pan_rad)
            if engine.status.name == "RUNNING": engine.step()
        return errors, pans

    def test_stationary_closed_loop_converges_and_camera_limit_is_final(self):
        engine = SimulationEngine(self.config((3, 10, 0)))
        camera = PinholeCamera(state(), CameraLimits(-.5, .5, -.5, .5, .4, .4))
        errors, _ = self.run_loop(engine, camera, ProportionalController(ControllerConfig(kp_pan=1.5, kp_tilt=1.5, max_pan_rate_radps=.4, max_tilt_rate_radps=.4)), 40)
        self.assertGreater(len(errors), 5); self.assertLess(errors[-1], errors[0]); self.assertLessEqual(abs(camera.state.pan_rad), .5)

    def test_moving_target_is_continuously_corrected(self):
        engine = SimulationEngine(self.config((1.5, 10, 0), velocity=(.35, 0, 0)))
        camera = PinholeCamera(state())
        errors, pans = self.run_loop(engine, camera, PIDController(ControllerConfig(kp_pan=1.2, ki_pan=.05, kd_pan=.02, max_pan_rate_radps=.5, max_tilt_rate_radps=.5)), 45)
        self.assertGreater(pans[-1], pans[0]); self.assertLess(max(errors[-10:]), errors[0] * 1.5)


if __name__ == "__main__": unittest.main()
