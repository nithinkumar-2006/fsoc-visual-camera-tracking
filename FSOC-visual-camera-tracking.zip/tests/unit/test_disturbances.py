from __future__ import annotations

import math
import unittest

from core.camera import PinholeCamera
from core.contracts.camera import CameraState
from core.contracts.control import ControlInput
from core.contracts.tracking import TrackingInput, TrackingStatus
from core.control import ControllerConfig, ProportionalController, apply_tracking_command
from core.disturbances import DisturbanceEngine
from core.perception import BeaconDetector, BeaconDetectorConfig
from core.simulation import SimulationEngine, validate_experiment_config
from core.tracking import ReactiveTracker, TrackingConfig


def config(disturbances, *, seed=12, duration=1.0):
    return validate_experiment_config({"schema_version":"2", "experiment_id":"disturbance", "seed":seed, "duration_s":duration, "simulation_dt_s":.1,
        "camera":{}, "targets":[{"target_id":"beacon", "position_w_m":[2,10,0], "designated":True}], "disturbances":disturbances,
        "pipeline":{}, "lock_policy":{}, "benchmark":{}, "export":{}})


def camera():
    return PinholeCamera(CameraState(0, (0,0,0), 0,0,0,0, math.pi/2, math.pi/2, (101,101)))


class DisturbanceUnitTests(unittest.TestCase):
    def sample(self, disturbances, t_steps=0, seed=12):
        engine = SimulationEngine(config(disturbances, seed=seed)); engine.start()
        for _ in range(t_steps): engine.step()
        return DisturbanceEngine.from_experiment(engine.config.raw).process(camera(), engine.snapshot())

    def test_schedule_activation_deactivation_and_events(self):
        d={"sensor_noise":{"enabled":True,"start_s":.1,"end_s":.3,"severity":.5,"sigma":9}}
        engine=SimulationEngine(config(d)); engine.start(); de=DisturbanceEngine.from_experiment(engine.config.raw); cam=camera()
        a=de.process(cam,engine.snapshot()); engine.step(); b=de.process(cam,engine.snapshot()); engine.step(); c=de.process(cam,engine.snapshot()); engine.step(); z=de.process(cam,engine.snapshot())
        self.assertEqual(a.active, ()); self.assertIn("sensor_noise",b.active); self.assertIn("sensor_noise",c.active); self.assertEqual(z.active, ())
        self.assertEqual([e.type for e in b.events], ["DISTURBANCE_CHANGED"]); self.assertEqual([e.type for e in z.events], ["DISTURBANCE_CHANGED"])

    def test_seed_replay_and_different_seed(self):
        d={"sensor_noise":{"enabled":True,"severity":1,"sigma":25},"turbulence":{"enabled":True,"severity":1}}
        self.assertEqual(self.sample(d,seed=4).frame.image_gray8, self.sample(d,seed=4).frame.image_gray8)
        self.assertNotEqual(self.sample(d,seed=4).frame.image_gray8, self.sample(d,seed=5).frame.image_gray8)

    def test_vibration_motion_and_nominal_pose_separation(self):
        d={"platform_vibration":{"enabled":True,"amplitude_rad":.1,"frequency_hz":1,"phase_rad":math.pi/2}, "camera_motion":{"enabled":True,"mode":"step","pan_rad":.2,"position_offset_w_m":[1,0,0]}}
        result=self.sample(d)
        self.assertNotEqual(result.nominal_camera_state.pan_rad,result.effective_camera_state.pan_rad)
        self.assertEqual(result.nominal_camera_state.pan_rad,0); self.assertEqual(result.effective_camera_state.position_w_m[0],1)

    def test_noise_blur_bounds_false_objects_and_no_truth_leak(self):
        d={"sensor_noise":{"enabled":True,"sigma":30},"motion_blur":{"enabled":True,"kernel":2},"false_bright_objects":{"enabled":True,"count":1,"intensity":250,"size_px":2,"positions_px":[[80,80]]}}
        result=self.sample(d); detections=BeaconDetector(BeaconDetectorConfig(intensity_threshold=120,min_area_px=2,min_mean_intensity=100)).process(result.frame)
        self.assertTrue(all(0<=p<=255 for p in result.frame.image_gray8)); self.assertGreaterEqual(len(detections),2)
        self.assertFalse(hasattr(result.frame,"targets")); self.assertEqual(len(result.ground_truth.targets),1)

    def test_occlusion_preserves_geometric_truth_and_events(self):
        d={"occlusion":{"enabled":True,"start_s":0,"end_s":.2,"severity":1}}
        result=self.sample(d)
        self.assertTrue(result.ground_truth.targets[0].in_geometric_fov); self.assertTrue(result.ground_truth.targets[0].occluded); self.assertEqual(max(result.frame.image_gray8),0)
        self.assertEqual(result.events[0].type,"OCCLUSION_STARTED")

    def test_turbulence_is_bounded_and_composes(self):
        d={name:{"enabled":True,"severity":.5} for name in ("platform_vibration","camera_motion","sensor_noise","motion_blur","false_bright_objects","turbulence")}
        r=self.sample(d); self.assertEqual(set(r.active),set(d)); self.assertEqual(len(r.frame.image_gray8),101*101); self.assertTrue(all(0<=p<=255 for p in r.frame.image_gray8))


class DisturbanceClosedLoopTests(unittest.TestCase):
    def test_closed_loop_stays_stable_under_noise_and_vibration(self):
        d={"platform_vibration":{"enabled":True,"severity":1,"amplitude_rad":.004,"frequency_hz":3},"sensor_noise":{"enabled":True,"severity":.15,"sigma":8}}
        eng=SimulationEngine(config(d,duration=3)); cam=camera(); de=DisturbanceEngine.from_experiment(eng.config.raw); detector=BeaconDetector(BeaconDetectorConfig(intensity_threshold=105,min_area_px=2,min_mean_intensity=100)); tracker=ReactiveTracker(); controller=ProportionalController(ControllerConfig(kp_pan=1.2,kp_tilt=1.2,max_pan_rate_radps=.5,max_tilt_rate_radps=.5)); errors=[]; eng.start()
        while eng.status.name=="RUNNING":
            r=de.process(cam,eng.snapshot()); out=tracker.process(TrackingInput(r.frame.frame_id,r.frame.t_sim_s,detector.process(r.frame),r.frame.camera_state)); cmd=controller.process(ControlInput(out,r.frame.camera_state)); apply_tracking_command(cam,cmd,eng.snapshot().context.simulation_dt_s)
            if out.error_px: errors.append(sum(abs(x) for x in out.error_px))
            eng.step()
        self.assertGreater(len(errors),10); self.assertLess(errors[-1],errors[0])

    def test_occlusion_lost_no_track_then_reacquired(self):
        d={"occlusion":{"enabled":True,"start_s":.3,"end_s":.8}}
        eng=SimulationEngine(config(d,duration=1.3)); cam=camera(); de=DisturbanceEngine.from_experiment(eng.config.raw); det=BeaconDetector(); tr=ReactiveTracker(TrackingConfig(max_consecutive_misses=2)); ctl=ProportionalController(); statuses=[]; modes=[]; eng.start()
        while eng.status.name=="RUNNING":
            r=de.process(cam,eng.snapshot()); out=tr.process(TrackingInput(r.frame.frame_id,r.frame.t_sim_s,det.process(r.frame),r.frame.camera_state)); statuses.append(out.status); modes.append(ctl.process(ControlInput(out,r.frame.camera_state)).mode); eng.step()
        self.assertIn(TrackingStatus.LOST,statuses); self.assertIn(TrackingStatus.REACQUIRED,statuses); self.assertIn("NO_TRACK",[m.value for m in modes])

