from __future__ import annotations

import math
import unittest

from core.camera.model import PinholeCamera
from core.contracts.camera import CameraFrame, CameraState
from core.contracts.perception import DetectionStatus
from core.contracts.simulation import FrameContext, TargetTruth
from core.perception import BeaconDetector, BeaconDetectorConfig
from core.simulation.engine import LifecycleStatus, SimulationEngine, SimulationSnapshot, WorldEnvironment, validate_experiment_config


def state(resolution=(21, 21)):
    return CameraState(0.0, (0.0, 0.0, 0.0), 0.0, 0.0, 0.0, 0.0, math.pi / 2, math.pi / 2, resolution)


def frame(points=(), resolution=(21, 21), frame_id=4):
    width, height = resolution; image = bytearray(width * height)
    for x, y, value in points: image[y * width + x] = value
    return CameraFrame(frame_id, 0.4, resolution, bytes(image), state(resolution))


class BeaconDetectorTests(unittest.TestCase):
    def setUp(self): self.detector = BeaconDetector(BeaconDetectorConfig(intensity_threshold=100, min_area_px=1, min_mean_intensity=100))

    def test_camera_frame_only_bright_beacon_centroid_bbox_and_contract(self):
        result = self.detector.process(frame([(9, 10, 180), (10, 10, 240), (11, 10, 180)]))
        self.assertEqual(len(result), 1)
        detection = result[0]
        self.assertEqual((detection.frame_id, detection.t_sim_s, detection.target_id, detection.status), (4, .4, None, DetectionStatus.VALID))
        self.assertEqual(detection.bbox_xywh_px, (9, 10, 3, 1))
        self.assertAlmostEqual(detection.center_px[0], 10.0); self.assertAlmostEqual(detection.center_px[1], 10.0)
        self.assertGreaterEqual(detection.confidence, 0); self.assertLessEqual(detection.confidence, 1)

    def test_dark_and_below_threshold_frames_have_honest_no_detection(self):
        self.assertEqual(self.detector.process(frame()), ())
        self.assertEqual(self.detector.process(frame([(3, 3, 99)])), ())

    def test_multiple_candidates_are_independently_extracted(self):
        result = self.detector.process(frame([(2, 2, 200), (3, 2, 200), (17, 18, 250)]))
        self.assertEqual(len(result), 2)
        self.assertEqual({x.bbox_xywh_px for x in result}, {(2, 2, 2, 1), (17, 18, 1, 1)})
        self.assertTrue(all(x.target_id is None for x in result))

    def test_edge_candidates_are_clipped_and_valid(self):
        for x, y in ((0, 0), (20, 0), (0, 20), (20, 20)):
            with self.subTest(x=x, y=y):
                detection = self.detector.process(frame([(x, y, 255)]))[0]
                bx, by, bw, bh = detection.bbox_xywh_px
                self.assertEqual(detection.center_px, (float(x), float(y)))
                self.assertTrue(0 <= bx < 21 and 0 <= by < 21 and bw > 0 and bh > 0)
                self.assertLessEqual(bx + bw, 21); self.assertLessEqual(by + bh, 21)

    def test_deterministic_detection_except_processing_time(self):
        input_frame = frame([(5, 5, 240), (6, 5, 160)])
        first, second = self.detector.process(input_frame)[0], self.detector.process(input_frame)[0]
        self.assertEqual((first.frame_id, first.t_sim_s, first.detector_id, first.target_id, first.bbox_xywh_px, first.center_px, first.confidence, first.status),
                         (second.frame_id, second.t_sim_s, second.detector_id, second.target_id, second.bbox_xywh_px, second.center_px, second.confidence, second.status))

    def test_invalid_image_reset_and_health(self):
        bad = CameraFrame(1, 0.0, (2, 2), b"\x00", state((2, 2)))
        with self.assertRaises(ValueError): self.detector.process(bad)
        self.detector.process(frame([(1, 1, 255)]))
        self.assertEqual(self.detector.health()["frames_processed"], 1)
        self.detector.reset(BeaconDetectorConfig(intensity_threshold=200, min_area_px=1, min_mean_intensity=200))
        self.assertEqual(self.detector.snapshot()["frames_processed"], 0)
        self.assertEqual(self.detector.process(frame([(1, 1, 199)])), ())

    def test_role_three_four_five_pixel_pipeline_and_accuracy(self):
        config = validate_experiment_config({"schema_version":"2", "experiment_id":"perception-integration", "seed":1, "duration_s":1.0, "simulation_dt_s":0.1,
            "camera":{}, "targets":[{"target_id":"beacon", "position_w_m":[1,10,0], "designated":True}],
            "disturbances":{}, "pipeline":{}, "lock_policy":{}, "benchmark":{}, "export":{}})
        engine = SimulationEngine(config); engine.start()
        camera = PinholeCamera(state((101, 101)))
        image, ground_truth = camera.observe(engine.snapshot())
        # The detector accepts only this image object; truth stays assertion-only.
        detections = BeaconDetector(BeaconDetectorConfig(intensity_threshold=100, min_area_px=2, min_mean_intensity=100)).process(image)
        self.assertEqual(len(detections), 1)
        projected = ground_truth.targets[0].image_center_px
        self.assertIsNotNone(projected)
        self.assertAlmostEqual(detections[0].center_px[0], projected[0], delta=1.0)  # type: ignore[index]
        self.assertAlmostEqual(detections[0].center_px[1], projected[1], delta=1.0)  # type: ignore[index]


if __name__ == "__main__": unittest.main()
