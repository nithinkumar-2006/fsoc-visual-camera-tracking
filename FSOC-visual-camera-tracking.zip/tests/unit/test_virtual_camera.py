import math
import unittest

from core.camera.model import CameraLimits, PinholeCamera
from core.contracts.camera import CameraState
from core.contracts.simulation import FrameContext, TargetTruth
from core.simulation.engine import LifecycleStatus, SimulationSnapshot, WorldEnvironment, SimulationEngine, validate_experiment_config


def state(**changes):
    base = dict(t_sim_s=0.0, position_w_m=(0.0, 0.0, 0.0), pan_rad=0.0, tilt_rad=0.0,
                pan_rate_radps=0.0, tilt_rate_radps=0.0, hfov_rad=math.pi / 2,
                vfov_rad=math.pi / 2, resolution_px=(101, 101))
    base.update(changes)
    return CameraState(**base)


def truth(target_id, position, *, emission=1.0, visible=True):
    return TargetTruth(target_id, 0.0, position, (0, 0, 0), (0, 0, 0), emission, False, visible)


def snapshot(*targets, frame_id=7):
    return SimulationSnapshot(LifecycleStatus.RUNNING, FrameContext(frame_id, frame_id, 0.0, 0.1), tuple(targets), WorldEnvironment(None, {}))


class VirtualCameraTests(unittest.TestCase):
    def setUp(self): self.camera = PinholeCamera(state())

    def observe_one(self, position): return self.camera.observe(snapshot(truth("t", position)))

    def test_principal_point_and_focal_lengths(self):
        self.assertEqual(PinholeCamera.principal_point((101, 51)), (50.0, 25.0))
        fx, fy = PinholeCamera.focal_lengths_px(state(resolution_px=(100, 50)))
        self.assertAlmostEqual(fx, 50.0)
        self.assertAlmostEqual(fy, 25.0)

    def test_axis_directions_and_behind_rejection(self):
        for pos, expected in [((0, 10, 0), (50.0, 50.0)), ((2, 10, 0), "right"), ((-2, 10, 0), "left"), ((0, 10, 2), "above"), ((0, 10, -2), "below")]:
            _, gt = self.observe_one(pos)
            item = gt.targets[0]
            self.assertTrue(item.in_geometric_fov)
            if expected == "right": self.assertGreater(item.image_center_px[0], 50)  # type: ignore[index]
            elif expected == "left": self.assertLess(item.image_center_px[0], 50)  # type: ignore[index]
            elif expected == "above": self.assertLess(item.image_center_px[1], 50)  # type: ignore[index]
            elif expected == "below": self.assertGreater(item.image_center_px[1], 50)  # type: ignore[index]
            else: self.assertEqual(item.image_center_px, expected)
        _, gt = self.observe_one((0, -10, 0))
        self.assertFalse(gt.targets[0].in_geometric_fov)

    def test_fov_boundaries_and_pose_rotation(self):
        _, gt = self.observe_one((9.9, 10, 0))
        self.assertTrue(gt.targets[0].in_geometric_fov)
        _, gt = self.observe_one((10.1, 10, 0))
        self.assertFalse(gt.targets[0].in_geometric_fov)
        _, gt = self.observe_one((0, 10, 9.9))
        self.assertTrue(gt.targets[0].in_geometric_fov)
        self.camera.set_state(state(pan_rad=math.pi / 2))
        _, gt = self.camera.observe(snapshot(truth("t", (10, 0, 0))))
        self.assertTrue(gt.targets[0].in_geometric_fov)
        self.camera.set_state(state(tilt_rad=math.pi / 4))
        _, gt = self.camera.observe(snapshot(truth("t", (0, 10, 10))))
        self.assertTrue(gt.targets[0].in_geometric_fov)

    def test_multiple_targets_rendering_dimensions_and_determinism(self):
        s = snapshot(truth("a", (0, 10, 0)), truth("b", (2, 10, 0)), frame_id=12)
        frame_a, gt = self.camera.observe(s)
        frame_b, _ = self.camera.observe(s)
        self.assertEqual(len(gt.targets), 2)
        self.assertEqual(len(frame_a.image_gray8), 101 * 101)
        self.assertEqual(frame_a.image_gray8, frame_b.image_gray8)
        self.assertGreater(max(frame_a.image_gray8), 0)

    def test_emission_does_not_change_geometric_truth(self):
        frame, gt = self.camera.observe(snapshot(truth("t", (0, 10, 0), emission=0.0, visible=False)))
        self.assertTrue(gt.targets[0].in_geometric_fov)
        self.assertEqual(max(frame.image_gray8), 0)

    def test_truth_is_separate_from_detector_facing_frame(self):
        frame, gt = self.observe_one((0, 10, 0))
        self.assertFalse(hasattr(frame, "targets"))
        self.assertFalse(hasattr(frame, "ground_truth"))
        self.assertEqual(gt.targets[0].target_id, "t")

    def test_rate_and_angle_limits(self):
        cam = PinholeCamera(state(), CameraLimits(-0.1, 0.1, -0.2, 0.2, 0.5, 0.25))
        result = cam.apply_rate_request(10, 10, 1.0)
        self.assertEqual((result.pan_rad, result.tilt_rad, result.pan_rate_radps, result.tilt_rate_radps), (0.1, 0.2, 0.5, 0.25))

    def test_role_three_engine_snapshot_integration(self):
        config = validate_experiment_config({"schema_version":"2", "experiment_id":"camera-test", "seed":1, "duration_s":1.0, "simulation_dt_s":0.1,
            "camera":{}, "targets":[{"target_id":"beacon", "position_w_m":[0,10,0], "designated":True}],
            "disturbances":{}, "pipeline":{}, "lock_policy":{}, "benchmark":{}, "export":{}})
        engine = SimulationEngine(config)
        engine.start()
        frame, gt = self.camera.observe(engine.snapshot())
        self.assertEqual(frame.frame_id, engine.snapshot().context.frame_id)
        self.assertTrue(gt.targets[0].in_geometric_fov)
