from __future__ import annotations

import math
import unittest

from core.camera.model import PinholeCamera
from core.contracts.camera import CameraState
from core.contracts.perception import DetectionResult
from core.contracts.tracking import TrackingInput, TrackingStatus
from core.perception import BeaconDetector, BeaconDetectorConfig
from core.simulation.engine import SimulationEngine, validate_experiment_config
from core.tracking import KalmanTracker, ReactiveTracker, TrackingConfig


def state(t=0.0, resolution=(101, 101)):
    return CameraState(t, (0, 0, 0), 0, 0, 0, 0, math.pi / 2, math.pi / 2, resolution)


def detection(frame_id, t, x, y, confidence=0.9):
    return DetectionResult(frame_id, t, "test", None, (round(x), round(y), 1, 1), (x, y), confidence, 0.0)


def item(frame_id, t, detections=(), resolution=(101, 101)):
    return TrackingInput(frame_id, t, tuple(detections), state(t, resolution))


class ReactiveTrackerTests(unittest.TestCase):
    def test_initialization_velocity_error_and_truth_isolation(self):
        tracker = ReactiveTracker()
        first = tracker.process(item(0, 0, [detection(0, 0, 60, 45)]))
        second = tracker.process(item(1, 0.1, [detection(1, .1, 62, 47)]))
        self.assertEqual(first.status, TrackingStatus.TRACKING)
        self.assertEqual(second.error_px, (12.0, -3.0))
        self.assertEqual(second.velocity_pxps, (20.0, 20.0))
        self.assertTrue(second.measured)
        self.assertFalse(hasattr(item(0, 0), "ground_truth"))

    def test_deterministic_association_coast_loss_and_reacquire(self):
        tracker = ReactiveTracker(TrackingConfig(gating_radius_px=10, max_consecutive_misses=2, confidence_decay=.5))
        tracker.process(item(0, 0, [detection(0, 0, 20, 20, .95), detection(0, 0, 70, 70, .9)]))
        # Near the first acquired candidate, a higher-confidence distractor must not steal association.
        tracked = tracker.process(item(1, .1, [detection(1, .1, 22, 20, .6), detection(1, .1, 75, 70, .99)]))
        self.assertEqual(tracked.estimated_center_px, (22, 20))
        self.assertEqual(tracker.process(item(2, .2)).status, TrackingStatus.COASTING)
        self.assertEqual(tracker.process(item(3, .3)).status, TrackingStatus.COASTING)
        lost = tracker.process(item(4, .4)); self.assertEqual(lost.status, TrackingStatus.LOST); self.assertIsNone(lost.estimated_center_px)
        reacquired = tracker.process(item(5, .5, [detection(5, .5, 80, 20)]))
        self.assertEqual(reacquired.status, TrackingStatus.REACQUIRED); self.assertTrue(reacquired.measured)

    def test_reset_health_and_frame_validation(self):
        tracker = ReactiveTracker(); tracker.process(item(0, 0, [detection(0, 0, 1, 1)]))
        self.assertEqual(tracker.health()["frames_processed"], 1)
        tracker.reset(); self.assertEqual(tracker.snapshot()["frames_processed"], 0)
        with self.assertRaises(ValueError): tracker.process(item(1, .1, [detection(2, .1, 1, 1)]))


class KalmanTrackerTests(unittest.TestCase):
    def test_prediction_update_velocity_gating_and_reset(self):
        tracker = KalmanTracker(TrackingConfig(gating_radius_px=12, max_consecutive_misses=1, measurement_noise=.1, process_noise=.1))
        tracker.process(item(0, 0, [detection(0, 0, 10, 10)]))
        tracker.process(item(1, 1, [detection(1, 1, 20, 10)]))
        updated = tracker.process(item(2, 2, [detection(2, 2, 30, 10), detection(2, 2, 90, 90, 1.0)]))
        self.assertAlmostEqual(updated.estimated_center_px[0], 30, delta=1.0)  # type: ignore[index]
        self.assertGreater(updated.velocity_pxps[0], 5)  # type: ignore[index]
        coast = tracker.process(item(3, 3)); self.assertEqual(coast.status, TrackingStatus.COASTING); self.assertFalse(coast.measured)
        self.assertEqual(tracker.process(item(4, 4)).status, TrackingStatus.LOST)
        tracker.reset(); self.assertEqual(tracker.snapshot()["frames_processed"], 0)

    def test_determinism(self):
        def run():
            tracker = KalmanTracker()
            return [tracker.process(item(i, i*.1, [detection(i, i*.1, 10+i, 20)])) for i in range(3)]
        self.assertEqual(run(), run())


class TrackingIntegrationTests(unittest.TestCase):
    def test_role_three_to_six_pipeline(self):
        config = validate_experiment_config({"schema_version":"2", "experiment_id":"tracking-integration", "seed":1, "duration_s":.3, "simulation_dt_s":.1,
            "camera":{}, "targets":[{"target_id":"beacon", "position_w_m":[0,10,0], "velocity_w_mps":[1,0,0], "designated":True}], "disturbances":{}, "pipeline":{}, "lock_policy":{}, "benchmark":{}, "export":{}})
        engine = SimulationEngine(config); engine.start()
        camera = PinholeCamera(state(resolution=(101, 101)))
        detector = BeaconDetector(BeaconDetectorConfig(intensity_threshold=100, min_area_px=2, min_mean_intensity=100))
        tracker = ReactiveTracker(); outputs = []
        for _ in range(3):
            snapshot = engine.snapshot(); frame, truth = camera.observe(snapshot)
            output = tracker.process(TrackingInput(frame.frame_id, frame.t_sim_s, detector.process(frame), frame.camera_state)); outputs.append(output)
            # Ground truth is only joined in this test assertion, never passed to tracker.
            self.assertIsNotNone(truth.targets[0].image_center_px)
            self.assertAlmostEqual(output.estimated_center_px[0], truth.targets[0].image_center_px[0], delta=1.5)  # type: ignore[index]
            if engine.status.name == "RUNNING": engine.step()
        self.assertTrue(all(x.measured for x in outputs))


if __name__ == "__main__": unittest.main()
