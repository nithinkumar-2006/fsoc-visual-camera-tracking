from __future__ import annotations
import csv, json, math, tempfile, unittest
from pathlib import Path

from core.benchmarking import AlgorithmMode, BenchmarkCollector, BenchmarkRunner, scenario_preset
from core.contracts.camera import GroundTruthFrame, ProjectedTargetTruth
from core.contracts.tracking import TrackingOutput, TrackingStatus

def truth(frame=0, t=0., pos=(10.,20.), visible=True):
    return GroundTruthFrame(frame,t,(ProjectedTargetTruth("beacon",visible,pos if visible else None,None,False),))
def output(frame=0,t=0.,pos=(13.,16.), *, measured=True, status=TrackingStatus.TRACKING):
    return TrackingOutput(frame,t,None,pos,(0,0),(3,-4),.9,status,measured,1,0)
class BenchmarkMetricTests(unittest.TestCase):
 def test_errors_missing_acquisition_lock_loss_and_reacquisition(self):
  c=BenchmarkCollector(lock_consecutive_frames=2); c.record_events(())
  c.record_frame(truth=truth(),tracking=output(),detector_id="d",controller_id="c",camera_pan_rad=0,camera_tilt_rad=0,active_disturbances=(),timings_ms={"tracking":2})
  c.record_frame(truth=truth(1,.1),tracking=output(1,.1),detector_id="d",controller_id="c",camera_pan_rad=0,camera_tilt_rad=0,active_disturbances=(),timings_ms={"tracking":2})
  c.record_frame(truth=truth(2,.2),tracking=output(2,.2,None,measured=False,status=TrackingStatus.LOST),detector_id="d",controller_id="c",camera_pan_rad=0,camera_tilt_rad=0,active_disturbances=(),timings_ms={"tracking":2})
  c.record_frame(truth=truth(3,.3),tracking=output(3,.3,(10,20),status=TrackingStatus.REACQUIRED),detector_id="d",controller_id="c",camera_pan_rad=0,camera_tilt_rad=0,active_disturbances=(),timings_ms={"tracking":2})
  m=c.finish(simulation_duration_s=.4,execution_duration_s=.2); self.assertAlmostEqual(m.average_tracking_error_px,10/3); self.assertEqual(m.missing_estimate_visible_frames,1); self.assertEqual(m.acquisition_time_s,0); self.assertEqual(m.target_loss_count,1); self.assertAlmostEqual(m.reacquisition_times_s[0],.1); self.assertEqual(m.lock_retention_percent,25); self.assertEqual(m.effective_processing_fps,20)
 def test_truth_has_no_pipeline_api(self):
  self.assertNotIn("truth", BenchmarkRunner.run.__annotations__)
class BenchmarkIntegrationTests(unittest.TestCase):
 def test_clean_and_occlusion_are_deterministic_and_exported(self):
  runner=BenchmarkRunner(); clean=scenario_preset("clean",seed=3,duration_s=.5); a=runner.run(clean,AlgorithmMode.BASELINE,scenario="clean"); b=runner.run(clean,AlgorithmMode.BASELINE,scenario="clean")
  self.assertEqual([(r["truth_u_px"],r["tracking_error_px"]) for r in a.telemetry],[(r["truth_u_px"],r["tracking_error_px"]) for r in b.telemetry]); self.assertGreater(a.metrics.processed_frames,0)
  occ=runner.run(scenario_preset("temporary_occlusion",seed=3,duration_s=2),AlgorithmMode.CLASSICAL_ADVANCED,scenario="temporary_occlusion"); self.assertGreaterEqual(occ.metrics.target_loss_count,1); self.assertTrue(occ.metrics.reacquisition_times_s)
  with tempfile.TemporaryDirectory() as d:
   report,telemetry=runner.export(a,d,stem="sample"); self.assertEqual(json.loads(report.read_text())["seed"],3)
   with telemetry.open() as f:self.assertEqual(len(list(csv.DictReader(f))),a.metrics.processed_frames)
 def test_same_seed_comparison_and_ai_mode(self):
  runner=BenchmarkRunner(); cfg=scenario_preset("false_bright_objects",seed=7,duration_s=.4); rs=runner.compare(cfg,[AlgorithmMode.BASELINE,AlgorithmMode.AI_ASSISTED],scenario="false_bright_objects",seeds=[7])
  self.assertEqual({r.seed for r in rs},{7}); self.assertEqual({r.configuration_hash for r in rs}, {rs[0].configuration_hash}); self.assertEqual(len(rs),2)
  with tempfile.TemporaryDirectory() as d:
   path=runner.export_comparison(rs,Path(d)/"comparison.csv"); self.assertEqual(len(path.read_text().splitlines()),3)
