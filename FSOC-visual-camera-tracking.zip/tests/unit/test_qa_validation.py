"""Role #13 regression coverage for configuration boundary defects."""
from __future__ import annotations

from copy import deepcopy
import unittest

from core.benchmarking import scenario_preset
from core.simulation.engine import ConfigError, validate_experiment_config


class QAConfigurationBoundaryTests(unittest.TestCase):
    def test_camera_and_disturbance_errors_fail_at_validation_boundary(self):
        cases = (
            ("zero resolution", lambda c: c["camera"].update(resolution_px=[0, 101])),
            ("zero FOV", lambda c: c["camera"].update(hfov_rad=0)),
            ("negative severity", lambda c: c["disturbances"].update(sensor_noise={"enabled": True, "severity": -0.1})),
            ("reversed schedule", lambda c: c["disturbances"].update(occlusion={"enabled": True, "start_s": 2, "end_s": 1})),
        )
        for label, mutate in cases:
            with self.subTest(label=label):
                config = scenario_preset("clean")
                mutate(config)
                with self.assertRaises(ConfigError):
                    validate_experiment_config(config)

    def test_invalid_seed_has_a_clear_config_error(self):
        config = scenario_preset("clean")
        config["seed"] = "not-a-seed"
        with self.assertRaises(ConfigError):
            validate_experiment_config(config)


if __name__ == "__main__":
    unittest.main()
