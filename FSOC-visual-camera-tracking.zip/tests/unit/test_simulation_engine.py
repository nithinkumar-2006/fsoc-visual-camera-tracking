from __future__ import annotations

import math
import unittest

from core.simulation import LifecycleStatus, SimulationEngine, validate_experiment_config
from core.simulation.engine import ConfigError


def config(*targets, seed=17, duration=1.0, dt=0.1):
    return validate_experiment_config({"schema_version":"2.0", "experiment_id":"unit-scenario", "seed":seed,
        "duration_s":duration, "simulation_dt_s":dt, "camera":{}, "targets":list(targets), "disturbances":[],
        "pipeline":{}, "lock_policy":{}, "benchmark":{}, "export":{},
        "environment":{"bounds_w_m":[[-10,10],[-10,10],[0,20]], "background":{"level":.1}}})


def target(kind="stationary", **extra):
    value = {"target_id":"beacon-01", "position_w_m":[1,2,3], "designated":True, "emission":.8, "trajectory":{"type":kind}}
    value.update(extra)
    return value


def run(engine):
    events, snapshots = list(engine.start()), [engine.snapshot()]
    while engine.status is LifecycleStatus.RUNNING:
        snapshot, tick_events = engine.step(); snapshots.append(snapshot); events.extend(tick_events)
    return snapshots, events


class SimulationEngineTests(unittest.TestCase):
    def assertVectorAlmostEqual(self, actual, expected, places=9):
        self.assertEqual(len(actual), len(expected))
        for a, e in zip(actual, expected): self.assertAlmostEqual(a, e, places=places)

    def test_fixed_step_timing_frame_identification_and_run_completion(self):
        snapshots, events = run(SimulationEngine(config(target("linear", velocity_w_mps=[2,0,0]), duration=.3, dt=.1)))
        self.assertEqual([s.context.frame_id for s in snapshots], [0,1,2,3])
        self.assertVectorAlmostEqual([s.context.t_sim_s for s in snapshots], [0,.1,.2,.3])
        self.assertEqual(events[-1].type, "RUN_STOPPED"); self.assertEqual(events[-1].payload["reason"], "duration_completed")

    def test_pause_resume_reset_and_stop(self):
        engine = SimulationEngine(config(target("linear", velocity_w_mps=[1,0,0])))
        engine.start(); engine.step(); engine.pause(); old = engine.snapshot()
        self.assertEqual(engine.step()[0], old)
        engine.resume(); engine.step(); event = engine.stop()[0]
        self.assertEqual(event.t_sim_s, .2); self.assertEqual(engine.status, LifecycleStatus.STOPPED)
        engine.reset(); self.assertEqual(engine.status, LifecycleStatus.IDLE); self.assertEqual(engine.snapshot().context.t_sim_s, 0.0)

    def test_stationary_linear_and_accelerated_truth(self):
        cases = [("stationary", {}, (1,2,3), (0,0,0), (0,0,0)),
                 ("linear", {"velocity_w_mps":[2,0,0]}, (3,2,3), (2,0,0), (0,0,0)),
                 ("accelerated", {"acceleration_w_mps2":[2,0,0]}, (2,2,3), (2,0,0), (2,0,0))]
        for kind, extra, position, velocity, acceleration in cases:
            with self.subTest(kind=kind):
                truth = run(SimulationEngine(config(target(kind, **extra))))[0][-1].targets[0]
                self.assertVectorAlmostEqual(truth.position_w_m, position); self.assertVectorAlmostEqual(truth.velocity_w_mps, velocity)
                self.assertVectorAlmostEqual(truth.acceleration_w_mps2, acceleration)

    def test_sinusoidal_and_coordinate_contract(self):
        t = target("sinusoidal", position_w_m=[0,0,0], trajectory={"type":"sinusoidal", "amplitude_m":2, "frequency_hz":.5, "phase_rad":0, "axis_w":[0,1,0]})
        truth = run(SimulationEngine(config(t)))[0][-1].targets[0]
        self.assertVectorAlmostEqual(truth.position_w_m, (0,0,0)); self.assertVectorAlmostEqual(truth.velocity_w_mps, (0,-2 * math.pi,0))
        linear = run(SimulationEngine(config(target("linear", position_w_m=[0,0,0], velocity_w_mps=[1,2,3]))))[0][-1].targets[0]
        self.assertVectorAlmostEqual(linear.position_w_m, (1,2,3))

    def test_seeded_random_replay_and_different_seed(self):
        payload = target("random", trajectory={"type":"random", "acceleration_std_mps2":.5, "max_speed_mps":3})
        first = run(SimulationEngine(config(payload, seed=99)))[0]
        second = run(SimulationEngine(config(payload, seed=99)))[0]
        third = run(SimulationEngine(config(payload, seed=100)))[0]
        self.assertEqual([x.targets[0] for x in first], [x.targets[0] for x in second])
        self.assertNotEqual(first[-1].targets[0].position_w_m, third[-1].targets[0].position_w_m)

    def test_sudden_maneuver_multiple_targets_and_visibility_schedule(self):
        maneuver = target("sudden_maneuver", position_w_m=[0,0,0], velocity_w_mps=[1,0,0], trajectory={"type":"sudden_maneuver", "maneuvers":[{"at_s":.5, "velocity_w_mps":[0,2,0]}]})
        snapshots, _ = run(SimulationEngine(config(maneuver)))
        self.assertVectorAlmostEqual(snapshots[5].targets[0].position_w_m, (.5,0,0)); self.assertVectorAlmostEqual(snapshots[-1].targets[0].position_w_m, (.5,1,0))
        beacon = target(visibility={"default_enabled":True, "intervals":[{"start_s":.2,"end_s":.5,"enabled":False}]})
        distractor = {"target_id":"distractor-02", "position_w_m":[5,0,0], "designated":False, "trajectory":{"type":"stationary"}}
        snapshots, _ = run(SimulationEngine(config(beacon, distractor)))
        self.assertEqual([x.designated for x in snapshots[0].targets], [True, False]); self.assertFalse(snapshots[2].targets[0].visible_truth); self.assertTrue(snapshots[5].targets[0].visible_truth)

    def test_invalid_configuration_is_rejected(self):
        raw = {"schema_version":"2", "experiment_id":"x", "seed":1, "duration_s":1, "simulation_dt_s":.1, "camera":{}, "targets":[target()], "disturbances":[], "pipeline":{}, "lock_policy":{}, "benchmark":{}, "export":{}}
        with self.assertRaises(ConfigError): validate_experiment_config(dict(raw, unexpected=1))
        with self.assertRaises(ConfigError): validate_experiment_config(dict(raw, simulation_dt_s=.3))


if __name__ == "__main__": unittest.main()
