"""Application-layer tests; Tk widgets themselves are intentionally not pixel tested."""
import tempfile
import unittest
from pathlib import Path

from app import ApplicationController, ApplicationState
from core.benchmarking import AlgorithmMode


class ApplicationControllerTests(unittest.TestCase):
    def test_lifecycle_telemetry_and_missing_values(self):
        app=ApplicationController()
        self.assertEqual(app.snapshot().state,ApplicationState.IDLE)
        self.assertIsNone(app.snapshot().telemetry["confidence"])
        app.start(); snap=app.tick()
        self.assertIn(snap.state,{ApplicationState.ACQUIRING,ApplicationState.TRACKING,ApplicationState.LOCKED})
        self.assertIsNotNone(snap.frame)
        self.assertIn("RUN_STARTED",[e["type"] if isinstance(e,dict) else e.type for e in snap.events])
        app.pause(); self.assertEqual(app.engine.status.name,"PAUSED")
        app.start(); app.stop(); self.assertEqual(app.snapshot().state,ApplicationState.STOPPED)
        app.reset(); self.assertEqual(app.snapshot().state,ApplicationState.IDLE)

    def test_algorithm_preset_disturbance_and_truth_isolation(self):
        app=ApplicationController(); app.select_algorithm(AlgorithmMode.AI_ASSISTED)
        self.assertTrue(app.snapshot().model_health["model_loaded"])
        app.select_preset("Temporary Occlusion")
        app.set_disturbance("sensor_noise",enabled=True,severity=.4)
        self.assertTrue(app.config["disturbances"]["sensor_noise"]["enabled"])
        app.start(); snap=app.tick()
        self.assertFalse(hasattr(snap.frame,"ground_truth"))
        self.assertIsNotNone(snap.truth) # only composition/evaluation boundary owns it

    def test_benchmark_and_export(self):
        app=ApplicationController()
        with tempfile.TemporaryDirectory() as d:
            report,telemetry=app.export(d)
            self.assertTrue(report.exists()); self.assertTrue(telemetry.exists())
        results=app.run_benchmark()
        self.assertEqual(len(results),3)
