"""Tests for the local-only HTTP adapter; core behavior is covered separately."""
import json
import threading
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from gui.web import create_server


class WebLayerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server, cls.service = create_server(port=0)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.service.close()
        cls.thread.join(timeout=1)

    def request(self, path, body=None):
        data = None if body is None else json.dumps(body).encode()
        req = Request(self.base + path, data=data, headers={"Content-Type": "application/json"})
        with urlopen(req, timeout=5) as response:
            return response.status, json.load(response) if path.startswith("/api/") else response.read()

    def test_page_and_state_contract(self):
        status, page = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn(b"Optical Tracking Laboratory", page)
        status, state = self.request("/api/state")
        self.assertEqual(status, 200)
        self.assertEqual(state["state"], "IDLE")
        self.assertEqual(len(state["algorithms"]), 3)

    def test_controls_reuse_application_controller(self):
        _, started = self.request("/api/control", {"action": "start"})
        self.assertIn(started["state"], {"SEARCHING", "ACQUIRING", "TRACKING", "LOCKED"})
        _, reset = self.request("/api/control", {"action": "reset"})
        self.assertEqual(reset["state"], "IDLE")

    def test_non_local_bind_is_rejected(self):
        with self.assertRaises(ValueError):
            create_server("0.0.0.0", 0)


if __name__ == "__main__":
    unittest.main()
