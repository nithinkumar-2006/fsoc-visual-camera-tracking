"""Role #12 end-to-end reliability coverage."""
