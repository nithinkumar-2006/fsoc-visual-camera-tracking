"""End-to-end checks for lifecycle, reproducibility, paths and containment."""
from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

from app import ApplicationController, ApplicationState
from core.benchmarking import AlgorithmMode, BenchmarkRunner, scenario_preset
from core.simulation.engine import ConfigError, validate_experiment_config


def event_types(snapshot):
    return [event["type"] if isinstance(event, dict) else event.type for event in snapshot.events]


class SystemIntegrationTests(unittest.TestCase):
    def test_pause_resume_reset_and_deterministic_replay(self):
        app = ApplicationController(preset="Vibration")
        app.start()
        first = app.tick().frame.image_gray8
        t_before_pause = app.engine.snapshot().context.t_sim_s
        app.pause()
        self.assertEqual(app.tick().frame.image_gray8, first)
        self.assertEqual(app.engine.snapshot().context.t_sim_s, t_before_pause)
        app.start()
        app.tick()
        app.reset()
        app.start()
        self.assertEqual(app.tick().frame.image_gray8, first)

    def test_ai_model_is_found_outside_repository_cwd(self):
        original = Path.cwd()
        with tempfile.TemporaryDirectory() as directory:
            try:
                os.chdir(directory)
                app = ApplicationController(mode=AlgorithmMode.AI_ASSISTED)
                self.assertTrue(app.snapshot().model_health["model_loaded"])
                result = BenchmarkRunner().run(scenario_preset("clean", duration_s=.1), AlgorithmMode.AI_ASSISTED)
                self.assertGreater(result.metrics.processed_frames, 0)
            finally:
                os.chdir(original)

    def test_fault_is_contained_once_and_reset_recovers(self):
        app = ApplicationController()
        app.start()
        def fail(_frame):
            raise RuntimeError("injected detector failure")
        app.detector.process = fail
        snapshot = app.tick()
        self.assertEqual(snapshot.state, ApplicationState.FAULTED)
        self.assertEqual(app.engine.status.name, "FAULTED")
        self.assertEqual(event_types(snapshot).count("RUN_FAULTED"), 1)
        app.tick()
        self.assertEqual(event_types(app.snapshot()).count("RUN_FAULTED"), 1)
        app.reset()
        self.assertEqual(app.snapshot().state, ApplicationState.IDLE)

    def test_canonical_lock_event_and_full_export(self):
        app = ApplicationController()
        app.start()
        for _ in range(5):
            snapshot = app.tick()
        self.assertIn("LOCK_ENTERED", event_types(snapshot))
        with tempfile.TemporaryDirectory() as directory:
            report, telemetry = app.export(directory)
            results = app.run_benchmark()
            comparison = BenchmarkRunner.export_comparison(results, Path(directory) / "comparison.csv")
            self.assertTrue(report.exists() and telemetry.exists() and comparison.exists())

    def test_invalid_config_remains_a_clear_boundary_error(self):
        config = scenario_preset("clean")
        config["duration_s"] = float("nan")
        with self.assertRaises(ConfigError):
            validate_experiment_config(config)
